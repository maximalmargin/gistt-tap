from __future__ import annotations

from dataclasses import replace
from typing import Any, Dict

from gistt.actions.unsubscribe import UnsubscribeAction
from gistt.models import EmailContext, EmailMessage, Gistt


class _StubGmailOps:
    def __init__(self, *, unsubscribe_result: bool, filter_result: bool, archive_result: bool) -> None:
        self.unsubscribe_result = unsubscribe_result
        self.filter_result = filter_result
        self.archive_result = archive_result
        self.unsubscribe_calls: list[Dict[str, Any]] = []
        self.filter_calls: list[Dict[str, Any]] = []
        self.archive_calls: list[Dict[str, Any]] = []

    def perform_list_unsubscribe(self, *, account_email: str | None, message_id: str) -> bool:
        self.unsubscribe_calls.append({"account_email": account_email, "message_id": message_id})
        return self.unsubscribe_result

    def create_auto_archive_filter(self, *, account_email: str | None, sender: str) -> bool:
        self.filter_calls.append({"account_email": account_email, "sender": sender})
        return self.filter_result

    def modify_thread_labels(
        self,
        *,
        account_email: str | None,
        thread_id: str,
        add_labels: list[str],
        remove_labels: list[str],
    ) -> bool:
        self.archive_calls.append(
            {
                "account_email": account_email,
                "thread_id": thread_id,
                "add_labels": list(add_labels),
                "remove_labels": list(remove_labels),
            }
        )
        return self.archive_result


def _sample_gistt(sender: str = "Example Sender <sender@example.com>") -> Gistt:
    email = EmailMessage(
        id="message-1",
        sender=sender,
        subject="Test message",
        time="2024-02-10T12:00:00Z",
        body="Body",
        is_from_user=False,
        account="user@example.com",
        context=EmailContext(id="thread-123", messages=[]),
    )
    return Gistt(content="content", email_message=email)


def test_unsubscribe_prefers_standard_method() -> None:
    action = UnsubscribeAction()
    gistt = _sample_gistt()
    client = _StubGmailOps(unsubscribe_result=True, filter_result=False, archive_result=True)

    result = action.execute(gistt, client)

    assert result is True
    assert len(client.unsubscribe_calls) == 1
    assert not client.filter_calls
    assert len(client.archive_calls) == 1
    assert action.execution_detail == "standard unsubscribe"


def test_unsubscribe_falls_back_to_filter() -> None:
    action = UnsubscribeAction()
    gistt = _sample_gistt()
    client = _StubGmailOps(unsubscribe_result=False, filter_result=True, archive_result=True)

    result = action.execute(gistt, client)

    assert result is True
    assert len(client.unsubscribe_calls) == 1
    assert len(client.filter_calls) == 1
    assert len(client.archive_calls) == 1
    call = client.filter_calls[0]
    assert call["sender"] == "sender@example.com"
    assert action.execution_detail == "auto-archive filter"


def test_unsubscribe_returns_false_when_all_fail() -> None:
    action = UnsubscribeAction()
    gistt = _sample_gistt()
    client = _StubGmailOps(unsubscribe_result=False, filter_result=False, archive_result=True)

    result = action.execute(gistt, client)

    assert result is False
    assert len(client.unsubscribe_calls) == 1
    assert len(client.filter_calls) == 1
    assert not client.archive_calls
    assert action.execution_detail is None


def test_unsubscribe_returns_false_when_archive_fails() -> None:
    action = UnsubscribeAction()
    gistt = _sample_gistt()
    client = _StubGmailOps(unsubscribe_result=True, filter_result=False, archive_result=False)

    result = action.execute(gistt, client)

    assert result is False
    assert len(client.unsubscribe_calls) == 1
    assert len(client.archive_calls) == 1
    assert action.execution_detail is None


def test_unsubscribe_requires_message_id() -> None:
    action = UnsubscribeAction()
    gistt = _sample_gistt()
    broken_email = replace(gistt.email_message, id="")
    broken_gistt = replace(gistt, email_message=broken_email)
    client = _StubGmailOps(unsubscribe_result=True, filter_result=True, archive_result=True)

    result = action.execute(broken_gistt, client)

    assert result is False
    assert not client.unsubscribe_calls
    assert not client.filter_calls
    assert not client.archive_calls
    assert action.execution_detail is None


def test_unsubscribe_requires_thread_id() -> None:
    action = UnsubscribeAction()
    gistt = _sample_gistt()
    no_thread_email = replace(gistt.email_message, context=None)
    no_thread_gistt = replace(gistt, email_message=no_thread_email)
    client = _StubGmailOps(unsubscribe_result=True, filter_result=True, archive_result=True)

    result = action.execute(no_thread_gistt, client)

    assert result is False
    assert not client.unsubscribe_calls
    assert not client.filter_calls
    assert not client.archive_calls
    assert action.execution_detail is None
