import sys
import types
from pathlib import Path
import unittest


def ensure_google_stubs() -> None:
    if "google" not in sys.modules:
        sys.modules["google"] = types.ModuleType("google")
    google = sys.modules["google"]

    # google.genai hierarchy
    if not hasattr(google, "genai"):
        genai = types.ModuleType("google.genai")
        sys.modules["google.genai"] = genai
        google.genai = genai  # type: ignore[attr-defined]
    if "google.genai.types" not in sys.modules:
        sys.modules["google.genai.types"] = types.ModuleType("google.genai.types")

    # google.oauth2.credentials
    if "google.oauth2" not in sys.modules:
        sys.modules["google.oauth2"] = types.ModuleType("google.oauth2")
    if "google.oauth2.credentials" not in sys.modules:
        credentials_mod = types.ModuleType("google.oauth2.credentials")

        class _Credentials:
            def __init__(self, *args, **kwargs) -> None:
                pass

        credentials_mod.Credentials = _Credentials  # type: ignore[attr-defined]
        sys.modules["google.oauth2.credentials"] = credentials_mod

    # googleapiclient discovery/errors
    if "googleapiclient" not in sys.modules:
        sys.modules["googleapiclient"] = types.ModuleType("googleapiclient")
    if "googleapiclient.discovery" not in sys.modules:
        discovery = types.ModuleType("googleapiclient.discovery")

        def _build(*args, **kwargs):
            return object()

        discovery.build = _build  # type: ignore[attr-defined]
        sys.modules["googleapiclient.discovery"] = discovery
    if "googleapiclient.errors" not in sys.modules:
        errors = types.ModuleType("googleapiclient.errors")

        class _HttpError(Exception):
            pass

        errors.HttpError = _HttpError  # type: ignore[attr-defined]
        sys.modules["googleapiclient.errors"] = errors

    # google.auth transport
    if "google.auth" not in sys.modules:
        sys.modules["google.auth"] = types.ModuleType("google.auth")
    if "google.auth.transport" not in sys.modules:
        sys.modules["google.auth.transport"] = types.ModuleType("google.auth.transport")
    if "google.auth.transport.requests" not in sys.modules:
        requests_mod = types.ModuleType("google.auth.transport.requests")

        class _Request:
            pass

        requests_mod.Request = _Request  # type: ignore[attr-defined]
        sys.modules["google.auth.transport.requests"] = requests_mod

    # google_auth_oauthlib.flow
    if "google_auth_oauthlib" not in sys.modules:
        sys.modules["google_auth_oauthlib"] = types.ModuleType("google_auth_oauthlib")
    if "google_auth_oauthlib.flow" not in sys.modules:
        flow_mod = types.ModuleType("google_auth_oauthlib.flow")

        class _Flow:
            @classmethod
            def from_client_secrets_file(cls, *args, **kwargs):
                return cls()

            def run_local_server(self, *args, **kwargs):
                return types.SimpleNamespace(to_json=lambda: "{}")

        flow_mod.InstalledAppFlow = _Flow  # type: ignore[attr-defined]
        sys.modules["google_auth_oauthlib.flow"] = flow_mod

    if "dotenv" not in sys.modules:
        dotenv_mod = types.ModuleType("dotenv")

        def _load_dotenv(*args, **kwargs):
            return None

        dotenv_mod.load_dotenv = _load_dotenv  # type: ignore[attr-defined]
        sys.modules["dotenv"] = dotenv_mod


ensure_google_stubs()

PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_PATH = PROJECT_ROOT / "src"
if str(SRC_PATH) not in sys.path:
    sys.path.insert(0, str(SRC_PATH))

from gistt.settings import get_settings  # noqa: E402
from gistt.models import ActionGroupRec  # noqa: E402
from gistt.ui.cli import GisttCLI  # noqa: E402


def _summary(thread_id: str, subject: str, sender: str = "sender@example.com") -> types.SimpleNamespace:
    return types.SimpleNamespace(
        thread_id=thread_id,
        subject=subject,
        sender=sender,
        date="2024-01-01T00:00:00Z",
        snippet="snippet",
        body="body",
        message_count=1,
        is_last_from_user=False,
        account="account@example.com",
        has_unread=True,
    )


class TestPrioritySelectionIndex(unittest.TestCase):
    def setUp(self) -> None:
        self.cli = GisttCLI.__new__(GisttCLI)
        settings_bundle = get_settings()
        self.cli._config = types.SimpleNamespace(settings=settings_bundle)

    def test_priority_selection_prefers_first_priority_group(self) -> None:
        action_summary = _summary("t-action", "Action Needed summary")
        archive_summary = _summary("t-archive", "Archive summary")
        summaries = [archive_summary, action_summary]

        def fake_groups(items: list[types.SimpleNamespace]) -> list[tuple[str, list[types.SimpleNamespace]]]:
            return [
                ("Action Needed", [action_summary]),
                ("Archive", [archive_summary]),
            ]

        self.cli._group_summaries_by_action = fake_groups  # type: ignore[method-assign]
        index = GisttCLI._priority_selection_index(self.cli, summaries)
        self.assertEqual(index, 1)

    def test_priority_selection_defaults_to_zero_when_no_groups(self) -> None:
        self.cli._group_summaries_by_action = lambda summaries: []  # type: ignore[method-assign]
        index = GisttCLI._priority_selection_index(self.cli, [])
        self.assertEqual(index, 0)


class TestGrouping(unittest.TestCase):
    def setUp(self) -> None:
        self.cli = GisttCLI.__new__(GisttCLI)
        settings_bundle = get_settings()
        self.cli._config = types.SimpleNamespace(settings=settings_bundle)

    def test_grouping_orders_priority_buckets(self) -> None:
        summaries = [
            _summary("thread-1", "Archive first"),
            _summary("thread-2", "FYI second"),
            _summary("thread-3", "Action needed third"),
            _summary("thread-4", "Waiting fourth"),
        ]
        action_by_thread = {
            "thread-1": "Archive",
            "thread-2": "FYI - Archive",
            "thread-3": "Action Needed",
            "thread-4": "Waiting on Reply",
        }
        def fake_recommendation(summary: types.SimpleNamespace, *_: object, **__: object) -> ActionGroupRec:
            group = action_by_thread.get(summary.thread_id, "Other")
            group_obj = self.cli._config.settings.group_for_name(group)
            if not group_obj:
                raise AssertionError(f"Missing group configuration for {group}.")
            return ActionGroupRec(action_group=group_obj, explanation="")

        self.cli._get_ai_recommendation = fake_recommendation  # type: ignore[method-assign]
        grouped = GisttCLI._group_summaries_by_action(self.cli, summaries)
        group_names = [name for name, _ in grouped]
        self.assertEqual(group_names, ["Action Needed", "Waiting on Reply", "FYI - Archive", "Archive"])

        # Ensure summaries preserve their original order inside buckets.
        archive_group = next(items for name, items in grouped if name == "Archive")
        self.assertEqual(archive_group[0].thread_id, "thread-1")

    def test_recommended_option_prefers_save_for_fyi(self) -> None:
        group_obj = self.cli._config.settings.group_for_name("FYI - Save")
        self.assertIsNotNone(group_obj)
        assert group_obj is not None
        recommendation = ActionGroupRec(action_group=group_obj, explanation="")
        option = self.cli._recommended_option(recommendation)
        self.assertEqual(option, "s")


if __name__ == "__main__":
    unittest.main()
