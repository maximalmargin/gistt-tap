"""Test helpers and shims for the Gistt project."""
from __future__ import annotations

import os
from pathlib import Path
import sys
import types


def _ensure_module(name: str) -> types.ModuleType:
    module = sys.modules.get(name)
    if module is None:
        module = types.ModuleType(name)
        sys.modules[name] = module
    return module


def _setup_google_stubs() -> None:
    project_root = Path(__file__).resolve().parents[1]
    src_path = project_root / "src"
    if str(src_path) not in sys.path:
        sys.path.insert(0, str(src_path))

    config_home = project_root / ".pytest-config"
    config_home.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("XDG_CONFIG_HOME", str(config_home))

    google = _ensure_module("google")

    # google.genai and supporting namespaces
    genai = _ensure_module("google.genai")
    if not hasattr(genai, "Client"):
        class _MockGenAIClient:
            def __init__(self, *args, **kwargs) -> None:
                self.args = args
                self.kwargs = kwargs

            def models(self) -> "_MockGenAIClient":  # pragma: no cover - helper stub
                return self

        genai.Client = _MockGenAIClient  # type: ignore[attr-defined]
    genai_types = _ensure_module("google.genai.types")
    if not hasattr(genai_types, "Content"):
        class _MockContent:
            def __init__(self, *args, **kwargs) -> None:
                self.args = args
                self.kwargs = kwargs

        class _MockPart:
            @staticmethod
            def from_text(text: str) -> str:  # pragma: no cover - helper stub
                return text

        class _MockGenerateContentConfig(dict):  # pragma: no cover - simple dict shim
            pass

        genai_types.Content = _MockContent  # type: ignore[attr-defined]
        genai_types.Part = _MockPart  # type: ignore[attr-defined]
        genai_types.GenerateContentConfig = _MockGenerateContentConfig  # type: ignore[attr-defined]
    google.genai = genai  # type: ignore[attr-defined]

    # google.oauth2.credentials
    oauth2 = _ensure_module("google.oauth2")
    credentials_mod = _ensure_module("google.oauth2.credentials")

    if not hasattr(credentials_mod, "Credentials"):
        class _MockCredentials:
            def __init__(self, *args, **kwargs) -> None:
                self.valid = True
                self.expired = False
                self.refresh_token = None

            @classmethod
            def from_authorized_user_file(cls, *_: object, **__: object) -> "_MockCredentials":
                return cls()

            def to_json(self) -> str:  # pragma: no cover - helper stub
                return "{}"

        credentials_mod.Credentials = _MockCredentials  # type: ignore[attr-defined]
    oauth2.credentials = credentials_mod  # type: ignore[attr-defined]

    # googleapiclient discovery/errors shims
    googleapiclient = _ensure_module("googleapiclient")
    discovery = _ensure_module("googleapiclient.discovery")
    errors = _ensure_module("googleapiclient.errors")

    if not hasattr(discovery, "build"):
        def _build(*args, **kwargs):  # pragma: no cover - construction stub
            return object()

        discovery.build = _build  # type: ignore[attr-defined]

    if not hasattr(errors, "HttpError"):
        class _HttpError(Exception):
            pass

        errors.HttpError = _HttpError  # type: ignore[attr-defined]

    googleapiclient.discovery = discovery  # type: ignore[attr-defined]
    googleapiclient.errors = errors  # type: ignore[attr-defined]

    # google.auth transport stubs
    google_auth = _ensure_module("google.auth")
    transport = _ensure_module("google.auth.transport")
    requests_mod = _ensure_module("google.auth.transport.requests")

    if not hasattr(requests_mod, "Request"):
        class _MockRequest:  # pragma: no cover - helper stub
            def __call__(self, *args, **kwargs):
                return None

        requests_mod.Request = _MockRequest  # type: ignore[attr-defined]

    transport.requests = requests_mod  # type: ignore[attr-defined]
    google_auth.transport = transport  # type: ignore[attr-defined]

    # google_auth_oauthlib flow stub
    oauthlib = _ensure_module("google_auth_oauthlib")
    flow = _ensure_module("google_auth_oauthlib.flow")

    if not hasattr(flow, "InstalledAppFlow"):
        class _MockFlow:
            def __init__(self, *args, **kwargs) -> None:
                pass

            @classmethod
            def from_client_secrets_file(cls, *args, **kwargs) -> "_MockFlow":
                return cls()

            def run_local_server(self, *args, **kwargs):  # pragma: no cover - helper stub
                return _ensure_module("google.oauth2.credentials").Credentials()

        flow.InstalledAppFlow = _MockFlow  # type: ignore[attr-defined]

    oauthlib.flow = flow  # type: ignore[attr-defined]


_setup_google_stubs()
