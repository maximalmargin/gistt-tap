import unittest
from unittest import mock
from gistt.services.genai_ops import GenAIOps
from google import genai


class TestGenAIOps(unittest.TestCase):
    def test_post_init(self):
        genai_ops = GenAIOps()
        self.assertIsNotNone(genai_ops.config)
        self.assertEqual(genai_ops.config.thinking_config.thinking_budget, -1)

    @mock.patch("gistt.services.genai_ops.genai.Client")
    def test_generate(self, mock_client_cls):
        client_instance = mock.MagicMock()
        client_instance.models.generate_content.return_value.text = "Hello, world!"
        mock_client_cls.return_value = client_instance

        genai_ops = GenAIOps()
        self.assertEqual(genai_ops.generate("Say 'Hello, world!'"), "Hello, world!")
if __name__ == "__main__":
    unittest.main()
