import contextlib
import io
import unittest

from gistt.ui.cli import _parse_cli_args, _resolve_version


class TestCliVersionFlag(unittest.TestCase):
    def test_version_flag_prints_version(self) -> None:
        expected = _resolve_version()
        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            with self.assertRaises(SystemExit) as exit_info:
                _parse_cli_args(["--version"])

        self.assertEqual(exit_info.exception.code, 0)
        output = buffer.getvalue().strip()
        self.assertIn(expected, output)
        self.assertTrue(output.startswith("gistt "))
