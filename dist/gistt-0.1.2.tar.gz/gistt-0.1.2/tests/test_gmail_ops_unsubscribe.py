from __future__ import annotations

from typing import Any, Dict, List, Optional

from gistt.services.gmail_ops import GmailOps
from gistt.settings import Settings


class _FakeExecute:
    def __init__(self, payload: Any) -> None:
        self._payload = payload

    def execute(self) -> Any:
        return self._payload


class _FakeMessages:
    def __init__(self, *, get_payload: Dict[str, Any]) -> None:
        self._get_payload = get_payload
        self.get_calls: List[Dict[str, Any]] = []
        self.send_calls: List[Dict[str, Any]] = []

    def get(self, **kwargs: Any) -> _FakeExecute:
        self.get_calls.append(kwargs)
        return _FakeExecute(self._get_payload)

    def send(self, *, userId: str, body: Dict[str, Any]) -> _FakeExecute:
        self.send_calls.append({"userId": userId, "body": body})
        return _FakeExecute({})


class _FakeFilters:
    def __init__(self, *, list_payload: Dict[str, Any]) -> None:
        self._list_payload = list_payload
        self.list_calls: List[Dict[str, Any]] = []
        self.create_calls: List[Dict[str, Any]] = []

    def list(self, **kwargs: Any) -> _FakeExecute:
        self.list_calls.append(kwargs)
        return _FakeExecute(self._list_payload)

    def create(self, *, userId: str, body: Dict[str, Any]) -> _FakeExecute:
        self.create_calls.append({"userId": userId, "body": body})
        return _FakeExecute({"id": "filter-created"})


class _FakeSettings:
    def __init__(self, filters_resource: _FakeFilters) -> None:
        self._filters_resource = filters_resource

    def filters(self) -> _FakeFilters:
        return self._filters_resource


class _FakeUsers:
    def __init__(self, messages_resource: _FakeMessages, filters_resource: _FakeFilters) -> None:
        self._messages_resource = messages_resource
        self._filters_resource = filters_resource

    def messages(self) -> _FakeMessages:
        return self._messages_resource

    def settings(self) -> _FakeSettings:
        return _FakeSettings(self._filters_resource)


class _FakeService:
    def __init__(self, messages_resource: _FakeMessages, filters_resource: _FakeFilters) -> None:
        self._users_resource = _FakeUsers(messages_resource, filters_resource)

    def users(self) -> _FakeUsers:
        return self._users_resource


class _StubAccountManager:
    def list(self) -> list[object]:  # pragma: no cover - unused in tests
        return []

    def get(self, email: str) -> Optional[object]:  # pragma: no cover - unused in tests
        return None

    def get_current(self) -> Optional[object]:  # pragma: no cover - unused in tests
        return None

    def credentials(self, config: object) -> None:  # pragma: no cover - unused in tests
        return None


def _gmail_ops_with_service(service: _FakeService) -> GmailOps:
    gmail_ops = GmailOps(account_manager=_StubAccountManager(), settings=Settings())
    key = gmail_ops._account_key(None)
    gmail_ops._service_cache[key] = service
    return gmail_ops


def test_perform_list_unsubscribe_mailto_sends_message() -> None:
    message_payload = {
        "payload": {
            "headers": [
                {"name": "List-Unsubscribe", "value": "<mailto:remove@example.com?subject=unsubscribe&body=Please%20remove%20me>"},
            ]
        }
    }
    messages = _FakeMessages(get_payload=message_payload)
    filters_resource = _FakeFilters(list_payload={"filter": []})
    service = _FakeService(messages, filters_resource)
    gmail_ops = _gmail_ops_with_service(service)

    success = gmail_ops.perform_list_unsubscribe(account_email=None, message_id="msg-1")

    assert success is True
    assert messages.send_calls, "Expected unsubscribe email to be sent."


def test_perform_list_unsubscribe_http_uses_post_when_requested() -> None:
    message_payload = {
        "payload": {
            "headers": [
                {"name": "List-Unsubscribe", "value": "<https://example.com/unsubscribe>"},
                {"name": "List-Unsubscribe-Post", "value": "List-Unsubscribe=One-Click"},
            ]
        }
    }
    messages = _FakeMessages(get_payload=message_payload)
    filters_resource = _FakeFilters(list_payload={"filter": []})
    service = _FakeService(messages, filters_resource)
    gmail_ops = _gmail_ops_with_service(service)

    called: Dict[str, Any] = {}

    def _fake_http(self, url: str, *, method: str) -> bool:
        called["url"] = url
        called["method"] = method
        return True

    gmail_ops._perform_http_unsubscribe = _fake_http.__get__(gmail_ops, GmailOps)  # type: ignore[assignment]

    success = gmail_ops.perform_list_unsubscribe(account_email=None, message_id="msg-2")

    assert success is True
    assert called["url"] == "https://example.com/unsubscribe"
    assert called["method"] == "post"


def test_create_auto_archive_filter_reuses_existing() -> None:
    filters_resource = _FakeFilters(
        list_payload={
            "filter": [
                {
                    "criteria": {"from": "sender@example.com"},
                    "action": {"removeLabelIds": ["INBOX"]},
                }
            ]
        }
    )
    messages = _FakeMessages(get_payload={"payload": {"headers": []}})
    service = _FakeService(messages, filters_resource)
    gmail_ops = _gmail_ops_with_service(service)

    success = gmail_ops.create_auto_archive_filter(account_email=None, sender="sender@example.com")

    assert success is True
    assert not filters_resource.create_calls


def test_create_auto_archive_filter_creates_new_filter() -> None:
    filters_resource = _FakeFilters(list_payload={"filter": []})
    messages = _FakeMessages(get_payload={"payload": {"headers": []}})
    service = _FakeService(messages, filters_resource)
    gmail_ops = _gmail_ops_with_service(service)

    success = gmail_ops.create_auto_archive_filter(account_email=None, sender="sender@example.com")

    assert success is True
    assert filters_resource.create_calls
    call = filters_resource.create_calls[0]
    assert call["userId"] == "me"
    assert call["body"]["criteria"]["from"] == "sender@example.com"
    assert call["body"]["action"]["removeLabelIds"] == ["INBOX"]
