# Design

## Philosophy

**1. Gistt-focused, not email-focused**  
We don't show you the email. Everything is modeled around the gistt, because what matters is understanding the intent and deciding what to do -- not wading through message threads.

**2. Terminal constraint as a feature**  
We chose the terminal for two reasons:

- **Target audience**: Hackers and tinkerers. Let a portion of the people get rich first. The design isn't fully fleshed out yet, so we want a small group who are tolerant of failures and can help iterate and customize.
- **Forced simplification**: Inspired by the success of Claude Code, Codex, and Gemini CLI, the limited UI is actually a good design constraint. It forces prioritization and simplification.

**3. Action-focused, opinionated state machine**  
We're not trying to write emails for you -- use your favorite chatbot for that. We focus on AI doing the cognitive processing of what action is needed from you. Our goal: get you out of here as fast as possible. Disengagement as success.

## Aesthetics: Retro-Futuristic

**Style Inspiration:**

- 1980s Saul Bass geometric minimalism meets synthwave
- Bauhaus meets Tron
- Constructivist poster design with neon accents
- Clean lines, bold shapes, limited color palette

**Color Palette:**

- Deep space blue/black background
- Cyan `#00ffff` as primary
- Neon accents:
  - Pink `#ff6ec7`
  - Green `#39ff14`
  - Yellow `#f9f871`
- White for contrast

Implementation note: UI components should reference the shared constants in `src/gistt/ui/palette.py` (`Palette.PRIMARY`, `Palette.PINK`, `Palette.GREEN`, `Palette.YELLOW`, etc.) instead of hard-coding color values.

**Mood:**

- Sophisticated, calm, focused
- Not chaotic cyberpunk — more like elegant data visualization meets 80s album cover
- The feeling of clarity, efficiency, and being in control
