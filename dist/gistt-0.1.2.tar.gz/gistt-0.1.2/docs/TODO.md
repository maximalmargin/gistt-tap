# TODO

- Scroll the cursor up `y=-2` at the welcome view.
- Handle key presses while fetching state.
- Evaluate migrating core models to Pydantic for simpler serialization/deserialization logic.
- Implement bulk operations.
- For actions already executed, skip execution.
- Support actions in the thread view.
- For replies, allow the user to give instructions.
- Time-based visual cues with symbols: ⚡ just now (bright green - needs attention) • 2h ago (yellow - recent) • ◦ 2d ago (dim - can wait).
- Codify UI copy rule: headers and labels stay lowercase (e.g., `active account`, `open in gmail`).
- Add debug mode to see exactly what the input to the API is
