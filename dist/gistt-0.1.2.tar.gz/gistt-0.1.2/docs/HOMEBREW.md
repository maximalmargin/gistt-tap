# Homebrew Packaging

Homebrew packaging now lives in the sibling `gistt-tap` repository (see `Formula/gistt.rb`). Use that tap repo for all release automation and dependency updates.

## Publishing a release

1. **Tag the code**  
   Bump the version in `pyproject.toml`, update `Formula/gistt.rb` in the `gistt-tap` repo (`url`/`sha256`), then create a git tag (`git tag v0.x.y && git push --tags`).

2. **Cut the source archive**  
   Build the tarball that Homebrew will download:  

   ```bash
   git archive --format=tar.gz --output dist/gistt-0.x.y.tar.gz v0.x.y
   shasum -a 256 dist/gistt-0.x.y.tar.gz
   ```  

   Because the main repo is private, upload that asset to a public release in `gistt-tap` (e.g. GitHub release `v0.x.y`). Rename it to `gistt-0.x.y.tar.gz` as you attach it, then copy the checksum into the formula.

3. **Refresh dependencies**  
   If runtime deps changed, regenerate resource blocks:  

   ```bash
   python ../gistt-tap/packaging/brew/update_resources.py > /tmp/resources.rb
   ```  

   Replace the resource section in `Formula/gistt.rb` inside the `gistt-tap` repo (leaving the platform-specific overrides for `maturin`, `protobuf`, and `pydantic-core` intact).

4. **Test the build locally**  

   ```bash
   brew uninstall --force gistt  # if already installed
   brew install --build-from-source ../gistt-tap/Formula/gistt.rb
   gistt --help
   ```

5. **Publish the tap**  
   Push the commit in `gistt-tap` and publish the release that hosts the tarball. Consumers can install with:  

   ```bash
   brew tap maximalmargin/gistt https://github.com/maximalmargin/gistt-tap
   brew install gistt
   ```

## Updating dependencies

When dependency versions change:

1. Update `../gistt-tap/packaging/brew/requirements.lock` (regenerate by reinstalling in a clean virtualenv and freezing).
2. Run `python ../gistt-tap/packaging/brew/update_resources.py` and paste the output into the formula (again keeping the platform overrides).
3. Verify with `brew install --build-from-source ../gistt-tap/Formula/gistt.rb`.
