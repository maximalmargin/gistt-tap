# gistt

Source repos of [gistt-tap](https://github.com/maximalmargin/gistt-tap).

## Run from source (local dev)

`PYTHONPATH=src python -m gistt.ui.cli`

## Configuration

- `gistt` ships default behavior in `data/settings.json` inside the package. Provide user overrides by placing a `settings.json` in `~/.config/gistt/` (respects `XDG_CONFIG_HOME`).
- On first run `gistt` writes a copy of the packaged defaults to `~/.config/gistt/settings.json` so you can tweak preferences without hunting for the template.
- Cached summaries include the action group priority as it existed when they were generated; if you change priorities, run `rm ~/.local/share/gistt/gistt_cache.json` to rebuild with the new ordering.
- Set `GISTT_SETTINGS_PATH` to point at a custom settings file when you need per-invocation overrides or alternate locations.
- Homebrew installs can drop a shared config at `$(brew --prefix)/etc/gistt/settings.json`; this becomes the fallback when no user override exists.
- OAuth client secrets live at `~/.config/gistt/client_secret.json` and account tokens at `~/.local/share/gistt/accounts/`.

## System Components

- **UI surface** lives in the Rich-based CLI (`src/gistt/ui/*`). Views such as `WelcomeView`, `TableView`, and `ThreadView` translate domain objects into layout primitives, own key handling, and never touch persistence or network APIs directly.

- **Gmail domain** owns account management, OAuth, thread fetching, and label mutations. The pieces live under `src/gistt/services/gmail_accounts.py` and `src/gistt/services/gmail_ops.py`, emitting `EmailMessage` + `EmailContext`.

- **gistt domain** centers on models, settings, and cached results. `GisttProducer` coordinates GenAI calls, while `GisttCacheStore` persists summaries and states.

- **GenAI integration** (Gemini today) turns email threads into `ActionGroupRec` plus summary text through `GisttProducer`, which wraps `GenAIOps`.

- **Cross-cutting utilities** (settings, helpers) sit at the edges and depend only on public interfaces, keeping each domain replaceable.

See `TODO.md` for the full backlog. PRs welcome.
