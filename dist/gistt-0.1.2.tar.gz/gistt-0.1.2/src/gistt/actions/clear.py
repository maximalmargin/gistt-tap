"""Clear action - removes cached gistt state from gmail."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from gistt.models import Action, Gistt
from gistt.services.gmail_ops import GmailOps


@dataclass(frozen=True)
class ClearAction(Action):
    """Clears all stored state for a gistt thread."""

    name: str = "clear"
    shortcuts: List[str] = field(default_factory=lambda: ["z"])

    def execute(self, gistt: Gistt, client: GmailOps) -> bool:
        """Remove the gistt label from the associated gmail thread."""
        if client is None or gistt is None:
            return False

        email = getattr(gistt, "email_message", None)
        if email is None:
            return False

        thread_id = email.thread_id(allow_message_fallback=True)
        if not thread_id:
            return False

        account_email = email.account_email()
        return client.modify_thread_labels(
            account_email=account_email,
            thread_id=thread_id,
            add_labels=list(self.labels_to_add),
            remove_labels=list(self.labels_to_remove),
        )

    @property
    def labels_to_add(self) -> tuple[str, ...]:
        """Restore the thread to the inbox and mark it unread."""
        return ("INBOX", "UNREAD")

    @property
    def labels_to_remove(self) -> tuple[str, ...]:
        return ("gistt",)
