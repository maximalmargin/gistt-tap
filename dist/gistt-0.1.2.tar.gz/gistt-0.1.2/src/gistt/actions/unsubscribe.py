"""Unsubscribe action - handles list unsubscribe flows and archives the thread."""
from __future__ import annotations

from dataclasses import dataclass, field
from email.utils import parseaddr
from typing import List, Optional
import logging

from gistt.models import Action, Gistt
from gistt.services.gmail_ops import GmailOps

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class UnsubscribeAction(Action):
    """Unsubscribe and archive the current gistt thread."""

    name: str = "unsubscribe"
    shortcuts: List[str] = field(default_factory=lambda: ["u"])
    _last_method: str = field(default="", init=False, repr=False, compare=False)

    def execute(self, gistt: Gistt, client: GmailOps) -> bool:
        if client is None or gistt is None:
            return False

        email = getattr(gistt, "email_message", None)
        if email is None:
            log.debug("Unsubscribe action aborted: gistt missing email message.")
            return False

        account_email = email.account_email()
        message_id = getattr(email, "id", None)
        if not message_id:
            log.debug("Unsubscribe action aborted: email missing message id.")
            return False

        thread_id = email.thread_id()
        if not thread_id:
            log.debug("Unsubscribe action aborted: unable to resolve thread id.")
            return False

        self._record_method(None)
        log.debug(
            "Attempting standard unsubscribe message_id=%s account=%s",
            message_id,
            account_email or "<default>",
        )
        unsubscribed = client.perform_list_unsubscribe(account_email=account_email, message_id=message_id)
        if unsubscribed:
            method_label = "standard unsubscribe"
        else:
            sender_address = self._sender_address(email.sender)
            if not sender_address:
                log.debug("Unsubscribe fallback aborted: unable to resolve sender address for filter creation.")
                return False

            log.debug(
                "Attempting auto-archive filter creation for sender=%s account=%s",
                sender_address,
                account_email or "<default>",
            )
            unsubscribed = client.create_auto_archive_filter(account_email=account_email, sender=sender_address)
            if not unsubscribed:
                return False
            method_label = "auto-archive filter"

        archived = self._archive_thread(client, account_email=account_email, thread_id=thread_id)
        if not archived:
            log.debug("Unsubscribe succeeded but archiving thread %s failed.", thread_id)
            self._record_method(None)
            return False

        self._record_method(method_label)
        return True

    def _archive_thread(self, client: GmailOps, *, account_email: Optional[str], thread_id: str) -> bool:
        return client.modify_thread_labels(
            account_email=account_email,
            thread_id=thread_id,
            add_labels=list(self.labels_to_add),
            remove_labels=list(self.labels_to_remove),
        )

    def _sender_address(self, raw_sender: Optional[str]) -> Optional[str]:
        if not raw_sender:
            return None
        _, address = parseaddr(raw_sender)
        normalized = address.strip()
        return normalized or None

    @property
    def labels_to_remove(self) -> tuple[str, ...]:
        """Match archive behavior by removing inbox and unread markers."""
        return ("INBOX", "UNREAD")

    @property
    def execution_detail(self) -> Optional[str]:
        detail = getattr(self, "_last_method", "")
        normalized = detail.strip()
        return normalized or None

    def _record_method(self, label: Optional[str]) -> None:
        object.__setattr__(self, "_last_method", (label or "").strip())
