"""Reply action - drafts an AI-generated reply to a thread."""
from __future__ import annotations

from dataclasses import dataclass, field
from email.utils import parseaddr
from typing import ClassVar, List, Optional, Tuple
import json
import logging

from gistt.models import Action, DraftRequest, EmailMessage, Gistt
from gistt.services.gmail_ops import GmailOps
from gistt.services.genai_ops import GenAIOps

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class ReplyAction(Action):
    """Drafts an AI-generated reply to a gistt thread."""

    DEFAULT_INSTRUCTIONS: ClassVar[str] = (
        "Compose a concise, professional reply that acknowledges the sender and proposes sensible next steps."
    )
    name: str = "reply"
    shortcuts: List[str] = field(default_factory=lambda: ["r"])

    def execute(self, gistt: Gistt, client: GmailOps) -> bool:
        """Generate a reply draft and create it via gmail."""
        if client is None or gistt is None:
            return False

        email = getattr(gistt, "email_message", None)
        if email is None:
            return False

        draft_request = self.suggest_reply(email, "")
        if draft_request is None:
            return False

        result = client.create_draft(
            request=draft_request,
            account_email=email.account_email(),
        )
        return result is not None

    @staticmethod
    def _build_prompt(*, email: EmailMessage, guidance: str) -> str:
        body_value = getattr(email, "body", "") or ""
        body_text = body_value.strip() if body_value else "(no body provided)"
        subject_value = getattr(email, "subject", "") or "(No subject)"
        sender_value = getattr(email, "sender", "") or "Unknown sender"
        date_value = getattr(email, "time", "") or getattr(email, "date", "") or "(unknown)"
        prompt = (
            "You are an expert email drafting assistant.\n"
            "Review the latest message details and craft a polished reply.\n\n"
            f"Subject: {subject_value}\n"
            f"From: {sender_value}\n"
            f"Date: {date_value}\n"
            f"Body:\n{body_text}\n\n"
            f"Instructions: {guidance}\n\n"
            "Respond with strict JSON (no markdown, no commentary) with keys "
            '"subject" and "body".'
        )
        return prompt

    @staticmethod
    def _generate_text(prompt: str) -> Optional[str]:
        """Generate text using the configured genAI service."""
        try:
            ops = GenAIOps()
            text = ops.generate(prompt)
            return text
        except Exception:  # noqa: BLE001
            log.exception("Failed to generate draft reply text.")
            return None

    @staticmethod
    def _parse_reply_json(text: str) -> Tuple[Optional[str], Optional[str]]:
        """Parse the JSON payload returned by the model."""
        candidate = text.strip()
        if candidate.startswith("```"):
            candidate = candidate.strip("`").strip()
            if candidate.lower().startswith("json"):
                candidate = candidate[4:].strip()

        try:
            payload = json.loads(candidate)
        except json.JSONDecodeError:
            log.debug("Model response was not valid JSON.")
            return None, None

        if not isinstance(payload, dict):
            log.debug("Model response payload was not a JSON object.")
            return None, None

        subject = payload.get("subject")
        body = payload.get("body")
        return subject, body

    @staticmethod
    def _extract_email_address(sender: str) -> str:
        """Return the email component from a sender header."""
        _, address = parseaddr(sender or "")
        return address

    @classmethod
    def suggest_reply(cls, email: EmailMessage, instructions: str) -> Optional[DraftRequest]:
        """Generate a draft reply for the supplied email message."""
        if email is None:
            return None

        guidance = instructions.strip()
        if not guidance:
            guidance = cls.DEFAULT_INSTRUCTIONS

        prompt = cls._build_prompt(email=email, guidance=guidance)
        response_text = cls._generate_text(prompt)
        if not response_text:
            log.debug("No text generated for reply suggestion; aborting.")
            return None

        subject, body = cls._parse_reply_json(response_text)
        if not body:
            log.debug("Could not parse body from generation response; aborting.")
            return None

        subject_value = getattr(email, "subject", "") or "(No subject)"
        subject_line = subject.strip() if subject else subject_value
        if subject_line and not subject_line.lower().startswith("re:"):
            subject_line = f"Re: {subject_line}"

        sender_value = getattr(email, "sender", "") or ""
        to_address = cls._extract_email_address(sender_value) or sender_value

        return DraftRequest(
            to=to_address,
            subject=subject_line or f"Re: {subject_value}",
            body=body.strip(),
            thread_id=email.thread_id(allow_message_fallback=True),
        )
