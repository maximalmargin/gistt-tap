"""Layout builder."""

import select
import sys
import termios
import tty
from typing import Optional

from rich import box
from rich.layout import Layout
from rich.panel import Panel
import os
import select

EMPTY_PANEL = Panel("", box=box.SIMPLE)
_CONTROL_KEY_MAP = {
    "\x08": "backspace",
    "\t": "tab",
    "\x0e": "ctrl+n",  # Ctrl+N / next line
    "\x10": "ctrl+p",  # Ctrl+P / previous line
    "\x7f": "backspace",   # DEL
    "\x03": "ctrl-c",
    "\x04": "ctrl-d",
    "\x1a": "ctrl-z",
    "\x0c": "ctrl-l",    
}

def build_layout(
    header_renderable,
    body_renderable,
    footer_renderable,
    spacer_size: int = 2,
    header_size: int = 5,
    body_ratio: int = 1,
    footer_size: int = 4,
) -> Layout:
    layout = Layout()
    sections = []
    if spacer_size > 0:
        sections.append(Layout(name="spacer", size=spacer_size))
    sections.extend(
        [
            Layout(name="header", size=header_size),
            Layout(name="body", ratio=body_ratio),
            Layout(name="footer", size=footer_size),
        ],
    )
    layout.split(*sections)

    if spacer_size > 0:
        layout["spacer"].update(EMPTY_PANEL)
    layout["header"].update(header_renderable)
    layout["body"].update(body_renderable)
    layout["footer"].update(footer_renderable)
    return layout


# Common escape-sequence map (CSI and SS3/application mode)
_ESC_SEQ_MAP = {
    b"\x1b[A": "up",     b"\x1bOA": "up",
    b"\x1b[B": "down",   b"\x1bOB": "down",
    b"\x1b[C": "right",  b"\x1bOC": "right",
    b"\x1b[D": "left",   b"\x1bOD": "left",
    b"\x1b[H": "home",   b"\x1bOH": "home",
    b"\x1b[F": "end",    b"\x1bOF": "end",
    b"\x1b[3~": "delete",
    b"\x1b[2~": "insert",
    b"\x1b[5~": "pageup",
    b"\x1b[6~": "pagedown",
}

def _read_ready(fd, timeout: Optional[float]) -> bool:
    while True:
        try:
            r, _, _ = select.select([fd], [], [], timeout)
            return bool(r)
        except InterruptedError:
            continue

def _read_byte(fd) -> bytes:
    while True:
        try:
            b = os.read(fd, 1)  # non-buffered, works with select on fd
            return b
        except InterruptedError:
            continue

def read_key(*, timeout: Optional[float] = None) -> Optional[str]:
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)  # disables canonical/echo; we get raw bytes
        # wait for first byte (or timeout)
        if timeout is not None and not _read_ready(fd, timeout):
            return None

        b = _read_byte(fd)
        if not b:
            return None

        ch = b.decode(errors="ignore")

        # Enter
        if ch in ("\r", "\n"):
            return "enter"

        # Single-byte control keys
        if ch in _CONTROL_KEY_MAP:
            return _CONTROL_KEY_MAP[ch]

        # ESC: could be bare ESC or start of an escape sequence
        if b == b"\x1b":
            seq = b
            # small window to collect the rest of the sequence
            # short but generous enough for a full CSI like \x1b[3~
            while _read_ready(fd, 0.01):  # 10ms chunks
                seq += _read_byte(fd)
                # fast-path: check if we already match a known sequence
                if seq in _ESC_SEQ_MAP:
                    return _ESC_SEQ_MAP[seq]
                # also break out if it looks like a complete CSI token
                if seq.startswith(b"\x1b[") and (seq.endswith(b"~") or (len(seq) >= 3 and seq[-1:] in b"ABCDHF")):
                    return _ESC_SEQ_MAP.get(seq, "unknown")
                # SS3 (application) sequences are short: ESC O X
                if seq.startswith(b"\x1bO") and len(seq) == 3:
                    return _ESC_SEQ_MAP.get(seq, "unknown")

            # nothing else arrived -> it was a bare ESC press
            return "escape"

        # Printable alnum
        if ch.isalnum():
            return ch

        # Space and common punctuation
        if ch and ch.isprintable():
            return ch

        # Ignore anything else
        return None

    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)