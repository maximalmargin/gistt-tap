"""Welcome view."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Optional

from rich.align import Align
from rich.console import Group
from rich.panel import Panel
from rich.text import Text
from rich.live import Live
from rich.layout import Layout
from rich.table import Table
from rich import box

from gistt.ui.base import View
from gistt.ui.layout import build_layout, read_key
from gistt.ui.palette import Palette
from gistt.controller.session_state import SessionStateStore
from gistt.controller.welcome_controller import SupportsWelcomeAccounts, WelcomeController
from gistt.services.gmail_accounts import AccountConfig


@dataclass
class WelcomeView(View):
    account_manager: SupportsWelcomeAccounts = field(repr=False)
    session_store: Optional[SessionStateStore] = field(
        default=None, repr=False)
    choice: str = field(default="")
    controller: WelcomeController = field(init=False, repr=False)

    def __post_init__(self) -> None:
        if self.session_store is None:
            self.session_store = SessionStateStore()
        self.status_message = ""
        self.controller = WelcomeController(
            account_manager=self.account_manager,
            session_store=self.session_store,
        )

    def render(
        self,
        current_account: Optional[AccountConfig],
        multi_account_mode: bool,
        live_factory: Optional[Callable[..., Live]] = None,
    ) -> tuple[Optional[AccountConfig], bool, bool]:

        accounts = self.account_manager.list_accounts()
        no_accounts = not accounts
        current_email = current_account.email.lower() if current_account else ""

        selection_index: Optional[int] = None
        if accounts:
            if multi_account_mode:
                selection_index = len(accounts)
            elif current_account:
                for idx, account in enumerate(accounts):
                    if account.email.lower() == current_email:
                        selection_index = idx
                        break
            if selection_index is None:
                selection_index = 0

        selection_count = len(accounts) + (1 if accounts else 0)

        def _selection_label(index: Optional[int]) -> str:
            if index is None:
                return ""
            if index < len(accounts):
                return accounts[index].email
            if index == len(accounts):
                return "all accounts"
            return ""

        def _selection_choice(index: Optional[int]) -> Optional[str]:
            if index is None:
                return None
            if index < len(accounts):
                return str(index + 1)
            if index == len(accounts):
                return "a"
            return None

        footer_message = (
            "◦ no accounts linked • l link • q quit"
            if no_accounts else
            "▸ select account • l link • q quit"
        )

        def _build_layout(error: Optional[str] = None) -> Layout:
            header = self._build_header()
            body = self._build_body(
                accounts=accounts,
                current_email=current_email,
                multi_account_mode=multi_account_mode,
                selected_index=selection_index,
                error=error,
            )
            footer = self._build_footer(footer_message)
            return build_layout(header_renderable=header, body_renderable=body, footer_renderable=footer)

        last_size = self.console.size

        with live_factory(_build_layout(), console=self.console, refresh_per_second=6, transient=False, auto_refresh=True) as live:
            error_msg: Optional[str] = None
            while True:
                accounts = self.account_manager.list_accounts()
                selection_count = len(accounts) + (1 if accounts else 0)
                if selection_count == 0:
                    selection_index = None
                else:
                    if selection_index is None:
                        selection_index = 0
                    selection_index %= selection_count

                if error_msg:
                    live.update(_build_layout(error_msg))
                    error_msg = None
                live.stop()
                choice: Optional[str] = None
                while choice is None:
                    choice = read_key(timeout=0.1)
                    if choice is not None:
                        break

                    size = self.console.size
                    if size != last_size:
                        last_size = size
                        live.start(refresh=True)
                        live.update(_build_layout(error_msg))
                        live.stop()

                self.choice = choice or ""
                self.status_message = f"You pressed {choice}" if choice else ""
                live.start(refresh=True)

                normalized_choice = choice.lower() if choice else ""

                navigation_handled = False
                if selection_count and choice:
                    if normalized_choice in ("down", "j", "ctrl+n", "n"):
                        selection_index = ((selection_index or 0) + 1) % selection_count
                        navigation_handled = True
                    elif normalized_choice in ("up", "k", "ctrl+p"):
                        selection_index = ((selection_index or 0) - 1) % selection_count
                        navigation_handled = True

                if navigation_handled:
                    selection_desc = _selection_label(selection_index)
                    if selection_desc:
                        self.status_message = f"selected {selection_desc}"
                    live.update(_build_layout(error_msg))
                    continue

                if not choice:
                    return current_account, multi_account_mode, True

                if choice == "enter":
                    selection_choice = _selection_choice(selection_index)
                    if selection_choice is not None:
                        choice = selection_choice
                        normalized_choice = choice.lower()

                outcome = self.controller.handle_choice(
                    choice=choice,
                    current_account=current_account,
                    multi_account_mode=multi_account_mode,
                    no_accounts=no_accounts,
                )

                if outcome.error:
                    error_msg = outcome.error
                    continue

                if outcome.handled:
                    return outcome.selection, outcome.multi_account_mode, outcome.should_continue

                error_msg = "unknown account. enter a valid number, email, or 'l'."

    def _build_header(self) -> Panel:
        title = Text("gistt", style=f"bold {Palette.PRIMARY}")
        subtitle = Align.center(
            Text(
                "\"Don't confuse motion with progress.\" Spend less time on email and get more done.",
                style="white",
            )
        )
        return Panel(
            subtitle,
            title=title,
            border_style=Palette.PRIMARY,
            padding=(1, 1),
            box=box.SIMPLE,
        )

    def _build_body(
        self,
        accounts: list[AccountConfig],
        current_email: str,
        multi_account_mode: bool,
        selected_index: Optional[int],
        error: Optional[str] = None,
    ) -> Panel:
        table = Table(
            show_header=True,
            header_style=f"bold {Palette.PRIMARY}",
            box=box.SIMPLE_HEAD,
            expand=True,
        )
        table.add_column("#", justify="right", width=3)
        table.add_column("email", overflow="fold")
        table.add_column("last used", justify="center", width=9)

        for idx, account in enumerate(accounts, start=1):
            is_current = account.email.lower() == current_email and not multi_account_mode
            is_selected = selected_index == (idx - 1)
            if is_selected:
                email_cell = Text(account.email, style="reverse")
            else:
                email_cell = account.email
            table.add_row(str(idx), email_cell,
                          f"[{Palette.GREEN}]*[/{Palette.GREEN}]" if is_current else "")

        if accounts:
            all_index = len(accounts)
            all_accounts_cell = Text(
                "all accounts", style="reverse") if selected_index == all_index else "all accounts"
            table.add_row("a", all_accounts_cell,
                          f"[{Palette.GREEN}]*[/{Palette.GREEN}]" if multi_account_mode else "")

        body = [table]
        if error:
            body.append(Text(error, style="bold red"))

        return Panel(Group(*body), title="Linked Gmail Accounts",
                     box=box.SIMPLE_HEAVY, padding=(0, 0))

    def _build_footer(self, prompt_message: str) -> Panel:
        return Panel(
            Group(
                Text(prompt_message, style=Palette.PRIMARY),
                Text(self.status_message, style="dim")),
            padding=(0, 0),
            box=box.SIMPLE,
        )
