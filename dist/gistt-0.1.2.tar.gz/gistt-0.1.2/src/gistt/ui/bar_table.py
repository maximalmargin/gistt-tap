"""Helpers for rendering the pagination meter in the table view."""
from __future__ import annotations

import math
from dataclasses import dataclass

from rich.text import Text

from gistt.ui.palette import Palette

@dataclass
class BarTable:
    """Neon styled meter showing the visible slice within the full result set."""

    width: int = 24

    def render(self, *, start: int, end: int, total: int, selection: int | None = None) -> Text:
        """Return a Rich Text bar marking the active window."""
        if total <= 0 or end <= start:
            return Text("")

        span = max(1, total)
        per_unit = self.width / span
        highlight_start = math.floor(per_unit * start)
        highlight_length = max(1, math.ceil(per_unit * (end - start)))
        highlight_end = highlight_start + highlight_length
        highlight_start = max(0, min(self.width - 1, highlight_start))
        highlight_end = max(highlight_start + 1, min(self.width, highlight_end))

        filled_segment = f"[bold {Palette.GREEN}]█[/]"
        empty_segment = f"[dim {Palette.BACKGROUND}]░[/]"
        selection_segment = f"[bold {Palette.YELLOW}]▒[/]"
        if selection is None:
            selection = start
        selection_index = max(0, min(selection, total - 1))
        window_size = max(1, end - start)
        highlight_span = max(1, highlight_end - highlight_start)

        if window_size == 1 or selection_index <= start:
            selection_unit = highlight_start
        elif selection_index >= end - 1:
            selection_unit = highlight_end - 1
        else:
            relative = (selection_index - start) / max(1, window_size - 1)
            selection_unit = highlight_start + int(round(relative * (highlight_span - 1)))

        selection_unit = max(highlight_start, min(highlight_end - 1, selection_unit))
        highlight = set(range(highlight_start, highlight_end))
        interior = []
        for idx in range(self.width):
            if idx == selection_unit:
                interior.append(selection_segment)
            elif idx in highlight:
                interior.append(filled_segment)
            else:
                interior.append(empty_segment)
        bar_markup = f"[bold {Palette.PINK}]■[/]" + "".join(interior) + f"[bold {Palette.PINK}]■[/]"
        current = max(0, min(selection, total - 1)) + 1
        digits = max(2, len(str(total)))
        count_markup = (
            f"[bold {Palette.PRIMARY}]{current:0{digits}d}[/]"
            f"[dim {Palette.YELLOW}]/[/]"
            f"[bold {Palette.YELLOW}]{total:0{digits}d}[/]"
        )
        return Text.from_markup(f"{bar_markup}  {count_markup}")
