"""Session state persistence for the CLI."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional
import json
import threading


STATE_DIR = Path.home() / ".local" / "share" / "gistt"


SESSION_STATE_FILE = STATE_DIR / "cli_session.json"

@dataclass
class TableState:
    selected_index: int = 0

@dataclass(frozen=True)
class SessionState:
    active_account_email: Optional[str] = None
    multi_account_mode: bool = False
    table_state: TableState = field(default_factory=TableState)

class SessionStateStore:
    """Persisted CLI session state."""

    def __init__(self, path: Path = SESSION_STATE_FILE) -> None:
        self._path = path
        self._lock = threading.RLock()
        self._state: SessionState = self._load()

    def load(self) -> SessionState:
        """Return the last persisted session state."""
        with self._lock:
            return self._state

    def save(self, state: SessionState) -> SessionState:
        """Persist the provided session state to disk."""
        with self._lock:
            self._state = state
            target_dir = self._path.parent if self._path else STATE_DIR
            target_dir.mkdir(parents=True, exist_ok=True)
            payload = asdict(state)
            self._path.write_text(json.dumps(payload, indent=2))
            return self._state

    def update(
        self,
        *,
        active_account_email: Optional[str],
        multi_account_mode: bool,
        table_state: Optional[TableState] = None,
    ) -> SessionState:
        """Persist a new session snapshot with the given values."""
        with self._lock:
            current = self._state
            next_table_state = table_state or getattr(current, "table_state", TableState())
            state = SessionState(
                active_account_email=active_account_email,
                multi_account_mode=multi_account_mode,
                table_state=next_table_state,
            )
            return self.save(state)

    def _load(self) -> SessionState:
        if not self._path.exists():
            return SessionState()
        try:
            payload = json.loads(self._path.read_text())
        except (json.JSONDecodeError, OSError):
            return SessionState()

        email = payload.get("active_account_email")
        if not isinstance(email, str) or not email.strip():
            email = None

        multi_mode = payload.get("multi_account_mode")
        if not isinstance(multi_mode, bool):
            multi_mode = False

        table_payload = payload.get("table_state")
        if isinstance(table_payload, dict):
            selected_index = table_payload.get("selected_index", 0)
            if not isinstance(selected_index, int) or selected_index < 0:
                selected_index = 0
        else:
            selected_index = 0

        return SessionState(
            active_account_email=email,
            multi_account_mode=multi_mode,
            table_state=TableState(selected_index=selected_index),
        )
