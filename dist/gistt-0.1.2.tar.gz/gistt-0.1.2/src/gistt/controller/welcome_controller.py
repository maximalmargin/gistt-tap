"""Controller for handling interactions in the welcome view."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Protocol

from gistt.controller.session_state import SessionStateStore
from gistt.services.gmail_accounts import AccountConfig


class SupportsWelcomeAccounts(Protocol):
    """Protocol describing the account operations consumed by the welcome flow."""

    def list_accounts(self) -> list[AccountConfig]:
        ...

    def link_account(self) -> Optional[AccountConfig]:
        ...


@dataclass
class WelcomeChoiceResult:
    """Structured response describing the outcome of a welcome choice."""

    handled: bool
    selection: Optional[AccountConfig]
    multi_account_mode: bool
    should_continue: bool
    error: Optional[str]


@dataclass
class WelcomeController:
    """Encapsulates the decision logic for the welcome view."""

    account_manager: SupportsWelcomeAccounts
    session_store: SessionStateStore

    def handle_choice(
        self,
        *,
        choice: str,
        current_account: Optional[AccountConfig],
        multi_account_mode: bool,
        no_accounts: bool,
    ) -> WelcomeChoiceResult:
        """Process a normalized user choice and return the resulting state."""
        if choice == "enter":
            return WelcomeChoiceResult(True, current_account, multi_account_mode, True, None)

        if choice == "q":
            return WelcomeChoiceResult(True, None, False, False, None)

        if choice == "a":
            if no_accounts:
                message = "No accounts linked yet. Link an account first."
                return WelcomeChoiceResult(False, current_account, multi_account_mode, True, message)
            result = WelcomeChoiceResult(True, current_account, True, True, None)
            self._persist_session(selection=current_account, multi_account_mode=True)
            return result

        if choice == "l":
            linked = self.account_manager.link_account()
            if linked is None:
                failure_message = (
                    "Account linking failed. Confirm your OAuth credentials file exists and the flow completes."
                )
                return WelcomeChoiceResult(False, current_account, multi_account_mode, True, failure_message)
            self._persist_session(selection=linked, multi_account_mode=False)
            return WelcomeChoiceResult(True, linked, False, True, None)

        accounts = self.account_manager.list_accounts()

        if choice.isdigit():
            idx = int(choice) - 1
            if 0 <= idx < len(accounts):
                selected = accounts[idx]
                self._persist_session(selection=selected, multi_account_mode=False)
                return WelcomeChoiceResult(True, selected, False, True, None)

        selected = next(
            (
                acct
                for acct in accounts
                if acct.email.lower() == choice
            ),
            None,
        )
        if selected:
            self._persist_session(selection=selected, multi_account_mode=False)
            return WelcomeChoiceResult(True, selected, False, True, None)

        error = "Unknown account. Enter a valid number, email, or 'l'."
        return WelcomeChoiceResult(False, current_account, multi_account_mode, True, error)

    def _persist_session(
        self,
        *,
        selection: Optional[AccountConfig],
        multi_account_mode: bool,
    ) -> None:
        """Persist the current selection or multi-account preference."""
        active_email: Optional[str] = None
        if not multi_account_mode and selection is not None:
            active_email = selection.email
        self.session_store.update(
            active_account_email=active_email,
            multi_account_mode=multi_account_mode,
        )
