"""Settings loader."""

from __future__ import annotations

from typing import Any, List
from collections.abc import Mapping
from dataclasses import dataclass, field
from importlib import resources
from pathlib import Path
import copy
import json
import logging
import os

logger = logging.getLogger(__name__)

from gistt.models import ActionGroup

_SETTINGS_ENV_VAR = "GISTT_SETTINGS_PATH"


@dataclass(frozen=True)
class Preferences:
    recency_cutoff_days: int = 10
    summary_workers: int = 3
    default_fetch_size: int = 4


@dataclass
class Settings:
    action_groups: List[ActionGroup] = field(default_factory=list)
    preferences: Preferences = field(default_factory=Preferences)
    _settings: Mapping[str, Any] = field(init=False, repr=False, default_factory=dict)
    _settings_source: Path | None = field(init=False, repr=False, default=None)

    _SETTINGS_PATH = "data/settings.json"

    def __post_init__(self) -> None:
        payload, override_source = self._load_settings_payload()
        self._settings = payload
        self._settings_source = override_source
        self.action_groups = self._parse_action_groups(payload)
        self.preferences = self._parse_preferences(payload)

    def _load_settings_payload(self) -> tuple[Mapping[str, Any], Path | None]:
        defaults = self._load_default_payload()
        created_template = _ensure_user_settings_template(defaults)
        overrides, source = self._load_override_payload(
            skip_paths={created_template} if created_template else None
        )
        if overrides:
            merged = _merge_settings(defaults, overrides)
            return merged, source
        return defaults, None

    def _load_default_payload(self) -> Mapping[str, Any]:
        with resources.files("gistt").joinpath(self._SETTINGS_PATH).open("r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, Mapping) else {}

    def _load_override_payload(
        self, *, skip_paths: set[Path] | None = None
    ) -> tuple[Mapping[str, Any], Path | None]:
        for candidate in _settings_override_paths():
            if skip_paths and candidate in skip_paths:
                continue
            try:
                if not candidate.is_file():
                    continue
            except OSError as exc:
                logger.debug("Skipping override candidate %s: %s", candidate, exc)
                continue

            try:
                with candidate.open("r", encoding="utf-8") as handle:
                    data = json.load(handle)
            except (OSError, json.JSONDecodeError) as exc:
                logger.warning("Failed to load settings override %s: %s", candidate, exc)
                continue

            if not isinstance(data, Mapping):
                logger.warning("Override settings at %s was not a mapping; ignoring", candidate)
                continue

            logger.debug("Loaded settings overrides from %s", candidate)
            return data, candidate

        return {}, None
    
    def _parse_action_groups(self, data: Mapping[str, Any]) -> List[ActionGroup]:
        try:
            action_groups = data.get("action_groups")
            if isinstance(action_groups, List):
                return [ActionGroup(**action_group) for action_group in action_groups]
            return []
        except (KeyError, TypeError, ValueError) as e:
            logger.warning("Failed to parse action groups: %s", e)
            return []
    
    def _parse_preferences(self, data: Mapping[str, Any]) -> Preferences:
        try:
            preferences = data.get("preferences")
            if isinstance(preferences, Mapping):
                return Preferences(**preferences)
            return Preferences()
        except (KeyError, TypeError, ValueError) as e:
            logger.warning("Failed to parse preferences: %s", e)
            return Preferences()

    def group_for_name(self, name: str) -> ActionGroup | None:
        """Return the configured action group matching the provided display name."""
        normalized = (name or "").strip().lower()
        if not normalized:
            return None
        for action_group in self.action_groups:
            if action_group.group.strip().lower() == normalized:
                return action_group

        fallbacks = {
            "waiting on reply": {
                "group": "Waiting on Reply",
                "action": "read",
                "condition": "Use when you're awaiting a response from someone else and need to keep the thread handy.",
                "instruction": "Summarize outstanding follow-up needs in under 15 words.",
                "priority": 20,
            },
        }
        definition = fallbacks.get(normalized)
        if definition:
            return ActionGroup(**definition)
        return None


def _settings_override_paths() -> list[Path]:
    """Return candidate override paths ordered by precedence."""
    candidates: list[Path] = []

    env_path = os.environ.get(_SETTINGS_ENV_VAR)
    if env_path:
        candidates.append(Path(env_path).expanduser())

    candidates.append(_user_settings_path())

    brew_prefix = os.environ.get("HOMEBREW_PREFIX")
    if brew_prefix:
        candidates.append(Path(brew_prefix) / "etc" / "gistt" / "settings.json")

    candidates.extend(
        [
            Path("/opt/homebrew/etc/gistt/settings.json"),
            Path("/usr/local/etc/gistt/settings.json"),
        ]
    )

    unique: list[Path] = []
    seen: set[Path] = set()
    for path in candidates:
        normalized = path.expanduser()
        if normalized in seen:
            continue
        seen.add(normalized)
        unique.append(normalized)
    return unique


def _merge_settings(defaults: Mapping[str, Any], overrides: Mapping[str, Any]) -> dict[str, Any]:
    """Merge user overrides into default settings, preserving nested mappings."""
    merged: dict[str, Any] = copy.deepcopy(dict(defaults))
    for key, value in overrides.items():
        existing = merged.get(key)
        if isinstance(existing, Mapping) and isinstance(value, Mapping):
            merged[key] = {**dict(existing), **dict(value)}
            continue
        merged[key] = value
    return merged


_SETTINGS_SINGLETON: Settings | None = None


def _user_settings_path() -> Path:
    config_home = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    return (config_home / "gistt" / "settings.json").expanduser()


def _ensure_user_settings_template(defaults: Mapping[str, Any]) -> Path | None:
    """Ensure a writable user settings file exists for easy customization.

    Returns the path if a new template was written, otherwise ``None``.
    """
    user_path = _user_settings_path()
    try:
        if user_path.exists():
            return None
        user_path.parent.mkdir(parents=True, exist_ok=True)
        with user_path.open("w", encoding="utf-8") as handle:
            handle.write(_render_settings_template(defaults))
        logger.debug("Created default settings template at %s", user_path)
        return user_path
    except OSError as exc:
        logger.debug("Unable to create user settings template at %s: %s", user_path, exc)
    return None


def _render_settings_template(defaults: Mapping[str, Any]) -> str:
    action_groups = defaults.get("action_groups") or []
    preferences = defaults.get("preferences") or {}

    def _render_group(index: int, group: Mapping[str, Any]) -> str:
        lines = [
            "    {",
            f'      "group": {json.dumps(group.get("group", ""))},',
            f'      "action": {json.dumps(group.get("action"))},',
            f'      "condition": {json.dumps(group.get("condition", ""))},',
            f'      "instruction": {json.dumps(group.get("instruction", ""))},',
            f'      "priority": {int(group.get("priority", 100))}',
            "    }",
        ]
        if index < len(action_groups) - 1:
            lines[-1] += ","
        return "\n".join(lines)

    groups_block = ""
    if isinstance(action_groups, list):
        rendered_groups = [
            _render_group(idx, group) for idx, group in enumerate(action_groups) if isinstance(group, Mapping)
        ]
        groups_block = "[\n" + "\n".join(rendered_groups) + "\n  ]" if rendered_groups else "[]"
    preferences_block = json.dumps(preferences, indent=4, sort_keys=False) if isinstance(preferences, Mapping) else "{}"
    return "{\n  \"action_groups\": " + groups_block + ",\n  \"preferences\": " + preferences_block + "\n}\n"


def get_settings() -> Settings:
    """Return a cached Settings instance, constructing it on first use."""
    global _SETTINGS_SINGLETON
    if _SETTINGS_SINGLETON is None:
        _SETTINGS_SINGLETON = Settings()
    return _SETTINGS_SINGLETON


def reset_settings_cache() -> None:
    """Clear the cached Settings instance (intended for tests)."""
    global _SETTINGS_SINGLETON
    _SETTINGS_SINGLETON = None
