"""Gmail account management."""
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Sequence, Dict, Any
import base64, hashlib, json, logging, os, time

from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import InstalledAppFlow

log = logging.getLogger(__name__)

APP_NAME = "gistt"
ROOT = Path.home() / ".local" / "share" / APP_NAME / "accounts"
META_FILE = "meta.json"
TOKEN_FILE = "token.json"
CLIENT_FILE = "client_secret.json"
CURRENT_LINK = ROOT.parent / "current"  # ~/.local/share/gistt/current -> accounts/<acctdir>

IDENTITY_SCOPES = (
    "https://www.googleapis.com/auth/userinfo.profile",
    "https://www.googleapis.com/auth/userinfo.email",
    "openid",
)
DEFAULT_SCOPES = (
    "https://www.googleapis.com/auth/gmail.modify",
    *IDENTITY_SCOPES,
)

def _safe_dir_name(email: str, sub: str) -> str:
    base = f"{email}__{sub}"
    h = hashlib.sha1(base.encode()).hexdigest()[:8]
    return base.replace("@", "_at_").replace("/", "_") + f"__{h}"

def _decode_idtoken_payload(id_token: str) -> Dict[str, Any]:
    # No verification required here; google-auth already validated in the flow.
    part = id_token.split(".")[1]
    part += "=" * ((4 - len(part) % 4) % 4)  # pad
    return json.loads(base64.urlsafe_b64decode(part.encode()).decode())

@dataclass(frozen=True)
class AccountConfig:
    id: str                 # stable folder name (email__sub__hash)
    email: str
    sub: str
    scopes: Sequence[str]
    dir: Path               # accounts/<id>/
    client_path: Path       # .../client_secret.json
    token_path: Path        # .../token.json
    meta_path: Path         # .../meta.json

    @staticmethod
    def from_dir(acct_dir: Path) -> Optional["AccountConfig"]:
        meta = acct_dir / META_FILE
        token = acct_dir / TOKEN_FILE
        client = acct_dir / CLIENT_FILE
        if not meta.exists() or not token.exists():
            return None
        try:
            m = json.loads(meta.read_text())
        except Exception:
            return None
        email = str(m.get("email", "")).strip()
        sub = str(m.get("sub", "")).strip()
        scopes = m.get("scopes", list(DEFAULT_SCOPES))
        if not email or not sub:
            return None
        return AccountConfig(
            id=acct_dir.name,
            email=email,
            sub=sub,
            scopes=scopes,
            dir=acct_dir.resolve(),
            client_path=client,
            token_path=token,
            meta_path=meta,
        )

@dataclass
class Token:
    access_token: str
    refresh_token: Optional[str]
    token_uri: str
    client_id: str
    client_secret: Optional[str]
    scopes: Sequence[str]
    expires_at: float  # epoch seconds

    def is_expired(self, skew: int = 60) -> bool:
        return time.time() >= (self.expires_at - skew)

class TokenStore:
    def load(self, cfg: AccountConfig) -> Optional[Token]:
        if not cfg.token_path.exists():
            return None
        try:
            d = json.loads(cfg.token_path.read_text())
            return Token(**d)
        except Exception as e:
            log.warning("Invalid token at %s: %s", cfg.token_path, e)
            return None

    def save(self, cfg: AccountConfig, tok: Token) -> None:
        cfg.token_path.parent.mkdir(parents=True, exist_ok=True)
        cfg.token_path.write_text(json.dumps(tok.__dict__, indent=2))


class GoogleInstalledAppAuth:
    def authorize(self, client_path: Path, scopes: Sequence[str]) -> Credentials:
        flow = InstalledAppFlow.from_client_secrets_file(
            str(client_path), scopes=scopes
        )
        # Let Google pick a free port; also ensures PKCE is used.
        creds = flow.run_local_server(port=0, access_type="offline", include_granted_scopes=False)
        return creds

    def refresh(self, creds: Credentials) -> Credentials:
        creds.refresh(Request())
        return creds


class Account:
    def __init__(self, cfg: AccountConfig, store: TokenStore, auth: GoogleInstalledAppAuth):
        self.cfg, self.store, self.auth = cfg, store, auth

    def ensure_creds(self) -> Credentials:
        # Try loading a google-auth Credentials from our serialized Token
        t = self.store.load(self.cfg)
        if t:
            ga = Credentials(
                token=t.access_token,
                refresh_token=t.refresh_token,
                token_uri=t.token_uri,
                client_id=t.client_id,
                client_secret=t.client_secret,
                scopes=t.scopes,
            )
            if ga.valid:
                return ga
            if ga.expired and ga.refresh_token:
                try:
                    ga = self.auth.refresh(ga)
                    self._persist_google_creds(ga)
                    return ga
                except Exception as e:
                    log.warning("Refresh failed for %s: %s", self.cfg.email, e)

        # No usable creds; interactive auth
        ga = self.auth.authorize(self.cfg.client_path, self.cfg.scopes)
        self._persist_google_creds(ga)
        return ga

    def _persist_google_creds(self, ga: Credentials) -> None:
        # google-auth doesn't expose expires_at directly in to_json; compute it
        expires_at = time.time() + max(0, int(ga.expiry.timestamp() - time.time())) if ga.expiry else time.time() + 3500
        tok = Token(
            access_token=ga.token,
            refresh_token=ga.refresh_token,
            token_uri=ga.token_uri,
            client_id=ga.client_id,
            client_secret=ga.client_secret,
            scopes=tuple(ga.scopes or self.cfg.scopes),
            expires_at=expires_at,
        )
        self.store.save(self.cfg, tok)

    def as_google_credentials(self) -> Credentials:
        return self.ensure_creds()


class AccountManager:
    def __init__(self, root: Path = ROOT):
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)
        CURRENT_LINK.parent.mkdir(parents=True, exist_ok=True)
        self.store = TokenStore()
        self.auth = GoogleInstalledAppAuth()

    def list(self) -> List[AccountConfig]:
        out: List[AccountConfig] = []
        for d in sorted(self.root.iterdir()):
            if d.is_dir():
                cfg = AccountConfig.from_dir(d)
                if cfg:
                    out.append(cfg)
        out.sort(key=lambda c: c.email.lower())
        return out

    def get(self, email: str) -> Optional[AccountConfig]:
        email = email.lower().strip()
        for cfg in self.list():
            if cfg.email.lower() == email:
                return cfg
        return None

    def get_current(self) -> Optional[AccountConfig]:
        # env wins, otherwise symlink, else first account
        env_email = os.getenv("ACTIVE_ACCOUNT", "").strip().lower()
        if env_email:
            c = self.get(env_email)
            if c:
                return c
        if CURRENT_LINK.exists():
            try:
                target = CURRENT_LINK.resolve()
                return AccountConfig.from_dir(target)
            except Exception:
                pass
        lst = self.list()
        return lst[0] if lst else None

    def set_current(self, cfg: AccountConfig) -> None:
        if CURRENT_LINK.exists() or CURRENT_LINK.is_symlink():
            CURRENT_LINK.unlink()
        CURRENT_LINK.symlink_to(cfg.dir)

    def link_account(self, client_path: Path, scopes: Sequence[str] = DEFAULT_SCOPES, set_current: bool = True) -> Optional[AccountConfig]:
        """
        Runs the auth flow, discovers email+sub from ID token, creates account dir, writes meta+token.
        """
        scopes = tuple(dict.fromkeys([*scopes, *IDENTITY_SCOPES]))  # dedupe, preserve order
        flow = InstalledAppFlow.from_client_secrets_file(str(client_path), scopes=scopes)
        creds = flow.run_local_server(port=0, access_type="offline", include_granted_scopes=False)

        email, sub, name = "unknown", "", None
        if creds.id_token:
            payload = _decode_idtoken_payload(creds.id_token)
            email = payload.get("email") or email
            sub = payload.get("sub") or sub
            name = payload.get("name")
        if not sub:
            log.error("Could not obtain OpenID 'sub'; ensure 'openid email profile' scopes are included.")
            return None

        acct_dir = self.root / _safe_dir_name(email, sub)
        acct_dir.mkdir(parents=True, exist_ok=True)
        meta_path = acct_dir / META_FILE
        meta = {
            "email": email,
            "sub": sub,
            "name": name,
            "scopes": list(scopes),
        }
        meta_path.write_text(json.dumps(meta, indent=2))

        dst_client = acct_dir / CLIENT_FILE
        if not dst_client.exists():
            try:
                dst_client.write_text(Path(client_path).read_text())
            except Exception:
                pass

        expires_at = time.time() + (int(creds.expiry.timestamp() - time.time()) if creds.expiry else 3500)
        token = Token(
            access_token=creds.token,
            refresh_token=creds.refresh_token,
            token_uri=creds.token_uri,
            client_id=creds.client_id,
            client_secret=creds.client_secret,
            scopes=list(creds.scopes or scopes),
            expires_at=expires_at,
        )
        token_path = acct_dir / TOKEN_FILE
        tmp_cfg = AccountConfig(
            id=acct_dir.name,
            email=email,
            sub=sub,
            scopes=scopes,
            dir=acct_dir,
            client_path=dst_client,
            token_path=token_path,
            meta_path=meta_path,
        )
        self.store.save(tmp_cfg, token)
        cfg = AccountConfig.from_dir(acct_dir)
        assert cfg is not None

        if set_current:
            self.set_current(cfg)
        log.info("Linked Gmail account: %s (sub=%s) dir=%s", cfg.email, cfg.sub, cfg.dir)
        return cfg


    def remove(self, cfg: AccountConfig) -> None:
        for f in (cfg.token_path, cfg.meta_path, cfg.client_path):
            try:
                f.unlink(missing_ok=True)
            except Exception:
                pass
        try:
            cfg.dir.rmdir()
        except OSError:
            pass
        if CURRENT_LINK.exists() and CURRENT_LINK.resolve() == cfg.dir:
            CURRENT_LINK.unlink()

    def credentials(self, cfg: Optional[AccountConfig] = None) -> Credentials:
        cfg = cfg or self.get_current()
        if not cfg:
            raise RuntimeError("No linked Gmail accounts. Call link_account(...) first.")
        return Account(cfg, self.store, self.auth).as_google_credentials()
