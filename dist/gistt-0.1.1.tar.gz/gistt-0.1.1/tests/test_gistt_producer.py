import json
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import MagicMock, patch

from gistt.models import EmailContext, EmailMessage
from gistt.services.gistt_cache_store import GisttCacheStore
from gistt.services.gistt_producer import GisttProducer


def make_message(identifier: str = "msg-1", account: str = "primary") -> EmailMessage:
    context = EmailContext(id="thread-1", messages=[])
    return EmailMessage(
        id=identifier,
        sender="sender@example.com",
        subject="Subject",
        time="2024-01-01T00:00:00Z",
        body="Body",
        is_from_user=False,
        account=account,
        context=context,
    )


class TestGisttProducer(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp_dir = tempfile.TemporaryDirectory()
        cache_path = Path(self._tmp_dir.name) / "gistt_cache.json"
        self.cache_store = GisttCacheStore(path=cache_path)
        self.genai_mock = MagicMock()
        self.gistt_producer = GisttProducer(genai_ops=self.genai_mock, cache_store=self.cache_store)
        self.email_message = make_message()
        self.action_group = self.gistt_producer.settings.action_groups[0]
        self.canonical = self.action_group.canonical_name
        self.genai_mock.generate.return_value = json.dumps(
            {
                "action_group_canonical": self.canonical,
                "explanation": "Explanation",
                "gistt": "gistt text",
            }
        )

    def tearDown(self) -> None:
        self._tmp_dir.cleanup()

    def test_produce(self) -> None:
        gistt = self.gistt_producer.produce(self.email_message)
        self.assertIsNotNone(gistt)
        self.assertEqual(gistt.content, "gistt text")
        self.assertEqual(gistt.recommendation.action_group.group, self.action_group.group)
        self.assertEqual(gistt.recommendation.action_group.action, self.action_group.action)
        self.assertEqual(gistt.recommendation.explanation, "Explanation")

    def test_produce_uses_cache_when_called_again(self) -> None:
        first_gistt = self.gistt_producer.produce(self.email_message)
        self.assertIsNotNone(first_gistt)
        self.gistt_producer.genai_ops.generate.assert_called_once()

        self.gistt_producer.genai_ops.generate.reset_mock()
        refreshed_message = EmailMessage(
            id=self.email_message.id,
            sender="sender@example.com",
            subject="Updated Subject",
            time="2024-01-01T01:00:00Z",
            body="Updated Body",
            is_from_user=False,
            account=self.email_message.account,
            context=EmailContext(id="thread-1", messages=[]),
        )

        cached_gistt = self.gistt_producer.produce(refreshed_message)
        self.gistt_producer.genai_ops.generate.assert_not_called()
        self.assertEqual(cached_gistt.content, first_gistt.content)
        self.assertEqual(cached_gistt.email_message, refreshed_message)
        self.assertNotEqual(cached_gistt.email_message, first_gistt.email_message)

    def test_produce_handles_invalid_json_response(self) -> None:
        self.genai_mock.generate.return_value = "not-json"
        gistt = self.gistt_producer.produce(self.email_message)
        self.assertEqual(gistt.content, "Gistt unavailable. Review the thread manually.")
        self.assertIsNone(gistt.recommendation)

    def test_produce_handles_fenced_json_response(self) -> None:
        self.genai_mock.generate.return_value = """```json
        {
            "action_group_canonical": "%s",
            "explanation": "Explanation",
            "gistt": "Summary inside fence"
        }
        ```""" % (self.canonical,)
        gistt = self.gistt_producer.produce(self.email_message)
        self.assertEqual(gistt.content, "Summary inside fence")

    def test_prompt_includes_relative_time(self) -> None:
        reference_now = datetime(2024, 1, 4, tzinfo=timezone.utc)
        timestamp = "2024-01-01T00:00:00+00:00"
        context_message = EmailMessage(
            id="msg-1",
            sender="sender@example.com",
            subject="Subject",
            time=timestamp,
            body="Body",
            is_from_user=False,
            account="primary",
            context=None,
        )
        context = EmailContext(id="thread-1", messages=[context_message])
        email_message = EmailMessage(
            id=context_message.id,
            sender=context_message.sender,
            subject=context_message.subject,
            time=context_message.time,
            body=context_message.body,
            is_from_user=context_message.is_from_user,
            account=context_message.account,
            context=context,
        )

        with patch("gistt.services.utils._now", return_value=reference_now):
            self.gistt_producer.produce(email_message)

        prompt = self.genai_mock.generate.call_args[0][0]
        self.assertIn("(3d ago)", prompt)

    def test_produce_many_preserves_order_and_reports_progress(self) -> None:
        messages = [
            make_message(identifier=f"msg-{index}")
            for index in range(1, 4)
        ]
        self.genai_mock.generate.side_effect = [
            json.dumps(
                {
                    "action_group_canonical": self.canonical,
                    "explanation": f"Explanation {index}",
                    "gistt": f"gistt text {index}",
                }
            )
            for index in range(1, 4)
        ]
        progress_calls: list[tuple[int, int, str]] = []

        def _progress(completed: int, total: int, email: EmailMessage) -> None:
            progress_calls.append((completed, total, email.id))

        gistts = self.gistt_producer.produce_many(
            messages,
            max_workers=2,
            progress=_progress,
        )

        self.assertEqual(
            [gistt.email_message.id for gistt in gistts],
            [message.id for message in messages],
        )
        self.assertEqual(len(progress_calls), len(messages))
        self.assertEqual(progress_calls[-1][0], len(messages))

    def test_produce_strips_css_rules_from_prompt(self) -> None:
        css_body = """
.ReadMsgBody { width: 100%;}
@media only screen and (max-width: 480px) {
  .body[pmyh] .device-width {
    width:100%!important; padding:0;
  }
}

Hello team,
Let's sync tomorrow.
"""
        context_message = EmailMessage(
            id="msg-css",
            sender="sender@example.com",
            subject="CSS Noise",
            time="2024-01-02T00:00:00Z",
            body=css_body,
            is_from_user=False,
            account="primary",
            context=None,
        )
        context = EmailContext(id="thread-css", messages=[context_message])
        email_message = EmailMessage(
            id=context_message.id,
            sender=context_message.sender,
            subject=context_message.subject,
            time=context_message.time,
            body=context_message.body,
            is_from_user=context_message.is_from_user,
            account=context_message.account,
            context=context,
        )

        self.gistt_producer.produce(email_message)
        prompt = self.genai_mock.generate.call_args[0][0]
        self.assertNotIn(".ReadMsgBody", prompt)
        self.assertNotIn("@media", prompt)
        self.assertIn("Hello team,", prompt)


if __name__ == "__main__":
    unittest.main()
