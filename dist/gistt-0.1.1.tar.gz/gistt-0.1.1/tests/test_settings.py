import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_PATH = PROJECT_ROOT / "src"
if str(SRC_PATH) not in sys.path:
    sys.path.insert(0, str(SRC_PATH))

from gistt.settings import Preferences, Settings, reset_settings_cache


class TestSettingsOverrides(unittest.TestCase):
    def tearDown(self) -> None:
        reset_settings_cache()

    def test_env_override_path_applies_preferences(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            override_path = Path(tmpdir) / "settings.json"
            override_payload = {"preferences": {"recency_cutoff_days": 42}}
            override_path.write_text(json.dumps(override_payload), encoding="utf-8")
            config_home = Path(tmpdir) / "config"

            with mock.patch.dict(
                os.environ,
                {
                    "GISTT_SETTINGS_PATH": str(override_path),
                    "XDG_CONFIG_HOME": str(config_home),
                },
                clear=False,
            ):
                reset_settings_cache()
                settings = Settings()

        self.assertEqual(settings.preferences.recency_cutoff_days, 42)
        self.assertGreater(len(settings.action_groups), 0)
        self.assertTrue(any(group.group == "Action Needed" for group in settings.action_groups))
        self.assertIsNotNone(settings._settings_source)
        assert settings._settings_source is not None
        self.assertEqual(settings._settings_source, override_path)

    def test_xdg_override_maintains_defaults_when_partial(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            config_home = Path(tmpdir)
            gistt_dir = config_home / "gistt"
            gistt_dir.mkdir(parents=True)
            override_path = gistt_dir / "settings.json"
            override_payload = {"preferences": {"summary_workers": 7}}
            override_path.write_text(json.dumps(override_payload), encoding="utf-8")

            with mock.patch.dict(
                os.environ,
                {
                    "XDG_CONFIG_HOME": str(config_home),
                    "GISTT_SETTINGS_PATH": "",
                },
                clear=False,
            ):
                reset_settings_cache()
                settings = Settings()

        self.assertEqual(settings.preferences.summary_workers, 7)
        self.assertEqual(
            settings.preferences.recency_cutoff_days,
            Preferences().recency_cutoff_days,
        )

    def test_missing_override_path_falls_back_to_defaults(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            config_home = Path(tmpdir)
            missing_path = Path(tmpdir) / "missing.json"
            with mock.patch.dict(
                os.environ,
                {
                    "GISTT_SETTINGS_PATH": str(missing_path),
                    "XDG_CONFIG_HOME": str(config_home),
                },
                clear=False,
            ):
                reset_settings_cache()
                settings = Settings()

        self.assertEqual(settings.preferences.recency_cutoff_days, 10)
        self.assertEqual(settings.preferences.summary_workers, 3)
        self.assertEqual(settings.preferences.default_fetch_size, 10)
        self.assertIsNone(settings._settings_source)

    def test_user_settings_template_created_when_missing(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            config_home = Path(tmpdir) / "xdg"
            template_path = config_home / "gistt" / "settings.json"
            self.assertFalse(template_path.exists())

            with mock.patch.dict(
                os.environ,
                {"XDG_CONFIG_HOME": str(config_home)},
                clear=False,
            ):
                reset_settings_cache()
                _settings = Settings()

                self.assertTrue(template_path.exists())
                payload = json.loads(template_path.read_text(encoding="utf-8"))
                self.assertIn("action_groups", payload)
                self.assertIn("preferences", payload)
