from __future__ import annotations

from typing import Any, Dict, List, Optional

from gistt.services.gmail_ops import GmailOps
from gistt.settings import Settings


class _FakeThreadsResource:
    def __init__(self) -> None:
        self.calls: List[Dict[str, Any]] = []

    def list(self, **kwargs: Any) -> "_FakeThreadsResource":
        self.calls.append(dict(kwargs))
        return self

    def execute(self) -> Dict[str, Any]:
        return {"threads": []}

    def get(self, *args: Any, **kwargs: Any) -> "_FakeThreadsResource":  # pragma: no cover - not used
        raise AssertionError("Unexpected call to get() during filter test.")


class _FakeUsersResource:
    def __init__(self, threads_resource: _FakeThreadsResource) -> None:
        self._threads_resource = threads_resource

    def threads(self) -> _FakeThreadsResource:
        return self._threads_resource


class _FakeService:
    def __init__(self) -> None:
        self.threads_resource = _FakeThreadsResource()
        self.users_resource = _FakeUsersResource(self.threads_resource)

    def users(self) -> _FakeUsersResource:
        return self.users_resource


class _StubAccountManager:
    def credentials(self, config: object) -> None:  # pragma: no cover - not needed for this test
        return None


def test_list_recent_threads_includes_unread_filter() -> None:
    settings = Settings()
    gmail_ops = GmailOps(account_manager=_StubAccountManager(), settings=settings)
    fake_service = _FakeService()

    result = gmail_ops._list_recent_threads(service=fake_service, limit=5)

    assert result == []
    assert fake_service.threads_resource.calls, "Expected threads().list to be invoked."
    query = fake_service.threads_resource.calls[0]["q"]
    assert "label:UNREAD" in query
