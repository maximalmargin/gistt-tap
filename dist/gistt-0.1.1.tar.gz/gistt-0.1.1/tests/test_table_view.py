from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional
from unittest.mock import patch

from rich.console import Console

from gistt.controller.session_state import SessionState, TableState
from gistt.services.gistt_cache_store import CachedGistt
from gistt.models import ActionGroup, ActionGroupRec, EmailMessage, Gistt, GisttState
from gistt.ui.table_view import TableView


class DummySessionStore:
    def __init__(
        self,
        *,
        account_email: Optional[str] = None,
        multi_account_mode: bool = False,
    ) -> None:
        self._state = SessionState(
            active_account_email=account_email,
            multi_account_mode=multi_account_mode,
            table_state=TableState(selected_index=0),
        )

    def load(self) -> SessionState:
        return self._state


@dataclass
class DummyController:
    handle_response: dict[str, object]
    cached_entries: List[CachedGistt]
    after_entries: Optional[List[CachedGistt]] = None
    selection_index: int = 0
    cached_results_calls: int = 0
    handle_calls: int = 0

    def handle_choice(self, choice: str) -> dict[str, object]:
        self.handle_calls += 1
        response = dict(self.handle_response)
        if response.get("status") == "ok" and self.after_entries is not None:
            self.cached_entries = list(self.after_entries)
        return response

    def cached_results(self) -> List[CachedGistt]:
        self.cached_results_calls += 1
        if self.selection_index >= len(self.cached_entries):
            self.selection_index = max(0, len(self.cached_entries) - 1)
        return list(self.cached_entries)

    def current_selection(self) -> int:
        return self.selection_index

    def move_selection(self, delta: int, total: int) -> tuple[int, bool]:
        if total <= 0:
            self.selection_index = 0
            return self.selection_index, False
        target = max(0, min(self.selection_index + delta, total - 1))
        changed = target != self.selection_index
        self.selection_index = target
        return self.selection_index, changed

    def set_selection(self, index: int) -> int:
        if not self.cached_entries:
            self.selection_index = 0
        else:
            self.selection_index = max(0, min(index, len(self.cached_entries) - 1))
        return self.selection_index


class DummyLive:
    def __init__(self) -> None:
        self.update_calls: int = 0

    def update(self, renderable, refresh: bool = False) -> None:  # noqa: ANN001 - rich signature
        self.update_calls += 1


class DummyLiveContext:
    def __enter__(self) -> "DummyLiveContext":
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:  # noqa: ANN001
        return False

    def update(self, renderable, refresh: bool = False) -> None:  # noqa: ANN001
        pass


def _cached_gist(subject: str, *, state: GisttState | str | None = None) -> CachedGistt:
    action_group = ActionGroup(group="Action Needed", action=None)
    recommendation = ActionGroupRec(action_group=action_group, explanation="because")
    email = EmailMessage(
        id=f"{subject}-id",
        sender="sender@example.com",
        subject=subject,
        time="2024-02-10T10:00:00Z",
        body="body",
        is_from_user=False,
        account="",
    )
    gistt = Gistt(content=f"{subject} gist", email_message=email, recommendation=recommendation, state=state)
    return CachedGistt(gistt=gistt, cached_at="2024-02-10T11:00:00Z")


def test_execute_action_refreshes_cached_results_and_rerenders() -> None:
    initial_entry = _cached_gist("Initial")
    refreshed_entry = _cached_gist("Refreshed")
    controller = DummyController(
        handle_response={
            "status": "ok",
            "message": "Action complete.",
            "action": "archive",
        },
        cached_entries=[refreshed_entry],
    )
    view = TableView(
        console=Console(record=True),
        session_store=DummySessionStore(),
        controller=controller,  # type: ignore[arg-type]
    )
    view._current_results = [initial_entry]

    live = DummyLive()
    view._handle_execute_action(live)  # type: ignore[arg-type]

    assert controller.handle_calls == 1
    assert controller.cached_results_calls == 1
    assert view._current_results == [refreshed_entry]
    assert view.status_message.startswith("Action complete.")
    assert "Selected 1/1 (Default account): Refreshed" in view.status_message
    assert live.update_calls == 1


def test_header_displays_all_accounts_label() -> None:
    controller = DummyController(handle_response={}, cached_entries=[])
    view = TableView(
        console=Console(record=True),
        session_store=DummySessionStore(multi_account_mode=True),
        controller=controller,  # type: ignore[arg-type]
    )

    header = view._build_header()

    assert "all accounts" in header.renderable.plain


def test_execute_action_skips_refresh_on_noop() -> None:
    entry = _cached_gist("Initial")
    controller = DummyController(
        handle_response={"status": "noop", "message": "Nothing to do."},
        cached_entries=[entry],
    )
    view = TableView(
        console=Console(record=True),
        session_store=DummySessionStore(),
        controller=controller,  # type: ignore[arg-type]
    )
    view._current_results = [entry]

    live = DummyLive()
    view._handle_execute_action(live)  # type: ignore[arg-type]

    assert controller.cached_results_calls == 0
    assert view.status_message == "Nothing to do."
    assert live.update_calls == 1


def test_toggle_unreviewed_filter_shows_all_when_disabled() -> None:
    pending = _cached_gist("Pending")
    completed = _cached_gist("Completed", state=GisttState.ARCHIVED)
    controller = DummyController(handle_response={}, cached_entries=[pending, completed])
    view = TableView(
        console=Console(record=True),
        session_store=DummySessionStore(),
        controller=controller,  # type: ignore[arg-type]
    )

    view._load_all_results()
    assert view._filter_unreviewed is True
    assert [entry.gistt.email_message.subject for entry in view._current_results] == ["Pending"]

    live = DummyLive()
    view._toggle_unreviewed_filter(live)  # type: ignore[arg-type]  disable filter

    assert view._filter_unreviewed is False
    assert [entry.gistt.email_message.subject for entry in view._current_results] == ["Pending", "Completed"]
    assert "Showing" in view.status_message
    assert controller.selection_index == 0


def test_toggle_unreviewed_filter_can_be_cleared() -> None:
    pending = _cached_gist("Pending")
    controller = DummyController(handle_response={}, cached_entries=[pending])
    view = TableView(
        console=Console(record=True),
        session_store=DummySessionStore(),
        controller=controller,  # type: ignore[arg-type]
    )

    view._load_all_results()
    live = DummyLive()
    assert view._filter_unreviewed is True

    view._toggle_unreviewed_filter(live)  # disable filter (show all)
    assert view._filter_unreviewed is False
    assert len(view._current_results) == 1
    assert "Showing" in view.status_message

    view._toggle_unreviewed_filter(live)  # enable filter again
    assert view._filter_unreviewed is True
    assert len(view._current_results) == 1
    assert "Filtered" in view.status_message or "No unreviewed" in view.status_message


def test_actioned_gist_persists_until_dismissed() -> None:
    pending_before = _cached_gist("Pending")
    pending_after = _cached_gist("Pending", state=GisttState.ARCHIVED)
    controller = DummyController(
        handle_response={"status": "ok", "action": "archive"},
        cached_entries=[pending_before],
        after_entries=[pending_after],
    )
    view = TableView(
        console=Console(record=True),
        session_store=DummySessionStore(),
        controller=controller,  # type: ignore[arg-type]
    )

    view._load_all_results()

    live = DummyLive()
    view._handle_execute_action(live)  # type: ignore[arg-type]

    assert view._filter_unreviewed is True
    assert [entry.gistt.email_message.subject for entry in view._current_results] == ["Pending"]
    assert view._recently_actioned, "Expected recently actioned gistt to remain visible."

    view._dismiss_actioned_gist(live)  # type: ignore[arg-type]

    assert not view._recently_actioned
    assert view._current_results == []
    assert "no unreviewed" in view.status_message.lower()


def test_actioned_gist_hidden_when_filtering_after_all_view_action() -> None:
    pending_before = _cached_gist("Pending")
    pending_after = _cached_gist("Pending", state=GisttState.ARCHIVED)
    controller = DummyController(
        handle_response={"status": "ok", "action": "archive"},
        cached_entries=[pending_before],
        after_entries=[pending_after],
    )
    view = TableView(
        console=Console(record=True),
        session_store=DummySessionStore(),
        controller=controller,  # type: ignore[arg-type]
    )

    view._load_all_results()

    live = DummyLive()
    view._toggle_unreviewed_filter(live)  # disable filter (show all)
    assert view._filter_unreviewed is False

    view._handle_execute_action(live)  # type: ignore[arg-type]

    assert not view._recently_actioned

    view._toggle_unreviewed_filter(live)  # enable filter (show unreviewed)

    assert view._filter_unreviewed is True
    assert view._current_results == []
    assert "no unreviewed" in view.status_message.lower()


def test_prepare_for_entry_clears_recently_actioned_on_reopen() -> None:
    pending_before = _cached_gist("Pending")
    pending_after = _cached_gist("Pending", state=GisttState.ARCHIVED)
    controller = DummyController(
        handle_response={"status": "ok", "action": "archive"},
        cached_entries=[pending_before],
        after_entries=[pending_after],
    )
    view = TableView(
        console=Console(record=True),
        session_store=DummySessionStore(),
        controller=controller,  # type: ignore[arg-type]
    )

    view._load_all_results()

    live = DummyLive()
    view._handle_execute_action(live)  # type: ignore[arg-type]

    assert view._recently_actioned

    view.prepare_for_entry()
    view._load_all_results()

    assert not view._recently_actioned
    assert view._current_results == []
    assert "no unreviewed" in view.status_message.lower()


def test_render_enter_opens_thread_view() -> None:
    entry = _cached_gist("Subject")
    controller = DummyController(handle_response={}, cached_entries=[entry])
    view = TableView(
        console=Console(record=True),
        session_store=DummySessionStore(),
        controller=controller,  # type: ignore[arg-type]
    )

    with patch("gistt.ui.table_view.read_key", side_effect=["enter"]):
        result = view.render(live_factory=lambda **kwargs: DummyLiveContext())

    assert result == "open-thread"
    assert view.consume_last_opened_entry() == entry
    assert view.consume_last_opened_entry() is None
