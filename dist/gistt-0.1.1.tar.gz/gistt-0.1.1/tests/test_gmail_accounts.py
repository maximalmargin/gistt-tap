import json
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
import gistt.services.gmail_accounts as ga


class FakeCreds:
    def __init__(self, token, refresh_token="R", token_uri="U", client_id="CID",
                 client_secret="CS", scopes=None, expiry=None, id_token=None):
        self.token, self.refresh_token, self.token_uri = token, refresh_token, token_uri
        self.client_id, self.client_secret = client_id, client_secret
        self.scopes = list(scopes or [])
        self.expiry, self.id_token = expiry, id_token

    @property
    def expired(self): return self.expiry and datetime.now() >= self.expiry
    @property
    def valid(self): return bool(self.token) and not self.expired
    def refresh(self, _): self.token = "REFRESHED"; self.expiry = datetime.now(
    ) + timedelta(hours=1)


class FakeFlow:
    def __init__(self, scopes): self.scopes = scopes

    @classmethod
    def from_client_secrets_file(cls, path, scopes):
        assert Path(path).exists()
        return cls(scopes)

    def run_local_server(self, **_):
        import base64
        import json as j
        def b64(d): return base64.urlsafe_b64encode(
            j.dumps(d).encode()).decode().rstrip("=")
        idt = ".".join(("hdr", b64(
            {"email": "alice@example.com", "sub": "12345", "name": "Alice"}), "sig"))
        return FakeCreds("NEW", scopes=self.scopes, expiry=datetime.now()+timedelta(hours=1), id_token=idt)


class TestMinimalE2E(unittest.TestCase):
    def setUp(self):
        self.tmp = TemporaryDirectory()
        t = Path(self.tmp.name)
        self.root, self.cur = t/"accounts", t/"current"
        self.client = t/"client.json"
        self.client.write_text(
            '{"installed":{"client_id":"x","project_id":"p","auth_uri":"u","token_uri":"tu","client_secret":"s","redirect_uris":["http://localhost"]}}')
        self.p1 = patch.object(ga, "CURRENT_LINK", self.cur, create=True)
        self.p2 = patch.object(ga, "InstalledAppFlow", FakeFlow, create=True)
        self.p3 = patch.object(ga, "Credentials", FakeCreds, create=True)
        for p in (self.p1, self.p2, self.p3):
            p.start()
        self.mgr = ga.AccountManager(root=self.root)

    def tearDown(self):
        for p in (self.p3, self.p2, self.p1):
            p.stop()
        self.tmp.cleanup()

    def test_link_and_credentials_happy_path(self):
        cfg = self.mgr.link_account(
            client_path=self.client, scopes=ga.DEFAULT_SCOPES, set_current=True)
        self.assertIsNotNone(cfg)
        self.assertEqual(cfg.email, "alice@example.com")
        self.assertEqual(cfg.sub, "12345")
        self.assertTrue(cfg.meta_path.exists() and cfg.token_path.exists())
        self.assertEqual(ga.CURRENT_LINK.resolve(), cfg.dir)

        # token.json contains our serialized token
        tok = json.loads(cfg.token_path.read_text())
        self.assertEqual(tok["client_id"], "CID")
        self.assertIn("expires_at", tok)

        # credentials() returns a ready credentials object (valid)
        creds = self.mgr.credentials(cfg)
        self.assertTrue(creds.valid)


if __name__ == "__main__":
    unittest.main()
