import json
import logging
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field, replace
from typing import Callable, Iterable, List, Sequence
import threading

from gistt.models import ActionGroup, ActionGroupRec, EmailContext, EmailMessage, Gistt
from gistt.services.genai_ops import GenAIOps
from gistt.settings import Settings
from gistt.services.gistt_cache_store import GisttCacheStore, CachedGistt
from gistt.services.utils import format_prompt_timestamp, format_thread_context

_ACTION_GROUP_TEMPLATE = """
- Canonical: "{canonical}"
  Group: "{group}"
  Action: "{action}"
  Condition: {condition}
  Instruction: {instruction}
"""
    
_GISTT_PROMPT_TEMPLATE = """
You are an executive assistant triaging an email thread.
Select the single best group from the list below. Each group specifies when to use it, the workflow action to take, and how the gistt should read.

Groups:
{groups}

Write your response using these rules:
- You must choose one group exactly as listed above; do not invent new groups.
- Return the canonical value exactly as provided for that group.
- Give a concise explanation (<= 25 words) for why the group fits.
- Provide at most two concise sentences summarizing the thread while following the chosen group's instruction.
- When the chosen group's action is "archive" or "save" and no follow-up is required, prefer a single sentence under 10 words.
- Use active voice and information-dense phrasing. Highlight critical dates, numbers, or commitments when relevant.

Return only JSON (no markdown):
{{
  "action_group_canonical": "<one of the listed canonical values>",
  "explanation": "<=25 words",
  "gistt": "one or two sentences that follow the chosen group's instruction"
}}

Thread subject: {subject}
Latest message time: {latest_time}
Last sender was user: {is_from_user}
Total messages: {count}

Context (most recent last):
{thread_context}
"""

log = logging.getLogger(__name__)

@dataclass
class GisttProducer:

    genai_ops: GenAIOps = field(default_factory=GenAIOps)
    settings: Settings = field(default_factory=Settings)
    cache_store: GisttCacheStore = field(default_factory=GisttCacheStore)
    _key_locks: dict[str, threading.Lock] = field(default_factory=dict, init=False, repr=False)
    _key_locks_guard: threading.Lock = field(default_factory=threading.Lock, init=False, repr=False)

    def produce(
        self,
        email_message: EmailMessage,
    ) -> Gistt:
        cached = self.cache_store.get(email_message.account, email_message.id)
        if cached is not None:
            gistt = cached.gistt
            if gistt.email_message != email_message:
                gistt = replace(gistt, email_message=email_message)
                self.cache_store.upsert(email_message, gistt)
            return gistt

        prompt = self._build_get_gist_prompt(email_message)
        response = self.genai_ops.generate(prompt)
        cleaned = self._normalize_response(response)
        log.debug("GenAI response for message %s (cleaned): %s", email_message.id, cleaned)
        gistt = self._safe_construct_gist(email_message, cleaned)
        self.cache_store.upsert(email_message, gistt)
        return gistt

    def produce_many(
        self,
        email_messages: Sequence[EmailMessage] | Iterable[EmailMessage],
        *,
        max_workers: int | None = None,
        progress: Callable[[int, int, EmailMessage], None] | None = None,
    ) -> List[Gistt]:
        """Produce gistts for many emails concurrently and return results in input order."""
        emails = list(email_messages)
        total = len(emails)
        if total == 0:
            return []

        def _lookup_key(email: EmailMessage) -> str:
            account = email.account or ""
            return f"{account}|{email.id}"

        # Build per-key locks so duplicate message ids process sequentially.
        unique_keys = {_lookup_key(email) for email in emails}
        for key in unique_keys:
            with self._key_locks_guard:
                self._key_locks.setdefault(key, threading.Lock())

        results: List[Gistt | None] = [None] * total
        worker_count = max_workers or self.settings.preferences.summary_workers or 1
        if worker_count < 1:
            worker_count = 1

        def _task(index: int, email: EmailMessage) -> tuple[int, Gistt, EmailMessage]:
            key = _lookup_key(email)
            lock = self._key_locks[key]
            with lock:
                gistt = self.produce(email)
            return index, gistt, email

        with ThreadPoolExecutor(max_workers=worker_count) as executor:
            futures = {
                executor.submit(_task, index, email): index
                for index, email in enumerate(emails)
            }

            completed = 0
            for future in as_completed(futures):
                index, gistt, email = future.result()
                results[index] = gistt
                completed += 1
                if progress:
                    try:
                        progress(completed, total, email)
                    except Exception:  # noqa: BLE001
                        log.exception("Progress callback failed for email %s", email.id)

        # Filter out None placeholders (should not occur) and type narrow.
        return [gistt for gistt in results if gistt is not None]

    def cached_gists(
        self,
        *,
        account_email: str | None = None,
        limit: int | None = None,
        account_emails: Sequence[str | None] | None = None,
    ) -> List[CachedGistt]:
        """Return cached gistts for one or more accounts."""
        if account_emails is not None:
            return self.cache_store.list_for_accounts(account_emails, limit=limit)
        return self.cache_store.list_for_account(account_email, limit=limit)

    def _build_get_gist_prompt(self, email_message: EmailMessage) -> str:
        groups = self._get_action_groups_prompt()
        email_context: EmailContext | None = email_message.context
        count = email_context.count if email_context else 0
        context_text = format_thread_context(email_context)
        latest_time = format_prompt_timestamp(email_message.time)
        prompt = _GISTT_PROMPT_TEMPLATE.format(
            groups=groups,
            subject=email_message.subject,
            latest_time=latest_time,
            is_from_user=email_message.is_from_user,
            count=count,
            thread_context=context_text,
        )
        return prompt
    
    def _get_action_groups_prompt(self) -> str:
        segments: List[str] = []
        for action_group in self.settings.action_groups:
            action_value = (
                action_group.action.name
                if hasattr(action_group.action, "name")
                else str(action_group.action or "")
            )
            segments.append(
                _ACTION_GROUP_TEMPLATE.format(
                    canonical=action_group.canonical_name,
                    group=action_group.group,
                    action=action_value,
                    condition=action_group.condition,
                    instruction=action_group.instruction,
                )
            )
        return "".join(segments)
    
    def _safe_construct_gist(self, email_message: EmailMessage, response: str) -> Gistt:
        try:
            return self._construct_gist_object(email_message, response)
        except (json.JSONDecodeError, KeyError, TypeError, ValueError) as error:
            log.error("Failed to parse GenAI gistt response for %s: %s", email_message.id, error)
            log.debug("Raw response content for %s: %s", email_message.id, response)
            return self._fallback_gist(email_message)
        except Exception as error:  # noqa: BLE001
            log.error("Unexpected error while constructing gistt for %s: %s", email_message.id, error)
            log.debug("Raw response content for %s: %s", email_message.id, response)
            return self._fallback_gist(email_message)

    def _construct_gist_object(self, email_message: EmailMessage, response: str) -> Gistt:
        payload = json.loads(response)
        canonical = str(payload["action_group_canonical"]).strip()
        action_group = self._lookup_action_group(canonical)
        if action_group is None:
            raise ValueError(f"Unknown action group canonical name: {canonical}")

        action_group_rec = ActionGroupRec(
            action_group=action_group,
            explanation=str(payload["explanation"]),
        )

        gistt = Gistt(
            content=str(payload["gistt"]),
            email_message=email_message,
            recommendation=action_group_rec
        )
        return gistt

    def _lookup_action_group(self, canonical: str) -> ActionGroup | None:
        normalized = canonical.strip().lower()
        if not normalized:
            return None
        for entry in self.settings.action_groups:
            if entry.canonical_name == normalized:
                return entry
        return None

    def _fallback_gist(self, email_message: EmailMessage) -> Gistt:
        fallback_text = "Gistt unavailable. Review the thread manually."
        return Gistt(
            content=fallback_text,
            email_message=email_message,
            recommendation=None,
        )

    def _normalize_response(self, response: str | None) -> str:
        if not response:
            return ""
        text = response.strip()
        # If the model wrapped the payload in fenced blocks, extract JSON inside.
        if "```" in text:
            segments = [segment.strip() for segment in text.split("```") if segment.strip()]
            # Prefer the segment that looks like JSON.
            for segment in segments:
                if segment.lower().startswith("json"):
                    without_label = segment[4:].strip()
                    if without_label:
                        text = without_label
                        break
                elif segment.startswith("{"):
                    text = segment
                    break
        # As a final safeguard, extract the first JSON object.
        match = re.search(r"\{.*\}", text, flags=re.DOTALL)
        if match:
            return match.group(0).strip()
        return text
