"""Operations for fetching Gmail messages and thread context."""
from __future__ import annotations

from datetime import datetime, timezone
from email.mime.text import MIMEText
from email.utils import parsedate_to_datetime
from typing import Callable, Dict, List, Optional, Tuple
import base64
import logging
import re

from googleapiclient.discovery import build as google_build
from googleapiclient.errors import HttpError

from gistt.models import DraftRequest, DraftResult, EmailContext, EmailMessage
from gistt.services.gmail_accounts import AccountConfig, AccountManager
from gistt.settings import Settings

log = logging.getLogger(__name__)

ServiceFactory = Callable[[object], object]


class GmailOps:
    """Lightweight helper for fetching Gmail messages and thread context."""

    def __init__(
        self,
        account_manager: AccountManager,
        settings: Settings,
        *,
        service_factory: Optional[Callable[[object], object]] = None,
    ) -> None:
        self._account_manager = account_manager
        self._settings = settings
        self._service_factory = service_factory or self._default_service_factory
        self._service_cache: Dict[str, object] = {}
        self._profile_cache: Dict[str, str] = {}
        self._gist_label_cache: Dict[str, str] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def list_accounts(self) -> List[AccountConfig]:
        """Return all linked Gmail accounts."""
        try:
            return self._account_manager.list()
        except AttributeError:
            log.debug("Account manager does not expose 'list'; returning empty list.")
            return []

    def fetch_messages_with_context(
        self,
        *,
        account_email: Optional[str] = None,
        limit: Optional[int] = None,
        max_messages_per_thread: Optional[int] = None,
    ) -> List[Tuple[EmailMessage, EmailContext]]:
        """Fetch multiple messages with their thread context."""
        log.info(
            "fetch_messages_with_context start account=%s limit=%s max_messages_per_thread=%s",
            account_email or "<default>",
            limit,
            max_messages_per_thread,
        )
        service = self._service_for_account(account_email)
        if service is None:
            log.warning("fetch_messages_with_context aborted: no service for %s", account_email or "<default>")
            return []

        account_key = self._account_key(account_email)
        fetch_limit = limit if limit is not None else self._settings.preferences.default_fetch_size
        if fetch_limit <= 0:
            log.info("fetch_messages_with_context: non-positive fetch limit resolved to %s", fetch_limit)
            return []

        thread_payloads = self._list_recent_threads(service, limit=fetch_limit)
        if not thread_payloads:
            log.info("fetch_messages_with_context: no threads returned for %s", account_email or "<default>")
            return []

        message_limit = (
            max_messages_per_thread if max_messages_per_thread and max_messages_per_thread > 0 else None
        )
        results: List[Tuple[EmailMessage, EmailContext]] = []
        for payload in thread_payloads:
            built = self._build_email_context(
                service=service,
                thread_payload=payload,
                account_email=account_email,
                account_key=account_key,
                max_messages=message_limit if message_limit else None,
            )
            if built:
                results.append(built)
        log.info(
            "fetch_messages_with_context complete account=%s threads=%s results=%s",
            account_email or "<default>",
            len(thread_payloads),
            len(results),
        )
        return results

    def modify_thread_labels(
        self,
        *,
        account_email: Optional[str] = None,
        thread_id: str,
        add_labels: Optional[List[str]] = None,
        remove_labels: Optional[List[str]] = None,
    ) -> bool:
        """Apply label updates to a Gmail thread."""
        if not thread_id:
            log.warning("modify_thread_labels aborted: missing thread id")
            return False

        service = self._service_for_account(account_email)
        if service is None:
            log.warning(
                "modify_thread_labels aborted: no service for %s",
                account_email or "<default>",
            )
            return False

        account_key = self._account_key(account_email)
        add_ids = self._resolve_label_names(service, account_key, add_labels or [], create=True)
        remove_ids = self._resolve_label_names(service, account_key, remove_labels or [], create=False)
        if not add_ids and not remove_ids:
            log.debug(
                "modify_thread_labels: no label changes for thread %s",
                thread_id,
            )
            return True

        body: Dict[str, List[str]] = {}
        if add_ids:
            body["addLabelIds"] = add_ids
        if remove_ids:
            body["removeLabelIds"] = remove_ids

        log.info(
            "modify_thread_labels start thread_id=%s add=%s remove=%s",
            thread_id,
            add_ids,
            remove_ids,
        )
        try:
            (
                service.users()
                .threads()
                .modify(userId="me", id=thread_id, body=body)
                .execute()
            )
        except HttpError as error:  # pragma: no cover - network interaction
            log.error("Failed to modify labels for thread %s: %s", thread_id, error)
            return False

        log.info("modify_thread_labels success thread_id=%s", thread_id)
        return True

    def create_draft(
        self,
        *,
        request: DraftRequest,
        account_email: Optional[str] = None,
    ) -> Optional[DraftResult]:
        """Create a Gmail draft for the supplied request."""
        if request is None:
            log.warning("create_draft aborted: missing request payload")
            return None
        if not request.to or not request.body:
            log.warning("create_draft aborted: missing recipient or body")
            return None

        service = self._service_for_account(account_email)
        if service is None:
            log.warning("create_draft aborted: no Gmail service for %s", account_email or "<default>")
            return None

        message = MIMEText(request.body)
        message["to"] = request.to
        message["subject"] = request.subject

        raw_message = base64.urlsafe_b64encode(message.as_bytes()).decode("utf-8")
        body = {"message": {"raw": raw_message}}
        if request.thread_id:
            body["message"]["threadId"] = request.thread_id

        log.info(
            "create_draft start account=%s thread_id=%s",
            account_email or "<default>",
            request.thread_id or "<none>",
        )
        try:
            draft = service.users().drafts().create(userId="me", body=body).execute()
        except HttpError as error:  # pragma: no cover - network interaction
            log.error("Failed to create Gmail draft: %s", error)
            return None

        if not isinstance(draft, dict):
            log.error("Unexpected draft response type: %s", type(draft))
            return None

        draft_id = str(draft.get("id", "")) if draft.get("id") else ""
        thread_id = request.thread_id
        message_payload = draft.get("message")
        if isinstance(message_payload, dict):
            thread_value = message_payload.get("threadId")
            if thread_value:
                thread_id = str(thread_value)

        if not draft_id:
            log.debug("Draft creation response missing id; treating as failure.")
            return None

        return DraftResult(
            draft_id=draft_id,
            to=request.to,
            subject=request.subject,
            body=request.body,
            thread_id=thread_id,
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
    def _default_service_factory(self, credentials: object) -> object:
        if google_build is None:  # pragma: no cover - environment without google libs
            raise RuntimeError("googleapiclient is not available in this environment.")
        return google_build("gmail", "v1", credentials=credentials, cache_discovery=False)

    def _service_for_account(self, account_email: Optional[str]) -> Optional[object]:
        key = self._account_key(account_email)
        cached = self._service_cache.get(key)
        if cached is not None:
            log.debug("Using cached Gmail service for %s", key)
            return cached

        config = self._resolve_account(account_email)
        if config is None:
            log.warning("No Gmail account configured for %s", account_email or "default")
            return None

        log.debug("Creating Gmail service for %s", config.email)
        try:
            credentials = self._account_manager.credentials(config)
        except Exception as error:  # pragma: no cover - exercised via environment
            log.error("Failed to obtain credentials for %s: %s", config.email, error)
            return None

        try:
            service = self._service_factory(credentials)
        except Exception as error:  # pragma: no cover - service creation issues
            log.error("Failed to create Gmail service for %s: %s", config.email, error)
            return None

        self._service_cache[key] = service
        log.debug("Cached Gmail service for %s", key)
        return service

    def _resolve_account(self, account_email: Optional[str]) -> Optional[AccountConfig]:
        if account_email:
            return self._account_manager.get(account_email)
        return self._account_manager.get_current()

    def _list_recent_threads(self, service: object, *, limit: int) -> List[Dict[str, object]]:
        if limit <= 0:
            return []

        importance_window = self._settings.preferences.recency_cutoff_days
        query_parts: List[str] = ["label:UNREAD", "-label:SPAM", "-label:TRASH"]
        if importance_window > 0:
            query_parts.append(f"newer_than:{int(importance_window)}d")
        query = " ".join(query_parts)

        log.debug("Listing Gmail threads limit=%s query=%s", limit, query)
        try:
            response = (
                service.users()
                .threads()
                .list(
                    userId="me",
                    labelIds=["INBOX"],
                    maxResults=max(limit, 1),
                    q=query.strip(),
                )
                .execute()
            )
        except HttpError as error:  # pragma: no cover - network interaction
            log.error("Failed to list Gmail threads: %s", error)
            return []

        threads = response.get("threads", []) if response else []
        if not threads:
            log.debug("List threads returned no results")
            return []

        payloads: List[Dict[str, object]] = []
        for entry in threads:
            thread_id = entry.get("id")
            if not thread_id:
                continue
            payload = self._get_thread(service, thread_id)
            if payload:
                payloads.append(payload)
            if len(payloads) >= limit:
                break
        log.debug("Fetched %s thread payloads (requested %s)", len(payloads), limit)
        return payloads

    def _get_thread(self, service: object, thread_id: Optional[str]) -> Optional[Dict[str, object]]:
        if not thread_id:
            return None
        log.debug("Fetching Gmail thread %s", thread_id)
        try:
            return (
                service.users()
                .threads()
                .get(userId="me", id=thread_id, format="full")
                .execute()
            )
        except HttpError as error:  # pragma: no cover - network interaction
            log.error("Failed to fetch Gmail thread %s: %s", thread_id, error)
            return None

    def _build_email_context(
        self,
        *,
        service: object,
        thread_payload: Dict[str, object],
        account_email: Optional[str],
        account_key: str,
        max_messages: Optional[int],
    ) -> Optional[Tuple[EmailMessage, EmailContext]]:
        messages = thread_payload.get("messages") or []
        if not messages:
            return None

        selected_messages = list(messages)
        if max_messages is not None and max_messages > 0:
            selected_messages = selected_messages[-max_messages:]

        context_messages: List[EmailMessage] = []
        for item in selected_messages:
            parsed = self._to_email_message(
                service=service,
                payload=item,
                account_email=account_email,
                account_key=account_key,
            )
            if parsed:
                context_messages.append(parsed)

        if not context_messages:
            return None

        thread_id = str(thread_payload.get("id", ""))
        log.debug(
            "Built email context thread_id=%s messages=%s",
            thread_id or "unknown-thread",
            len(context_messages),
        )
        context = EmailContext(id=thread_id or "unknown-thread", messages=context_messages)
        latest = context_messages[-1]
        email = EmailMessage(
            id=latest.id,
            sender=latest.sender,
            subject=latest.subject,
            time=latest.time,
            body=latest.body,
            is_from_user=latest.is_from_user,
            account=latest.account,
            context=context,
        )
        return email, context

    def _to_email_message(
        self,
        service: object,
        payload: Dict[str, object],
        account_email: Optional[str],
        account_key: str,
    ) -> Optional[EmailMessage]:
        message_id = str(payload.get("id", ""))
        headers = self._extract_headers(payload)
        sender = headers.get("from", "Unknown sender")
        subject = headers.get("subject", "(No subject)")
        timestamp = self._resolve_timestamp(headers.get("date"), payload.get("internalDate"))
        account = account_email or self._user_email(service, account_key) or ""

        body = self._extract_plain_body(payload.get("payload", {}))
        clean_body = self._clean_email_body(body)
        is_from_user = self._is_user_sender(sender, service, account_key)

        return EmailMessage(
            id=message_id,
            sender=sender,
            subject=subject,
            time=timestamp,
            body=clean_body,
            is_from_user=is_from_user,
            account=account,
        )

    def _resolve_timestamp(self, header_date: Optional[str], internal_date: Optional[object]) -> str:
        if header_date:
            try:
                parsed = parsedate_to_datetime(header_date)
                if parsed.tzinfo is None:
                    parsed = parsed.replace(tzinfo=timezone.utc)
                return parsed.astimezone(timezone.utc).isoformat()
            except Exception:
                pass
        if internal_date:
            try:
                epoch_ms = int(str(internal_date))
                dt = datetime.fromtimestamp(epoch_ms / 1000.0, tz=timezone.utc)
                return dt.isoformat()
            except Exception:
                pass
        return ""

    def _extract_headers(self, payload: Dict[str, object]) -> Dict[str, str]:
        headers: Dict[str, str] = {}
        raw_headers = payload.get("payload", {}).get("headers", [])
        for header in raw_headers or []:
            name = str(header.get("name", "")).lower()
            value = str(header.get("value", ""))
            headers[name] = value
        return headers

    def _extract_plain_body(self, payload: Dict[str, object]) -> str:
        if not payload:
            return ""

        mime_type = str(payload.get("mimeType", "")).lower()
        data = payload.get("body", {}).get("data")
        if data:
            decoded = self._decode_body(data)
            if decoded:
                return decoded

        parts = payload.get("parts", []) or []
        if not parts:
            return ""

        for part in parts:
            if str(part.get("mimeType", "")).lower() == "text/plain":
                decoded = self._decode_part(part)
                if decoded:
                    return decoded

        for part in parts:
            if str(part.get("mimeType", "")).lower().startswith("multipart/"):
                decoded = self._extract_plain_body(part)
                if decoded:
                    return decoded

        for part in parts:
            if str(part.get("mimeType", "")).lower() == "text/html":
                decoded = self._decode_part(part)
                if decoded:
                    return decoded

        if mime_type == "text/html" and data:
            return self._decode_body(data)

        return ""

    def _decode_part(self, part: Dict[str, object]) -> str:
        body = part.get("body", {})
        data = body.get("data")
        if data:
            decoded = self._decode_body(data)
            if decoded:
                return decoded
        return ""

    def _decode_body(self, data: str) -> str:
        try:
            padding = len(data) % 4
            if padding:
                data += "=" * (4 - padding)
            return base64.urlsafe_b64decode(data).decode("utf-8", errors="replace")
        except (ValueError, UnicodeDecodeError):
            return ""

    def _clean_email_body(self, text: str) -> str:
        if not text:
            return ""

        cleaned = self._strip_html(text)
        lines = cleaned.splitlines()
        processed: List[str] = []

        for line in lines:
            base = line.rstrip()
            if not base:
                processed.append("")
                continue

            stripped = base.lstrip()
            quote_depth = len(stripped) - len(stripped.lstrip(">"))
            if quote_depth > 0:
                content = stripped.lstrip("> ").strip()
                marker = "[quoted]" if quote_depth == 1 else f"[quoted x{quote_depth}]"
                processed.append(f"{marker} {content}".strip())
            else:
                processed.append(base)

        while processed and not processed[0].strip():
            processed.pop(0)
        while processed and not processed[-1].strip():
            processed.pop()

        return "\n".join(processed)

    def _strip_html(self, text: str) -> str:
        stripped = re.sub(r"<\s*(br|p)\s*/?>", "\n", text, flags=re.IGNORECASE)
        stripped = re.sub(r"<[^>]+>", "", stripped)
        stripped = re.sub(r"[\t\r\f]+", " ", stripped)
        return stripped

    def _user_email(self, service: object, account_key: str) -> str:
        cached = self._profile_cache.get(account_key)
        if cached is not None:
            return cached
        try:
            profile = service.users().getProfile(userId="me").execute()
            email = str(profile.get("emailAddress", "")) if profile else ""
        except HttpError as error:  # pragma: no cover - network interaction
            log.error("Unable to fetch Gmail profile for %s: %s", account_key, error)
            email = ""
        self._profile_cache[account_key] = email
        return email

    def _is_user_sender(self, sender: str, service: object, account_key: str) -> bool:
        if not sender:
            return False
        user_email = self._user_email(service, account_key)
        return bool(user_email and user_email.lower() in sender.lower())

    def _account_key(self, account_email: Optional[str]) -> str:
        return (account_email or "__default__").lower()

    def _resolve_label_names(
        self,
        service: object,
        account_key: str,
        labels: List[str],
        *,
        create: bool,
    ) -> List[str]:
        if not labels:
            return []

        resolved: List[str] = []
        for label in labels:
            if not label:
                continue

            if label.lower() == "gistt":
                gist_id = self._gist_label_id(service, account_key, create=create)
                if gist_id:
                    resolved.append(gist_id)
                continue

            resolved.append(label)

        return resolved

    def _gist_label_id(
        self,
        service: object,
        account_key: str,
        *,
        create: bool,
    ) -> Optional[str]:
        cached = self._gist_label_cache.get(account_key)
        if cached:
            return cached

        try:
            response = service.users().labels().list(userId="me").execute()
        except HttpError as error:  # pragma: no cover - network interaction
            log.error("Unable to list Gmail labels for %s: %s", account_key, error)
            return None

        labels = response.get("labels", []) if response else []
        for entry in labels:
            if not isinstance(entry, dict):
                continue
            name = str(entry.get("name", "")).strip().lower()
            if name == "gistt":
                label_id = str(entry.get("id", ""))
                if label_id:
                    self._gist_label_cache[account_key] = label_id
                    return label_id

        if not create:
            return None

        try:
            created = (
                service.users()
                .labels()
                .create(
                    userId="me",
                    body={
                        "name": "gistt",
                        "labelListVisibility": "labelShow",
                        "messageListVisibility": "show",
                    },
                )
                .execute()
            )
        except HttpError as error:  # pragma: no cover - network interaction
            log.error("Failed to create gistt label for %s: %s", account_key, error)
            return None

        label_id = str((created or {}).get("id", "")) if created else ""
        if label_id:
            self._gist_label_cache[account_key] = label_id
            return label_id

        log.debug("Gmail returned no label id when creating gistt label for %s", account_key)
        return None
