"""Abstract base interface for interactive console views."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from rich.console import Console
from rich.panel import Panel
from gistt.controller.base import Controller

@dataclass
class View(ABC):
    """Common base for Rich-powered CLI views."""

    console: Console = field(repr=False)
    controller: Controller = field(repr=False)
    status_message: str = field(default="", init=False)

    @abstractmethod
    def render(self, *args: Any, **kwargs: Any) -> Any:
        """Render the view and return any interaction result."""

    @abstractmethod
    def _build_header(self) -> Panel:
        """Build the header for the view."""

    @abstractmethod
    def _build_body(self, *args: Any, **kwargs: Any) -> Panel:
        """Build the body for the view."""

    @abstractmethod
    def _build_footer(self, *args: Any, **kwargs: Any) -> Panel:
        """Build the footer for the view."""
