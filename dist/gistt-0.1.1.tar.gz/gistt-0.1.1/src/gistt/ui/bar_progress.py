"""Retro-styled progress helpers for the UI."""
from __future__ import annotations

from rich.progress import ProgressColumn, Task
from rich.text import Text

from gistt.ui.palette import Palette


class BarProgress(ProgressColumn):
    """Neon 80s bar using block characters (█ ▒ ░ ■)."""

    def __init__(self, width: int = 24) -> None:
        super().__init__()
        self._width = width

    def render(self, task: Task) -> Text:
        total = task.total or 0
        completed = min(max(task.completed or 0, 0), total) if total else (task.completed or 0)

        if total <= 0:
            interior = f"[dim {Palette.BACKGROUND}]" + ("░" * self._width) + "[/]"
            return Text.from_markup(f"[bold {Palette.PINK}]■[/]{interior}[bold {Palette.PINK}]■[/]")

        ratio = 0 if total == 0 else completed / max(total, 1)
        filled_units = max(0, min(self._width, int(ratio * self._width)))
        remaining_units = self._width - filled_units

        segments = [f"[bold {Palette.PINK}]■[/]"]
        if filled_units:
            segments.append(f"[bold {Palette.GREEN}]{'█' * filled_units}[/]")

        has_partial = 0 < ratio < 1 and remaining_units > 0
        if has_partial:
            segments.append(f"[bold {Palette.YELLOW}]▒[/]")
            remaining_units -= 1

        if remaining_units > 0:
            segments.append(f"[dim {Palette.BACKGROUND}]{'░' * remaining_units}[/]")

        segments.append(f"[bold {Palette.PINK}]■[/]")
        return Text.from_markup("".join(segments))


class BarProgressCount(ProgressColumn):
    """Retro-styled completed/total counter."""

    def render(self, task: Task) -> Text:
        total = task.total
        completed = task.completed or 0
        if total and total > 0:
            markup = (
                f"[bold {Palette.PRIMARY}]{int(completed):02d}[/]"
                f"[dim {Palette.YELLOW}]/[/]"
                f"[bold {Palette.YELLOW}]{int(total):02d}[/]"
            )
        else:
            markup = (
                f"[bold {Palette.PRIMARY}]{int(completed):02d}[/]"
                f"[dim {Palette.YELLOW}]/[/]"
                f"[bold {Palette.YELLOW}]??[/]"
            )
        return Text.from_markup(markup)
