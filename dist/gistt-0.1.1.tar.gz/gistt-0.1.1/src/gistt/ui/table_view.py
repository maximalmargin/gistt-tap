"""Rich-based table view."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import Callable, List, Optional, Set

from rich import box
from rich.console import Console, Group
from rich.live import Live
from rich.panel import Panel
from rich.progress import Progress, TextColumn, TimeElapsedColumn
from rich.table import Table
from rich.text import Text

from gistt.controller.session_state import SessionStateStore
from gistt.controller.table_controller import TableController
from gistt.services.gistt_cache_store import CachedGistt
from gistt.ui.base import View
from gistt.ui.layout import build_layout, read_key
from gistt.ui.gistt_table import GisttTable
from gistt.ui.bar_progress import BarProgress, BarProgressCount
from gistt.ui.bar_table import BarTable
from gistt.ui.palette import Palette


@dataclass(init=False)
class TableView(View):
    """Interactive table surface for browsing gistts."""

    controller: TableController = field(repr=False)
    status_message: str = field(default="◦ ready...")
    footer_message: str = field(
        default=(
            "g: fetch • tab: action • s: read • z: clear • e: archive • j/k: navigate • h: filter • d: dismiss • b: back • q: quit"
        ),
    )
    _current_results: List[CachedGistt] = field(init=False, default_factory=list, repr=False)
    _all_results: List[CachedGistt] = field(init=False, default_factory=list, repr=False)
    _display_index_map: List[int] = field(init=False, default_factory=list, repr=False)
    _filter_unreviewed: bool = field(init=False, default=True, repr=False)
    _recently_actioned: Set[str] = field(init=False, default_factory=set, repr=False)
    _gistt_table: GisttTable = field(init=False, repr=False)
    _scroll_offset: int = field(init=False, default=0, repr=False)
    _last_opened_entry: Optional[CachedGistt] = field(init=False, default=None, repr=False)
    _progress: Optional[Progress] = field(init=False, default=None, repr=False)
    _progress_task: Optional[int] = field(init=False, default=None, repr=False)
    _progress_total: int = field(init=False, default=0, repr=False)
    _bar_table: BarTable = field(init=False, repr=False)

    def __init__(
        self,
        *,
        console: Console,
        session_store: SessionStateStore,
        controller: TableController,
    ) -> None:
        super().__init__(console=console, controller=controller)
        self._session_store = session_store
        self.status_message = "◦ ready..."
        self.footer_message = (
            "g: fetch • tab: action • s: read • z: clear • e: archive • j/k: navigate • h: filter • d: dismiss • b: back • q: quit"
        )
        self._current_results = []
        self._all_results = []
        self._display_index_map = []
        self._filter_unreviewed = True
        self._recently_actioned = set()
        self._gistt_table = GisttTable()
        self._scroll_offset = 0
        self._last_opened_entry = None
        self._progress = None
        self._progress_task = None
        self._progress_total = 0
        self._bar_table = BarTable()

    def prepare_for_entry(self) -> None:
        """Clear transient state before rendering after returning from welcome view."""
        self._recently_actioned.clear()

    def render(self, *, live_factory: Callable[..., Live] = Live) -> Optional[str]:
        """Render the table view and handle user interaction."""
        with live_factory(
            console=self.console,
            refresh_per_second=8,
            transient=False,
            auto_refresh=False,
        ) as live:
            self._hydrate_from_cache()
            live.update(self._build_layout(), refresh=True)
            last_size = self.console.size
            while True:
                key = read_key(timeout=0.1)
                if key is None:
                    current_size = self.console.size
                    if current_size != last_size:
                        last_size = current_size
                        live.update(self._build_layout(), refresh=True)
                    continue

                normalized = key.lower()
                if normalized == "g":
                    self._handle_fetch_request(live)
                    continue

                if normalized == "tab":
                    self._handle_execute_action(live, choice="tab")
                    continue

                if normalized == "d":
                    self._dismiss_actioned_gist(live)
                    continue

                if normalized == "h":
                    self._toggle_unreviewed_filter(live)
                    continue
                if normalized == "enter":
                    entry = self._selected_entry()
                    if entry is None:
                        self.status_message = "no gistt selected."
                        live.update(self._build_layout(), refresh=True)
                        continue
                    self._last_opened_entry = entry
                    return "open-thread"

                resolve_shortcut = getattr(self.controller, "resolve_action_shortcut", None)
                if callable(resolve_shortcut) and resolve_shortcut(key):
                    self._handle_execute_action(live, choice=key)
                    continue

                if normalized in ("j", "ctrl+n", "k", "ctrl+p", "up", "down"):
                    down_keys = {"j", "ctrl+n", "down"}
                    key_hint = "j" if normalized in down_keys else "k"
                    moved = self._handle_selection_input(key_hint)
                    if moved:
                        live.update(self._build_layout(), refresh=True)
                    continue

                display_key = "enter" if key == "" else key
                self.status_message = f"pressed {display_key}"
                live.update(self._build_layout(), refresh=True)

                return key

    # ------------------------------------------------------------------
    # Layout helpers
    # ------------------------------------------------------------------
    def _build_layout(self):
        header = self._build_header()
        body = self._build_body()
        footer = self._build_footer()
        return build_layout(
            header_renderable=header,
            body_renderable=body,
            footer_renderable=footer,
            spacer_size=0,
            header_size=3,
            body_ratio=1,
            footer_size=5,
        )

    def _build_header(self) -> Panel:
        state = self._session_store.load()
        multi_mode = getattr(state, "multi_account_mode", False)
        if multi_mode:
            account_label = "all accounts"
        else:
            account_value = getattr(state, "active_account_email", None)
            account_label = account_value or "Default account"
        account_text = Text(f"active account: {account_label}", style="white")

        meter_markup: Text | None = None
        if self._current_results:
            selection = self._selected_display_position()
            start, end = self._current_window()
            total = len(self._current_results)
            if total > 0:
                meter_markup = self._bar_table.render(
                    start=start,
                    end=end,
                    total=total,
                    selection=selection,
                )

        if meter_markup is None:
            return Panel(account_text, border_style=Palette.PRIMARY, box=box.MINIMAL)

        header_grid = Table.grid(expand=True)
        header_grid.add_column(justify="left", ratio=1)
        header_grid.add_column(justify="right", ratio=1)
        header_grid.add_row(account_text, meter_markup)

        return Panel(header_grid, border_style=Palette.PRIMARY, box=box.MINIMAL)

    def _build_body(self) -> Panel:
        if not self._current_results:
            message = (
                "no unreviewed gistts. press 'h' to show all."
                if self._filter_unreviewed
                else "no gistts available. press 'g' to fetch."
            )
            return Panel(Text(message, style=Palette.PRIMARY), padding=(1, 1), box=box.SIMPLE)

        session_state = self._session_store.load()
        multi_mode = getattr(session_state, "multi_account_mode", False)
        self._ensure_selection_visible()
        selected_index = self._selected_display_position()
        start, end = self._current_window()
        window = self._current_results[start:end]
        visible_index = None
        if selected_index is not None and start <= selected_index < end:
            visible_index = selected_index - start
        table_renderable = self._gistt_table.render(
            window,
            selected_index=visible_index,
            multi_account_mode=multi_mode,
        )
        return Panel(table_renderable, box=box.SIMPLE)

    def _build_footer(self) -> Panel:
        elements = [
            Text(self.footer_message, style=Palette.PRIMARY),
            Text(self.status_message, style="dim"),
        ]
        if self._progress is not None and self._progress_task is not None:
            elements.append(self._progress)
        return Panel(
            Group(*elements),
            padding=(0, 1),
            box=box.SIMPLE,
        )

    # ------------------------------------------------------------------
    # Interaction helpers
    # ------------------------------------------------------------------
    def _hydrate_from_cache(self) -> None:
        self._load_all_results()
        if self._current_results:
            visible = len(self._current_results)
            total = len(self._all_results)
            plural = "" if visible == 1 else "s"
            if self._filter_unreviewed:
                prefix = f"Filtered to {visible} unreviewed gistt{plural}."
            else:
                prefix = f"Loaded {visible} cached gistt{plural}. press 'g' to refresh."
                if total != visible:
                    prefix = f"Loaded {visible}/{total} cached gistt{plural}. press 'g' to refresh."
            self._update_selection_message(prefix=prefix)
        else:
            self.status_message = (
                "no unreviewed gistts available."
                if self._filter_unreviewed
                else "no gistts available."
            )

    def _handle_fetch_request(self, live: Live) -> None:
        self._reset_progress()
        self.status_message = "fetching latest gistts..."
        live.update(self._build_layout(), refresh=True)
        response = self.controller.fetch_gists(
            progress=lambda message: self._update_status(live, message)
        )
        self._reset_progress()
        if response.get("status") != "ok":
            self.status_message = response.get("message", "unable to fetch gistts.")
            live.update(self._build_layout(), refresh=True)
            return

        raw_results = response.get("results") or []
        parsed_results = [item for item in raw_results if isinstance(item, CachedGistt)]

        self._all_results = list(parsed_results)
        self._apply_current_filter()
        self._ensure_selection_visible()
        total_count = response.get("count", len(parsed_results))
        added_count = response.get("added")
        if not isinstance(added_count, int) or added_count < 0:
            added_count = max(total_count, 0)
        if not self._current_results:
            message = response.get("message", None)
            if self._filter_unreviewed:
                self.status_message = message or "no unreviewed gistts available."
            else:
                self.status_message = message or "no gistts available."
        else:
            account = parsed_results[0].gistt.email_message.account if parsed_results else ""
            session_state = self._session_store.load()
            multi_mode = getattr(session_state, "multi_account_mode", False)
            if multi_mode:
                account_hint = " across all accounts"
            else:
                account_label = self._account_label(account)
                account_hint = f" for {account_label}" if account_label else ""
            fetched_at = datetime.now().strftime("%H:%M:%S")
            plural_added = "" if added_count == 1 else "s"
            if added_count > 0:
                prefix = f"fetched {added_count} new gistt{plural_added}{account_hint} at {fetched_at}."
            else:
                prefix = f"no new gistts{account_hint}. refreshed at {fetched_at}."
            if self._filter_unreviewed:
                visible = len(self._current_results)
                vis_plural = "" if visible == 1 else "s"
                prefix = f"{prefix} showing {visible} unreviewed gistt{vis_plural}."
            self._update_selection_message(prefix=prefix)
        live.update(self._build_layout(), refresh=True)

    def _update_status(self, live: Live, message: str) -> None:
        self._maybe_update_progress(message)
        self.status_message = message
        live.update(self._build_layout(), refresh=True)

    # ------------------------------------------------------------------
    # Progress helpers
    # ------------------------------------------------------------------
    _PROGRESS_PATTERN = re.compile(r"producing gistt (\d+)/(\d+)")

    def _maybe_update_progress(self, message: str) -> None:
        if "fetching gmail threads" in message.lower():
            self._reset_progress()
            return

        match = self._PROGRESS_PATTERN.search(message)
        if match:
            completed = int(match.group(1))
            total = int(match.group(2))
            if total <= 0:
                total = max(completed, 1)
            self._ensure_progress(total)
            if self._progress is not None and self._progress_task is not None:
                self._progress_total = max(total, self._progress_total)
                self._progress.update(
                    self._progress_task,
                    completed=min(completed, total),
                    total=total,
                    description="synthwave gistts",
                )
            return

        if "refreshing cached gistts" in message.lower():
            if self._progress is not None and self._progress_task is not None:
                total = self._progress_total or 1
                self._progress.update(
                    self._progress_task,
                    completed=total,
                    total=total,
                    description="cache encore",
                )

    def _ensure_progress(self, total: int) -> None:
        if self._progress is None or self._progress_task is None:
            self._progress = Progress(
                TextColumn(
                    f"[bold {Palette.PINK}]▸▸[/] [bold {Palette.PRIMARY}]{{task.description}}[/]",
                    justify="left",
                ),
                BarProgress(width=self._bar_table.width),
                BarProgressCount(),
                TimeElapsedColumn(),
                expand=True,
            )
            self._progress_task = self._progress.add_task(
                "synthwave gistts",
                total=max(total, 1),
                completed=0,
            )
        else:
            self._progress.update(self._progress_task, total=max(total, 1))
        self._progress_total = max(total, 1)

    def _reset_progress(self) -> None:
        self._progress = None
        self._progress_task = None
        self._progress_total = 0

    # ------------------------------------------------------------------
    # Selection helpers
    # ------------------------------------------------------------------
    def _handle_selection_input(self, key: str) -> bool:
        if not self._current_results:
            self.status_message = "no gistts to select."
            return True

        delta = 1 if key == "j" else -1

        if self._filter_unreviewed:
            position = self._selected_display_position()
            if position is None:
                self.status_message = "no unreviewed gistts available."
                return True
            new_position = position + delta
            if new_position < 0 or new_position >= len(self._display_index_map):
                limit_hint = "end" if delta > 0 else "start"
                self.status_message = f"already at {limit_hint}."
                return True
            target_index = self._display_index_map[new_position]
            self.controller.set_selection(target_index)
            self._update_selection_message()
            self._ensure_selection_visible()
            return True

        total = len(self._display_index_map)
        _, changed = self.controller.move_selection(delta, total)
        if not changed:
            limit_hint = "end" if delta > 0 else "start"
            self.status_message = f"already at {limit_hint}."
            return True

        self._update_selection_message()
        self._ensure_selection_visible()
        return True

    def _handle_execute_action(self, live: Live, *, choice: str = "tab") -> None:
        acted_entry_id: Optional[str] = None
        next_entry_id: Optional[str] = None
        position = self._selected_display_position()
        if position is not None and 0 <= position < len(self._current_results):
            acted_entry_id = self._current_results[position].gistt.email_message.id
            next_position = position + 1
            if 0 <= next_position < len(self._current_results):
                next_entry_id = self._current_results[next_position].gistt.email_message.id

        response = self.controller.handle_choice(choice)
        status = response.get("status")
        message = response.get("message")

        if status != "noop":
            if status == "ok" and acted_entry_id and self._filter_unreviewed:
                self._recently_actioned.add(acted_entry_id)
            self._load_all_results()
            if status == "ok":
                self._select_next_after_action(
                    prior_selection=position,
                    acted_entry_id=acted_entry_id,
                    next_entry_id=next_entry_id,
                )

        if status == "ok":
            action_label = response.get("action", "action")
            summary = message or f"Executed {action_label}."
            self._update_selection_message(prefix=summary)
            message = None
        elif status == "noop":
            self.status_message = message or "no action available."
        else:
            self.status_message = message or "action failed."

        if message:
            self.status_message = message

        live.update(self._build_layout(), refresh=True)

    def _update_selection_message(self, *, prefix: Optional[str] = None) -> None:
        if not self._current_results:
            if self._filter_unreviewed:
                self.status_message = "no unreviewed gistts available."
            else:
                self.status_message = "no gistts available."
            return

        position = self._selected_display_position()
        if position is None:
            if self._filter_unreviewed:
                self.status_message = "no unreviewed gistts available."
            else:
                self.status_message = "no gistts to select."
            return

        total = len(self._current_results)
        selected = self._current_results[position]
        subject = selected.gistt.email_message.subject or "(no subject)"
        subject = subject.strip() or "(no subject)"
        account_label = self._account_label(selected.gistt.email_message.account)
        if account_label:
            selection_label = f"Selected {position + 1}/{total} ({account_label}): {subject}"
        else:
            selection_label = f"Selected {position + 1}/{total}: {subject}"
        if prefix:
            self.status_message = f"{prefix} {selection_label}"
        else:
            self.status_message = selection_label

    def _select_next_after_action(
        self,
        *,
        prior_selection: Optional[int],
        acted_entry_id: Optional[str],
        next_entry_id: Optional[str],
    ) -> None:
        """Advance the selection to the next visible entry after executing an action."""
        if not self._current_results or not self._display_index_map:
            return

        target_display_index: Optional[int] = None

        if next_entry_id:
            for index, entry in enumerate(self._current_results):
                if entry.gistt.email_message.id == next_entry_id:
                    target_display_index = index
                    break

        if target_display_index is None and acted_entry_id:
            for index, entry in enumerate(self._current_results):
                if entry.gistt.email_message.id == acted_entry_id:
                    candidate = index + 1 if index + 1 < len(self._current_results) else index
                    target_display_index = candidate
                    break

        if target_display_index is None and prior_selection is not None:
            if prior_selection < len(self._current_results):
                target_display_index = prior_selection
            else:
                target_display_index = len(self._current_results) - 1

        if target_display_index is None:
            target_display_index = len(self._current_results) - 1

        target_display_index = max(0, min(target_display_index, len(self._current_results) - 1))

        if target_display_index >= len(self._display_index_map):
            target_display_index = len(self._display_index_map) - 1

        raw_index = self._display_index_map[target_display_index]
        self.controller.set_selection(raw_index)
        self._ensure_selection_visible()

    # ------------------------------------------------------------------
    # Filtering helpers
    # ------------------------------------------------------------------
    @staticmethod
    def _account_label(account: Optional[str]) -> str:
        value = (account or "").strip()
        return value or "Default account"

    def _toggle_unreviewed_filter(self, live: Live) -> None:
        self._filter_unreviewed = not self._filter_unreviewed
        if not self._filter_unreviewed:
            # Switching to the full list should drop the temporary "recent" list
            # so returning to unreviewed mode hides completed gistts again.
            self._recently_actioned.clear()
        self._load_all_results()
        self._ensure_selection_visible()

        if not self._current_results:
            if self._filter_unreviewed:
                self.status_message = "no unreviewed gistts available."
            else:
                self.status_message = "no gistts available."
        else:
            visible = len(self._current_results)
            plural = "" if visible == 1 else "s"
            if self._filter_unreviewed:
                prefix = f"Filtered to {visible} unreviewed gistt{plural}."
            else:
                total = len(self._all_results)
                prefix = f"Showing all gistts ({visible})"
                if visible != total:
                    prefix = f"Showing {visible}/{total} gistts."
            self._update_selection_message(prefix=prefix)
        live.update(self._build_layout(), refresh=True)

    def _dismiss_actioned_gist(self, live: Live) -> None:
        active_ids = {
            entry.gistt.email_message.id
            for entry in self._current_results
            if getattr(entry.gistt, "state", None)
        }
        if not active_ids and not self._recently_actioned:
            self.status_message = "no completed gistts to dismiss."
            live.update(self._build_layout(), refresh=True)
            return

        self._recently_actioned.clear()
        message = "Dismissed completed gistts."

        self._apply_current_filter()
        self._ensure_selection_visible()
        if self._current_results:
            self._update_selection_message(prefix=message)
        else:
            self.status_message = (
                "no unreviewed gistts available." if self._filter_unreviewed else "no gistts available."
            )
        live.update(self._build_layout(), refresh=True)

    def _load_all_results(self) -> None:
        cached_entries = self.controller.cached_results()
        self._all_results = list(cached_entries)
        self._apply_current_filter()
        self._ensure_selection_visible()

    def _apply_current_filter(self) -> None:
        valid_ids = {entry.gistt.email_message.id for entry in self._all_results}
        if self._recently_actioned:
            self._recently_actioned.intersection_update(valid_ids)

        if self._filter_unreviewed:
            indices = [
                index
                for index, entry in enumerate(self._all_results)
                if (
                    not getattr(entry.gistt, "state", None)
                    or entry.gistt.email_message.id in self._recently_actioned
                )
            ]
        else:
            indices = list(range(len(self._all_results)))
        self._display_index_map = indices
        self._current_results = [self._all_results[i] for i in indices]
        self._scroll_offset = 0
        self._sync_selection_to_display()
        if not self._current_results:
            self.status_message = (
                "no unreviewed gistts available."
                if self._filter_unreviewed
                else "no gistts available."
            )

    def _sync_selection_to_display(self) -> None:
        if not self._display_index_map:
            return
        selection = self.controller.current_selection()
        if selection in self._display_index_map:
            return
        self.controller.set_selection(self._display_index_map[0])

    def _selected_display_position(self) -> Optional[int]:
        if not self._display_index_map:
            return None
        selection = self.controller.current_selection()
        try:
            return self._display_index_map.index(selection)
        except ValueError:
            self.controller.set_selection(self._display_index_map[0])
            return 0

    def _selected_entry(self) -> Optional[CachedGistt]:
        position = self._selected_display_position()
        if position is None:
            return None
        if not (0 <= position < len(self._current_results)):
            return None
        return self._current_results[position]

    def _ensure_selection_visible(self) -> None:
        if not self._current_results:
            self._scroll_offset = 0
            return

        viewport = self._compute_viewport_size()
        if viewport <= 0:
            self._scroll_offset = 0
            return

        position = self._selected_display_position()
        if position is None:
            self._scroll_offset = 0
            return

        max_offset = max(0, len(self._current_results) - viewport)
        if position < self._scroll_offset:
            self._scroll_offset = position
        elif position >= self._scroll_offset + viewport:
            self._scroll_offset = position - viewport + 1

        if self._scroll_offset > max_offset:
            self._scroll_offset = max_offset
        if self._scroll_offset < 0:
            self._scroll_offset = 0

    def _current_window(self) -> tuple[int, int]:
        if not self._current_results:
            return (0, 0)
        viewport = self._compute_viewport_size()
        if viewport <= 0 or viewport >= len(self._current_results):
            return (0, len(self._current_results))
        start = min(self._scroll_offset, max(0, len(self._current_results) - viewport))
        end = min(len(self._current_results), start + viewport)
        return (start, end)

    def _compute_viewport_size(self) -> int:
        """Estimate how many gistts can be shown without overflowing the terminal."""
        console_size = getattr(self.console, "size", None)
        console_height = console_size.height if console_size else 24
        # Reserve generous space for header/footer panels, borders, and padding.
        reserved = 12
        available = max(3, console_height - reserved)
        # Approximate height per gistt row: preview lines plus metadata and group headers.
        # Allow extra headroom for group headers, padding, and spacing between rows.
        approx_per_gistt = max(4, self._gistt_table.max_preview_lines + 3)
        viewport = max(5, available // approx_per_gistt)
        return viewport

    def consume_last_opened_entry(self) -> Optional[CachedGistt]:
        """Return the last entry opened in the thread view and clear the reference."""
        entry = self._last_opened_entry
        self._last_opened_entry = None
        return entry
