"""Minimal CLI entry point that presents the welcome view and persists selection."""
from __future__ import annotations

import argparse
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Optional, Sequence

from rich.console import Console
from rich.live import Live

from gistt.services.gmail_accounts import AccountConfig, AccountManager as GmailAccountManager
from gistt.services.gmail_ops import GmailOps
from gistt.services.gistt_producer import GisttProducer
from gistt.settings import Settings
from gistt.controller.session_state import SessionStateStore
from gistt.controller.table_controller import TableController
from gistt.controller.thread_controller import ThreadController
from gistt.ui.welcome_view import WelcomeView
from gistt.ui.table_view import TableView
from gistt.ui.thread_view import ThreadView
from gistt.models import Action, ActionGroupRec


DEFAULT_CLIENT_SECRETS = Path.home() / ".config" / "gistt" / "client_secret.json"
CLIENT_SECRETS_ENV = "GISTT_CLIENT_CREDENTIALS"
DEFAULT_LOG_FILE = Path.home() / ".local" / "share" / "gistt" / "logs" / "gistt.log"


class WelcomeAccountManager:
    """Adapter that exposes the subset of account operations needed by the welcome view."""

    def __init__(self, console: Console, delegate: GmailAccountManager) -> None:
        self._console = console
        self._delegate = delegate

    # ------------------------------------------------------------------
    # Interface consumed by WelcomeView
    # ------------------------------------------------------------------
    def list_accounts(self) -> list[AccountConfig]:
        return self._delegate.list()

    def link_account(self) -> Optional[AccountConfig]:
        client_path = self._credentials_path()
        if not client_path.exists():
            env_hint = CLIENT_SECRETS_ENV
            self._console.print(
                "[yellow]no OAuth client credentials found. "
                f"place client_secret.json at {DEFAULT_CLIENT_SECRETS} or set {env_hint}. "
                f"last attempted path: {client_path}[/yellow]"
            )
            return None
        try:
            return self._delegate.link_account(client_path)
        except Exception as error:  # noqa: BLE001 - surfacing environment issues
            self._console.print(f"[red]failed to link gmail account: {error}[/red]")
            return None

    # ------------------------------------------------------------------
    # Helpers used by the CLI shell
    # ------------------------------------------------------------------
    def current_account(self) -> Optional[AccountConfig]:
        return self._delegate.get_current()

    def find_account(self, email: Optional[str]) -> Optional[AccountConfig]:
        if not email:
            return None
        return self._delegate.get(email)

    def set_current(self, account: AccountConfig) -> None:
        self._delegate.set_current(account)

    def _credentials_path(self) -> Path:
        override = os.environ.get(CLIENT_SECRETS_ENV)
        if override:
            return Path(override).expanduser()

        return DEFAULT_CLIENT_SECRETS


@dataclass
class GisttCLI:
    console: Console
    settings: Settings
    account_manager: WelcomeAccountManager
    welcome_view: WelcomeView
    session_store: SessionStateStore
    table_controller: TableController
    table_view: TableView
    thread_controller: ThreadController
    thread_view: ThreadView
    _config: SimpleNamespace = field(default_factory=lambda: SimpleNamespace(settings=None), repr=False)

    @classmethod
    def create(cls) -> "GisttCLI":
        console = Console()
        delegate = GmailAccountManager()
        account_manager = WelcomeAccountManager(console=console, delegate=delegate)
        session_store = SessionStateStore()
        settings = Settings()
        gmail_ops = GmailOps(account_manager=delegate, settings=settings)
        gistt_producer = GisttProducer()
        table_controller = TableController(
            session_store=session_store,
            gmail_ops=gmail_ops,
            settings=settings,
            gistt_producer=gistt_producer,
        )
        welcome_view = WelcomeView(
            console=console,
            account_manager=account_manager,
            session_store=session_store,
        )
        thread_controller = ThreadController(session_store=session_store)
        thread_view = ThreadView(
            console=console,
            controller=thread_controller,
        )
        table_view = TableView(
            console=console,
            session_store=session_store,
            controller=table_controller,
        )
        config = SimpleNamespace(settings=settings)
        return cls(
            console=console,
            settings=settings,
            account_manager=account_manager,
            welcome_view=welcome_view,
            session_store=session_store,
            table_controller=table_controller,
            table_view=table_view,
            thread_controller=thread_controller,
            thread_view=thread_view,
            _config=config,
        )

    def run(self) -> int:
        session = self.session_store.load()

        while True:
            current_account = self.account_manager.find_account(session.active_account_email)
            if not current_account and not session.multi_account_mode:
                current_account = self.account_manager.current_account()

            selected, multi_account_mode, should_continue = self.welcome_view.render(
                current_account=current_account,
                multi_account_mode=session.multi_account_mode,
                live_factory=Live,
            )

            if not should_continue:
                return 0

            active_email: Optional[str] = None
            if selected and not multi_account_mode:
                self.account_manager.set_current(selected)
                active_email = selected.email

            session = self.session_store.update(
                active_account_email=active_email,
                multi_account_mode=multi_account_mode,
            )

            # When the user links an account, immediately show the welcome view again.
            if self.welcome_view.choice.lower() == "l" and selected is not None:
                continue

            back_to_welcome = self._render_table_view()
            if back_to_welcome:
                continue
            return 0

    def _render_table_view(self) -> bool:
        self.table_view.prepare_for_entry()
        while True:
            self.console.clear()
            key = self.table_view.render()
            normalized = (key or "").lower()
            if normalized == "open-thread":
                entry = self.table_view.consume_last_opened_entry()
                if entry is None:
                    continue
                self.console.clear()
                thread_result = self.thread_view.render(entry)
                if (thread_result or "").lower() == "quit":
                    return False
                continue
            if normalized == "b":
                return True
            return False

    def _group_summaries_by_action(self, summaries: Sequence[Any]) -> list[tuple[str, list[Any]]]:
        """Bucket summaries by recommended action group ordered by configured priority."""
        buckets: dict[str, dict[str, Any]] = {}
        for summary in summaries:
            recommendation = self._get_ai_recommendation(summary)
            action_group = recommendation.action_group if recommendation else None  # type: ignore[attr-defined]
            if action_group is None:
                name = "Other"
                priority = 1000
            else:
                name = getattr(action_group, "group", "Other") or "Other"
                priority = getattr(action_group, "priority", 1000)
            bucket = buckets.setdefault(name, {"items": [], "priority": priority})
            bucket["items"].append(summary)
            if priority < bucket["priority"]:
                bucket["priority"] = priority

        ordered = sorted(
            buckets.items(),
            key=lambda item: (item[1]["priority"], item[0].lower()),
        )
        return [(name, payload["items"]) for name, payload in ordered]

    def _priority_selection_index(self, summaries: Sequence[Any]) -> int:
        """Return the index of the highest-priority summary, falling back to zero."""
        grouped = self._group_summaries_by_action(summaries)
        if not grouped:
            return 0

        for _, items in grouped:
            for item in items:
                try:
                    return summaries.index(item)  # type: ignore[arg-type]
                except ValueError:
                    continue
        return 0

    def _recommended_option(self, recommendation: ActionGroupRec | None) -> str:
        """Map an action recommendation to its preferred keyboard shortcut."""
        if recommendation is None or recommendation.action_group is None:
            return ""

        action = recommendation.action_group.action
        if isinstance(action, Action):
            shortcuts = getattr(action, "shortcuts", ()) or ()
            if shortcuts:
                return shortcuts[0]
            name = getattr(action, "name", "")
            return name[:1].lower() if name else ""

        if isinstance(action, str):
            mapping = {
                "archive": "e",
                "read": "s",
                "reply": "r",
                "clear": "z",
                "dismiss": "d",
                "save": "s",
                "quit": "q",
            }
            normalized = action.strip().lower()
            if not normalized:
                return ""
            return mapping.get(normalized, normalized[0])

        return ""

    def _get_ai_recommendation(self, summary: Any) -> ActionGroupRec | None:
        """Placeholder hook for retrieving AI recommendations (patched in tests)."""
        return getattr(summary, "recommendation", None)

def _parse_cli_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="gistt",
        description="terminal assistant for gmail triage and drafting.",
    )
    parser.add_argument(
        "-debug",
        "--debug",
        action="store_true",
        help="enable verbose debug logging output.",
    )
    parser.add_argument(
        "--log-level",
        choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
        type=str.upper,
        help="override logging level without enabling full debug output.",
    )
    parser.add_argument(
        "--log-file",
        type=str,
        help=f"write log output to a file (default: {DEFAULT_LOG_FILE}).",
    )
    return parser.parse_args(argv)


def _configure_logging(args: argparse.Namespace) -> None:
    level: Optional[int] = None
    if getattr(args, "debug", False):
        level = logging.DEBUG
    elif getattr(args, "log_level", None):
        level = getattr(logging, args.log_level, logging.INFO)

    log_file_arg = getattr(args, "log_file", None)
    log_file = Path(log_file_arg).expanduser() if log_file_arg else None
    if log_file is None and level is not None:
        log_file = DEFAULT_LOG_FILE

    handlers = []
    if level is not None:
        handlers.append(logging.StreamHandler())
    if log_file is not None:
        log_file.parent.mkdir(parents=True, exist_ok=True)
        handlers.append(logging.FileHandler(log_file, encoding="utf-8"))

    if handlers:
        logging.basicConfig(
            level=level or logging.INFO,
            format="%(asctime)s %(levelname)s %(name)s: %(message)s",
            handlers=handlers,
            force=True,
        )


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = _parse_cli_args(argv)
    _configure_logging(args)
    cli = GisttCLI.create()
    return cli.run()


if __name__ == "__main__":
    raise SystemExit(main())
