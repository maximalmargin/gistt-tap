"""Rich table component for displaying gistts grouped by recommendation."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, List, Sequence, Tuple

from rich import box
from rich.table import Table
from rich.text import Text

from gistt.models import ActionGroup
from gistt.services.gistt_cache_store import CachedGistt
from gistt.services.utils import format_relative_time, parse_timestamp
from gistt.ui.palette import Palette


@dataclass
class GisttTable:
    """Renderable table showing cached gistts grouped by recommended action."""

    max_preview_lines: int = 3
    preview_char_limit: int = 1000

    def render(
        self,
        results: Sequence[CachedGistt],
        *,
        selected_index: int | None = None,
        multi_account_mode: bool = False,
    ) -> Table:
        """Return a Rich table populated with gistt metadata."""
        table = Table(
            header_style=f"bold {Palette.PRIMARY}",
            expand=True,
            show_lines=False,
            box=box.SIMPLE_HEAVY,
            pad_edge=False,
            padding=(1, 1),
        )
        table.add_column("", justify="center", width=2, no_wrap=True)
        table.add_column(
            "state",
            justify="left",
            ratio=1,
            min_width=9,
            no_wrap=True,
            overflow="ellipsis",
        )
        table.add_column(
            "gistt",
            justify="left",
            ratio=7,
            min_width=40,
            overflow="fold",
            no_wrap=False,
        )
        table.add_column(
            "subject",
            justify="left",
            ratio=2,
            min_width=18,
            no_wrap=True,
            overflow="ellipsis",
        )
        table.add_column(
            "sender",
            justify="left",
            ratio=2,
            min_width=16,
            no_wrap=True,
            overflow="ellipsis",
        )
        table.add_column(
            "account",
            justify="left",
            ratio=1,
            min_width=10,
            no_wrap=True,
            overflow="ellipsis",
        )
        table.add_column(
            "when",
            justify="right",
            ratio=1,
            min_width=9,
            no_wrap=True,
            overflow="ellipsis",
        )

        grouped = self._group_by_action(results)
        active_index = selected_index if isinstance(selected_index, int) and selected_index >= 0 else None
        row_index = 0

        if not grouped:
            table.add_row(
                Text("·", style="dim"),
                Text("◦ no gistts available.", style=Palette.PRIMARY),
                Text(""),
                Text(""),
                Text(""),
                Text(""),
                Text(""),
            )
            return table

        for index, (group_name, items) in enumerate(grouped):
            header_label = Text(f"■ {group_name} ({len(items)})", style=f"bold {Palette.PINK}")
            table.add_row(
                Text(" ", style="dim"),
                Text(""),
                header_label,
                Text(""),
                Text(""),
                Text(""),
                Text(""),
            )

            for cached in items:
                gistt = cached.gistt
                email = gistt.email_message
                is_selected = active_index == row_index
                marker = Text("▶", style=f"bold {Palette.GREEN}") if is_selected else Text(" ", style="dim")
                state_text = self._state_text(gistt.state)
                gistt_text = self._summarize(gistt.content)
                subject_text = self._subject_text(email.subject)
                sender_text = self._sender_text(email.sender, email.is_from_user)
                account_text = self._account_text(email.account, collapse_domain=multi_account_mode)
                when_text = self._when_text(email.time, cached.cached_at)

                if is_selected:
                    for cell in (state_text, gistt_text, subject_text, sender_text, account_text, when_text):
                        cell.stylize("bold")

                table.add_row(
                    marker,
                    state_text,
                    gistt_text,
                    subject_text,
                    sender_text,
                    account_text,
                    when_text,
                )
                row_index += 1

            if index < len(grouped) - 1:
                table.add_section()

        return table

    def _group_by_action(self, results: Sequence[CachedGistt]) -> List[Tuple[str, List[CachedGistt]]]:
        """Group gistts by their recommended action label."""
        grouped: Dict[str, Dict[str, Any]] = {}
        for cached in results:
            label = self._group_label(cached)
            priority = self._group_priority(cached)
            bucket = grouped.setdefault(label, {"items": [], "priority": priority})
            bucket["items"].append(cached)
            if priority < bucket["priority"]:
                bucket["priority"] = priority

        if not grouped:
            return []

        ordered_groups = sorted(
            grouped.items(),
            key=lambda item: (item[1]["priority"], item[0].lower()),
        )
        return [(label, payload["items"]) for label, payload in ordered_groups]

    def _group_label(self, cached: CachedGistt) -> str:
        group = self._resolve_action_group(cached)
        if group and group.group:
            return group.group
        return "other"

    def _group_priority(self, cached: CachedGistt) -> int:
        group = self._resolve_action_group(cached)
        if group and hasattr(group, "priority"):
            try:
                return int(getattr(group, "priority"))
            except (TypeError, ValueError):
                return 100
        return 100

    def _resolve_action_group(self, cached: CachedGistt) -> ActionGroup | None:
        gistt = cached.gistt
        if gistt.recommendation and gistt.recommendation.action_group:
            return gistt.recommendation.action_group
        return gistt.action_group

    def _state_text(self, state) -> Text:
        if not state:
            return Text("-", style="dim", overflow="ellipsis", no_wrap=True)
        label = getattr(state, "value", None) or str(state)
        return Text(self._trim(label, 16), style=Palette.YELLOW, overflow="ellipsis", no_wrap=True)

    def _summarize(self, content: str | None) -> Text:
        """Return a short preview of the gistt content."""
        if not content:
            return Text("◦ (no gistt available.)", style="dim")

        lines = [line.strip() for line in content.splitlines() if line.strip()]
        if not lines:
            return Text("◦ (no gistt available.)", style="dim")

        preview = lines[: self.max_preview_lines]
        trimmed = [self._trim(line, self.preview_char_limit) for line in preview]
        if len(lines) > self.max_preview_lines:
            trimmed[-1] = self._append_ellipsis(trimmed[-1])
        text = "\n".join(trimmed)
        return Text(text, style="boldwhite")

    def _subject_text(self, subject: str | None) -> Text:
        value = subject.strip() if subject else "(no subject)"
        return Text(self._trim(value, 60), overflow="ellipsis", no_wrap=True, style="dim")

    def _sender_text(self, sender: str | None, is_from_user: bool) -> Text:
        base = sender.strip() if sender else "(unknown sender)"
        text = Text(self._trim(base, 30), no_wrap=True, overflow="ellipsis", style=Palette.PRIMARY)
        if is_from_user:
            text.append(" ◂you", style=Palette.GREEN)
        return text

    def _account_text(self, account: str | None, *, collapse_domain: bool = False) -> Text:
        value = (account or "").strip()
        if not value:
            return Text("default account", style="dim", no_wrap=True, overflow="ellipsis")
        display = value
        return Text(self._trim(display, 40), style="white", no_wrap=True, overflow="ellipsis")

    def _when_text(self, email_time: str | None, cached_time: str | None) -> Text:
        timestamp = parse_timestamp(email_time) or parse_timestamp(cached_time)
        when_text = self._format_when(timestamp)
        when_text.no_wrap = True
        when_text.overflow = "ellipsis"
        return when_text

    @staticmethod
    def _format_when(timestamp: datetime | None) -> Text:
        if not timestamp:
            return Text("-", style="dim")

        now = datetime.now(timezone.utc)
        relative = format_relative_time(timestamp.isoformat(), now=now)
        if relative is None:
            display = timestamp.astimezone().strftime("%Y-%m-%d")
            return Text(display, style="dim", no_wrap=True, overflow="ellipsis")

        style = "dim"
        if relative == "in future":
            style = "dim"
        elif relative == "just now" or relative.endswith("m ago"):
            style = Palette.GREEN
        elif relative.endswith("h ago") or relative.endswith("d ago"):
            style = Palette.YELLOW
        else:
            style = "dim"

        return Text(relative, style=style, no_wrap=True, overflow="ellipsis")

    @staticmethod
    def _trim(value: str, limit: int) -> str:
        """Trim a string to a character limit with ellipsis."""
        if len(value) <= limit:
            return value
        return value[: max(0, limit - 1)].rstrip() + "…"

    @staticmethod
    def _append_ellipsis(value: str) -> str:
        return value.rstrip("…") + "…"
