"""Centralized color palette for the terminal UI."""


class Palette:
    """Synthwave-inspired color constants used across the UI."""

    BACKGROUND = "#0c1445"
    PRIMARY = "#00ffff"
    PINK = "#ff6ec7"
    GREEN = "#39ff14"
    YELLOW = "#f9f871"
