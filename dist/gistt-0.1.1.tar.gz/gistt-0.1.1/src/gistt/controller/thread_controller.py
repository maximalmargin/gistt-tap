"""Controller utilities for the thread view."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional
from urllib.parse import quote

from gistt.controller.base import Controller
from gistt.controller.session_state import SessionStateStore
from gistt.models import EmailMessage


@dataclass
class ThreadController(Controller):
    """Lightweight controller that provides helpers for the thread view."""

    session_store: Optional[SessionStateStore] = None

    def handle_choice(self, choice: str) -> Dict[str, Any]:
        """Thread view does not currently support actions."""
        return {"status": "noop", "choice": choice}

    def _persist_session(self, **kwargs: Any) -> None:
        """Persist the current session snapshot when available."""
        if not self.session_store:
            return
        state = self.session_store.load()
        self.session_store.save(state)

    def gmail_link(self, email: EmailMessage) -> str:
        """Return a Gmail URL pointing to the thread or, as a fallback, the message."""
        account_path = "u/0"
        account_email = self._resolve_account_email(email)
        query = f"?authuser={quote(account_email)}" if account_email else ""
        thread_id = getattr(getattr(email, "context", None), "id", None)
        if thread_id:
            return f"https://mail.google.com/mail/{account_path}/{query}#inbox/{thread_id}"
        message_id = email.id or "unknown"
        return f"https://mail.google.com/mail/{account_path}/{query}#all/{message_id}"

    def _resolve_account_email(self, email: EmailMessage) -> Optional[str]:
        """Resolve the Gmail account email associated with the message."""
        if email.account:
            normalized = email.account.strip()
            if normalized:
                return normalized
        if not self.session_store:
            return None
        state = self.session_store.load()
        account_email = getattr(state, "active_account_email", None)
        if isinstance(account_email, str):
            normalized = account_email.strip()
            if normalized:
                return normalized
        return None
