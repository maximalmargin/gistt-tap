from abc import ABC, abstractmethod
from typing import Any

class Controller(ABC):
    @abstractmethod
    def handle_choice(self, choice: str) -> Any:
        """Handle the choice for the view."""

    @abstractmethod
    def _persist_session(self, **kwargs: Any) -> None:
        """Persist the session state."""