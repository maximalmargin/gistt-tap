"""Core data models shared across the application."""
from __future__ import annotations

from abc import ABC
from dataclasses import dataclass, field
from typing import Any, List, Optional
import re
from enum import Enum


# ---------------------------------------------------------------------------
# Email domain models
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class EmailMessage:
    """Single email message fetched from API."""

    id: str
    sender: str
    subject: str
    time: str
    body: str
    is_from_user: bool
    account: str
    context: Optional[EmailContext] = None

    def thread_id(self, *, allow_message_fallback: bool = False) -> Optional[str]:
        """Return the Gmail thread identifier associated with this message."""
        context = getattr(self, "context", None)
        thread_id = getattr(context, "id", None) if context is not None else None
        if thread_id:
            return thread_id
        if allow_message_fallback:
            fallback = getattr(self, "id", None)
            return fallback or None
        return None

    def account_email(self) -> Optional[str]:
        """Return the Gmail account email for this message, if available."""
        account = getattr(self, "account", None)
        return account or None


@dataclass(frozen=True)
class EmailContext:
    """Context of related email messages."""

    id: str
    messages: List[EmailMessage]

    @property
    def count(self) -> int:
        return len(self.messages)


@dataclass(frozen=True)
class Action(ABC):
    """Executable operation that can be taken on a gist."""

    name: str
    shortcuts: List[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        if not self._is_supported():
            raise ValueError(f"Action {self.name} is not supported")

    def _is_supported(self) -> bool:
        return self.name in {"archive", "read", "clear", "reply", "dismiss", "save", "quit"}

    def execute(self, gistt: "Gistt", client: Any) -> bool:
        """Execute the action against the provided gistt."""
        raise NotImplementedError

    @property
    def labels_to_add(self) -> tuple[str, ...]:
        """Labels automatically applied when the action executes."""
        return ("gistt",)

    @property
    def labels_to_remove(self) -> tuple[str, ...]:
        """Labels automatically removed when the action executes."""
        return ()


@dataclass(frozen=True)
class ActionGroup:
    """Grouping of related actions with instructional context."""

    group: str
    action: Optional[Action]
    condition: str = ""
    instruction: str = ""
    priority: int = 100

    @property
    def canonical_name(self) -> str:
        canonical = re.compile(r"[^a-z0-9]+").sub(" ", self.group.lower())
        parts = [segment for segment in canonical.split() if segment]
        return "_".join(parts)


@dataclass(frozen=True)
class ActionGroupRec:
    """Recommendation returned by GenAI describing the suggested action."""

    action_group: ActionGroup
    explanation: str


# ---------------------------------------------------------------------------
# gistt domain models
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Gistt:
    """Summarised insight for an email thread."""

    content: str
    email_message: EmailMessage
    action_group: Optional[ActionGroup] = None
    recommendation: Optional[ActionGroupRec] = None
    state: "GisttState" | None = None

class GisttState(str, Enum):
    """Lifecycle states a gistt can move through."""

    SAVED = "saved"
    ARCHIVED = "archived"
    REVIEWED = "reviewed"
    DRAFTED = "drafted"

# ---------------------------------------------------------------------------
# Drafting models
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class DraftRequest:
    """Draft request payload."""

    to: str
    subject: str
    body: str
    thread_id: Optional[str] = None

@dataclass(frozen=True)
class DraftResult:
    """Draft creation result from Gmail."""

    draft_id: str
    to: str
    subject: str
    body: str
    thread_id: Optional[str] = None
