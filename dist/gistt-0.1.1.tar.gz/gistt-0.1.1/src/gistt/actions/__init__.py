"""Action registry helpers."""
from __future__ import annotations

from typing import Dict

from gistt.models import Action

from .archive import ArchiveAction
from .clear import ClearAction
from .read import ReadAction
from .reply import ReplyAction

_DEFAULT_ACTIONS: Dict[str, Action] = {
    "archive": ArchiveAction(),
    "read": ReadAction(),
    "clear": ClearAction(),
    "reply": ReplyAction(),
}


def available_actions() -> Dict[str, Action]:
    """Return the default set of available actions keyed by canonical name."""
    return dict(_DEFAULT_ACTIONS)


__all__ = ["available_actions"]
