"""Read action - clears the unread label from a thread."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from gistt.models import Action, Gistt
from gistt.services.gmail_ops import GmailOps


@dataclass(frozen=True)
class ReadAction(Action):
    """Marks a gistt as read by clearing the UNREAD label on its thread."""

    name: str = "read"
    shortcuts: List[str] = field(default_factory=lambda: ["s"])

    def execute(self, gistt: Gistt, client: GmailOps) -> bool:
        """Execute the read action."""
        if client is None or gistt is None:
            return False

        email = getattr(gistt, "email_message", None)
        if email is None:
            return False

        thread_id = email.thread_id()
        if not thread_id:
            return False

        account_email = email.account_email()
        return client.modify_thread_labels(
            account_email=account_email,
            thread_id=thread_id,
            add_labels=list(self.labels_to_add),
            remove_labels=list(self.labels_to_remove),
        )

    @property
    def labels_to_remove(self) -> tuple[str, ...]:
        return ("UNREAD",)
