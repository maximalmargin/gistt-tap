from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
import json
from tempfile import TemporaryDirectory
from typing import Dict, Optional, Sequence
from unittest.mock import MagicMock
from types import SimpleNamespace

from gistt.controller.session_state import SessionStateStore
from gistt.controller.table_controller import TableController
from gistt.models import ActionGroup, ActionGroupRec, EmailContext, EmailMessage, Gistt, GisttState
from gistt.settings import Settings
from gistt.services.gistt_cache_store import GisttCacheStore, CachedGistt
from gistt.services.gistt_producer import GisttProducer


class DummyGmailOps:
    def __init__(
        self,
        results: Optional[list[tuple[EmailMessage, EmailContext]]],
        *,
        accounts: Optional[list[str]] = None,
    ) -> None:
        self._results = results
        self.called = False
        self.last_limit: Optional[int] = None
        self.modified_calls: list[Dict[str, object]] = []
        self._accounts = [SimpleNamespace(email=email) for email in accounts or []]

    def fetch_messages_with_context(self, **kwargs: object) -> Optional[list[tuple[EmailMessage, EmailContext]]]:
        self.called = True
        limit = kwargs.get("limit")
        if isinstance(limit, int):
            self.last_limit = limit
        return self._results

    def list_accounts(self) -> list[SimpleNamespace]:
        return list(self._accounts)

    def modify_thread_labels(
        self,
        *,
        account_email: Optional[str] = None,
        thread_id: str,
        add_labels: Optional[list[str]] = None,
        remove_labels: Optional[list[str]] = None,
    ) -> bool:
        self.modified_calls.append(
            {
                "account_email": account_email,
                "thread_id": thread_id,
                "add_labels": list(add_labels or []),
                "remove_labels": list(remove_labels or []),
            }
        )
        return True


class StubCacheStore:
    def __init__(self, entries: list[CachedGistt]) -> None:
        self._entries = list(entries)
        self.upsert_calls: list[tuple[EmailMessage, Gistt]] = []

    def list_for_account(
        self,
        account_email: Optional[str],
        *,
        limit: Optional[int] = None,
    ) -> list[CachedGistt]:
        items = list(self._entries)
        if limit is None or limit < 0 or limit >= len(items):
            return items
        return items[:limit]

    def list_for_accounts(
        self,
        accounts: Optional[Sequence[Optional[str]]] = None,
        *,
        limit: Optional[int] = None,
    ) -> list[CachedGistt]:
        items = list(self._entries)
        if accounts is not None:
            normalized = {str(account or "").lower() for account in accounts}
            items = [
                entry
                for entry in items
                if entry.gist.email_message.account.lower() in normalized
                or (not entry.gist.email_message.account and "" in normalized)
            ]
        if limit is None or limit < 0 or limit >= len(items):
            return items
        return items[:limit]

    def upsert(self, email_message: EmailMessage, gist: Gistt) -> CachedGistt:
        replacement = CachedGistt(gist=gist, cached_at="persisted")
        for index, entry in enumerate(self._entries):
            if entry.gist.email_message.id == email_message.id:
                self._entries[index] = replacement
                break
        else:
            self._entries.append(replacement)
        self.upsert_calls.append((email_message, gist))
        return replacement


class StubGisttProducer:
    def __init__(self, entries: list[CachedGistt]) -> None:
        self.cache_store = StubCacheStore(entries)

    def cached_gists(
        self,
        *,
        account_email: Optional[str] = None,
        limit: Optional[int] = None,
        account_emails: Optional[Sequence[Optional[str]]] = None,
    ) -> list[CachedGistt]:
        if account_emails is not None:
            return self.cache_store.list_for_accounts(account_emails, limit=limit)
        return self.cache_store.list_for_account(account_email, limit=limit)

    def produce(self, email_message: EmailMessage) -> None:  # pragma: no cover - not needed in tests
        return None

    def produce_many(
        self,
        email_messages,
        *,
        max_workers: Optional[int] = None,
        progress = None,
    ) -> None:
        emails = list(email_messages)
        total = len(emails)
        for index, email in enumerate(emails, start=1):
            if progress:
                progress(index, total, email)
            self.produce(email)


def _sample_result() -> tuple[EmailMessage, EmailContext]:
    latest = EmailMessage(
        id="msg-2",
        sender="sender@example.com",
        subject="Follow-up required",
        time="2024-01-02T00:00:00Z",
        body="Can we align on the next steps for the launch?",
        is_from_user=False,
        account="",
    )
    context = EmailContext(
        id="thread-1",
        messages=[
            EmailMessage(
                id="msg-1",
                sender="colleague@example.com",
                subject="Initial request",
                time="2024-01-01T00:00:00Z",
                body="Sharing the briefing document for review.",
                is_from_user=False,
                account="",
            ),
            latest,
        ],
    )
    enriched = EmailMessage(
        id=latest.id,
        sender=latest.sender,
        subject=latest.subject,
        time=latest.time,
        body=latest.body,
        is_from_user=latest.is_from_user,
        account="",
        context=context,
    )
    return enriched, context


def _cached_gist(
    subject: str,
    group_label: str,
    cached_at: str,
    *,
    email_time: str,
    priority: int = 100,
) -> CachedGistt:
    action_group = ActionGroup(group=group_label, action=None, priority=priority)
    recommendation = ActionGroupRec(action_group=action_group, explanation="because")
    email = EmailMessage(
        id=f"{subject}-id",
        sender="sender@example.com",
        subject=subject,
        time=email_time,
        body="body",
        is_from_user=False,
        account="",
    )
    gist = Gistt(content=f"{subject} gist", email_message=email, recommendation=recommendation)
    return CachedGistt(gist=gist, cached_at=cached_at)


def _cached_gist_with_action(
    subject: str,
    group_label: str,
    *,
    action_name: str,
    thread_id: str,
    email_time: str,
    priority: int = 100,
) -> CachedGistt:
    action_group = ActionGroup(group=group_label, action=action_name, priority=priority)
    recommendation = ActionGroupRec(action_group=action_group, explanation="because")
    context = EmailContext(id=thread_id, messages=[])
    email = EmailMessage(
        id=f"{subject}-id",
        sender="sender@example.com",
        subject=subject,
        time=email_time,
        body="body",
        is_from_user=False,
        account="",
        context=context,
    )
    gist = Gistt(content=f"{subject} gist", email_message=email, recommendation=recommendation)
    return CachedGistt(gist=gist, cached_at="2024-01-01T00:00:00Z")


def test_handle_choice_fetches_gist() -> None:
    with TemporaryDirectory() as tmp:
        store_path = Path(tmp) / "session.json"
        session_store = SessionStateStore(path=store_path)
        settings = Settings()
        gmail_ops = DummyGmailOps([_sample_result()])
        cache_store = GisttCacheStore(path=Path(tmp) / "gistt_cache.json")
        genai_mock = MagicMock()
        gistt_producer = GisttProducer(genai_ops=genai_mock, cache_store=cache_store)
        default_group = gistt_producer.settings.action_groups[0]
        genai_mock.generate.return_value = json.dumps(
            {
                "action_group_canonical": default_group.canonical_name,
                "explanation": "Next steps needed.",
                "gistt": "Follow up on the launch plan.",
            }
        )
        controller = TableController(
            session_store=session_store,
            gmail_ops=gmail_ops,
            settings=settings,
            gistt_producer=gistt_producer,
        )

        payload = controller.handle_choice("g")

        assert gmail_ops.called is True
        assert payload["status"] == "ok"
        assert gmail_ops.last_limit == settings.preferences.default_fetch_size
        assert payload["count"] == 1
        assert payload["added"] == 1
        assert isinstance(payload["results"][0], CachedGistt)
        assert controller.last_email() is not None
        assert controller.last_context() is not None


def test_handle_choice_fetches_all_accounts() -> None:
    with TemporaryDirectory() as tmp:
        store_path = Path(tmp) / "session.json"
        session_store = SessionStateStore(path=store_path)
        session_store.update(active_account_email=None, multi_account_mode=True)
        settings = Settings()

        def _build_entry(account: str, message_id: str) -> tuple[EmailMessage, EmailContext]:
            email = EmailMessage(
                id=message_id,
                sender=f"{account}",
                subject=f"Subject {account}",
                time="2024-01-01T00:00:00Z",
                body="body",
                is_from_user=False,
                account=account,
            )
            context = EmailContext(id=f"{message_id}-thread", messages=[email])
            return replace(email, context=None), context

        responses: dict[str, list[tuple[EmailMessage, EmailContext]]] = {
            "one@example.com": [_build_entry("one@example.com", "msg-one")],
            "two@example.com": [_build_entry("two@example.com", "msg-two")],
        }

        class MultiAccountGmailOps:
            def __init__(self, payloads: dict[str, list[tuple[EmailMessage, EmailContext]]]) -> None:
                self._payloads = payloads
                self.call_log: list[tuple[str | None, Optional[int]]] = []

            def list_accounts(self) -> list[SimpleNamespace]:
                return [SimpleNamespace(email=email) for email in self._payloads]

            def fetch_messages_with_context(self, *, account_email: Optional[str] = None, limit: Optional[int] = None, **_: object) -> list[tuple[EmailMessage, EmailContext]]:
                self.call_log.append((account_email, limit))
                return self._payloads.get(account_email or "", [])

            def modify_thread_labels(
                self,
                *,
                account_email: Optional[str] = None,
                thread_id: str,
                add_labels: Optional[list[str]] = None,
                remove_labels: Optional[list[str]] = None,
            ) -> bool:
                return True

        gmail_ops = MultiAccountGmailOps(responses)
        cache_store = GisttCacheStore(path=Path(tmp) / "gistt_cache.json")
        genai_mock = MagicMock()
        gistt_producer = GisttProducer(genai_ops=genai_mock, cache_store=cache_store)
        default_group = gistt_producer.settings.action_groups[0]
        genai_mock.generate.return_value = json.dumps(
            {
                "action_group_canonical": default_group.canonical_name,
                "explanation": "Handle for all accounts.",
                "gistt": "All accounts gist.",
            }
        )

        controller = TableController(
            session_store=session_store,
            gmail_ops=gmail_ops,  # type: ignore[arg-type]
            settings=settings,
            gistt_producer=gistt_producer,
        )

        payload = controller.handle_choice("g")

        assert payload["status"] == "ok"
        assert payload["count"] == 2
        assert payload["added"] == 2
        assert {gist.gist.email_message.account for gist in payload["results"]} == {"one@example.com", "two@example.com"}
        for account_email, limit in gmail_ops.call_log:
            assert account_email in {"one@example.com", "two@example.com"}
            assert limit == settings.preferences.default_fetch_size


def test_handle_choice_handles_failure() -> None:
    with TemporaryDirectory() as tmp:
        session_store = SessionStateStore(path=Path(tmp) / "session.json")
        settings = Settings()
        gmail_ops = DummyGmailOps(None)
        cache_store = GisttCacheStore(path=Path(tmp) / "gistt_cache.json")
        genai_mock = MagicMock()
        gistt_producer = GisttProducer(genai_ops=genai_mock, cache_store=cache_store)
        default_group = gistt_producer.settings.action_groups[0]
        genai_mock.generate.return_value = json.dumps(
            {
                "action_group_canonical": default_group.canonical_name,
                "explanation": "Next steps needed.",
                "gistt": "Follow up on the launch plan.",
            }
        )
        controller = TableController(
            session_store=session_store,
            gmail_ops=gmail_ops,
            settings=settings,
            gistt_producer=gistt_producer,
        )

        payload = controller.handle_choice("g")

        assert payload["status"] == "error"
        assert "Unable to load email context" in payload["message"]


def test_handle_choice_increments_fetch_window() -> None:
    with TemporaryDirectory() as tmp:
        store_path = Path(tmp) / "session.json"
        session_store = SessionStateStore(path=store_path)
        settings = Settings()
        gmail_ops = DummyGmailOps([_sample_result()])
        cache_store = GisttCacheStore(path=Path(tmp) / "gistt_cache.json")
        genai_mock = MagicMock()
        gistt_producer = GisttProducer(genai_ops=genai_mock, cache_store=cache_store)
        default_group = gistt_producer.settings.action_groups[0]
        genai_mock.generate.return_value = json.dumps(
            {
                "action_group_canonical": default_group.canonical_name,
                "explanation": "Next steps needed.",
                "gistt": "Follow up on the launch plan.",
            }
        )
        controller = TableController(
            session_store=session_store,
            gmail_ops=gmail_ops,
            settings=settings,
            gistt_producer=gistt_producer,
        )

        first = controller.handle_choice("g")
        assert gmail_ops.last_limit == settings.preferences.default_fetch_size
        assert first["count"] == 1
        assert first["added"] == 1

        gmail_ops.called = False
        second = controller.handle_choice("g")
        assert gmail_ops.called is True
        assert gmail_ops.last_limit == settings.preferences.default_fetch_size * 2
        assert second["count"] == 1
        assert second["added"] == 0


def test_cached_results_loads_full_cache_and_fetch_limits_remote_calls() -> None:
    with TemporaryDirectory() as tmp:
        store_path = Path(tmp) / "session.json"
        session_store = SessionStateStore(path=store_path)
        settings = Settings()
        gmail_ops = DummyGmailOps([])
        entries = [
            _cached_gist(
                f"Subject {index}",
                "Action Needed",
                cached_at=f"2024-01-{index:02d}T00:00:00Z",
                email_time=f"2024-01-{index:02d}T00:00:00Z",
            )
            for index in range(1, 8)
        ]
        gistt_producer = StubGisttProducer(entries)
        controller = TableController(
            session_store=session_store,
            gmail_ops=gmail_ops,
            settings=settings,
            gistt_producer=gistt_producer,
        )

        cached = controller.cached_results()

        assert len(cached) == len(entries)

        payload = controller.fetch_gists()

        assert payload["status"] == "ok"
        assert gmail_ops.last_limit == settings.preferences.default_fetch_size
        assert payload["added"] == 0


def test_handle_choice_tab_executes_recommended_action() -> None:
    with TemporaryDirectory() as tmp:
        store_path = Path(tmp) / "session.json"
        session_store = SessionStateStore(path=store_path)
        settings = Settings()
        gmail_ops = DummyGmailOps([_sample_result()])
        cache_store = GisttCacheStore(path=Path(tmp) / "gistt_cache.json")
        genai_mock = MagicMock()
        gistt_producer = GisttProducer(genai_ops=genai_mock, cache_store=cache_store)
        default_group = gistt_producer.settings.action_groups[0]
        target_group = next(
            (
                group
                for group in gistt_producer.settings.action_groups
                if (
                    (group.action.name if hasattr(group.action, "name") else str(group.action or "")).lower()
                    == "read"
                )
            ),
            default_group,
        )
        genai_mock.generate.return_value = json.dumps(
            {
                "action_group_canonical": target_group.canonical_name,
                "explanation": "Mark as handled.",
                "gistt": "Follow up completed.",
            }
        )
        controller = TableController(
            session_store=session_store,
            gmail_ops=gmail_ops,
            settings=settings,
            gistt_producer=gistt_producer,
        )

        fetch_payload = controller.handle_choice("g")
        assert fetch_payload["status"] == "ok"
        assert controller.current_selection() == 0

        response = controller.handle_choice("\t")

        assert response["status"] == "ok"
        assert response["action"] == "read"
        assert gmail_ops.modified_calls, "Expected modify_thread_labels to be invoked."
        call = gmail_ops.modified_calls[0]
        assert call["thread_id"] == "thread-1"
        assert call["remove_labels"] == ["UNREAD"]
        assert call["add_labels"] == ["gistt"]
        assert controller.last_results()[0].state == GisttState.REVIEWED
        last_email = controller.last_email()
        assert last_email is not None
        cached_entry = cache_store.get(None, last_email.id)
        assert cached_entry is not None
        assert cached_entry.gist.state == GisttState.REVIEWED
        refreshed = controller.cached_results()
        assert refreshed[0].gist.state == GisttState.REVIEWED


def test_handle_choice_tab_executes_archive_action() -> None:
    with TemporaryDirectory() as tmp:
        store_path = Path(tmp) / "session.json"
        session_store = SessionStateStore(path=store_path)
        settings = Settings()
        gmail_ops = DummyGmailOps([_sample_result()])
        cache_store = GisttCacheStore(path=Path(tmp) / "gistt_cache.json")
        genai_mock = MagicMock()
        gistt_producer = GisttProducer(genai_ops=genai_mock, cache_store=cache_store)
        archive_group = next(
            (
                group
                for group in gistt_producer.settings.action_groups
                if (
                    (group.action.name if hasattr(group.action, "name") else str(group.action or "")).lower()
                    == "archive"
                )
            ),
            gistt_producer.settings.action_groups[0],
        )
        genai_mock.generate.return_value = json.dumps(
            {
                "action_group_canonical": archive_group.canonical_name,
                "explanation": "Archive the thread.",
                "gistt": "No further action needed.",
            }
        )
        controller = TableController(
            session_store=session_store,
            gmail_ops=gmail_ops,
            settings=settings,
            gistt_producer=gistt_producer,
        )

        fetch_payload = controller.handle_choice("g")
        assert fetch_payload["status"] == "ok"
        assert controller.current_selection() == 0

        response = controller.handle_choice("\t")

        assert response["status"] == "ok"
        assert response["action"] == "archive"
        assert gmail_ops.modified_calls, "Expected modify_thread_labels to be invoked."
        call = gmail_ops.modified_calls[0]
        assert call["thread_id"] == "thread-1"
        assert set(call["remove_labels"]) == {"INBOX", "UNREAD"}
        assert call["add_labels"] == ["gistt"]
        assert controller.last_results()[0].state == GisttState.ARCHIVED
        last_email = controller.last_email()
        assert last_email is not None
        cached_entry = cache_store.get(None, last_email.id)
        assert cached_entry is not None
        assert cached_entry.gist.state == GisttState.ARCHIVED
        refreshed = controller.cached_results()
        assert refreshed[0].gist.state == GisttState.ARCHIVED


def test_handle_choice_shortcuts_execute_actions() -> None:
    with TemporaryDirectory() as tmp:
        session_store = SessionStateStore(path=Path(tmp) / "session.json")
        settings = Settings()
        gmail_ops = DummyGmailOps([])
        entries = [
            _cached_gist_with_action(
                "First",
                "Action Needed",
                action_name="read",
                thread_id="thread-1",
                email_time="2024-02-10T09:00:00Z",
            ),
            _cached_gist_with_action(
                "Second",
                "Action Needed",
                action_name="archive",
                thread_id="thread-2",
                email_time="2024-02-09T09:00:00Z",
            ),
        ]
        gistt_producer = StubGisttProducer(entries)
        controller = TableController(
            session_store=session_store,
            gmail_ops=gmail_ops,
            settings=settings,
            gistt_producer=gistt_producer,
        )

        controller.cached_results()
        assert controller.resolve_action_shortcut("S") == "read"
        assert controller.resolve_action_shortcut("[") == "archive"
        assert controller.current_selection() == 0

        read_response = controller.handle_choice("s")

        assert read_response["status"] == "ok"
        assert read_response["action"] == "read"
        assert gmail_ops.modified_calls, "Expected modify_thread_labels to record read action."
        first_call = gmail_ops.modified_calls[0]
        assert first_call["thread_id"] == "thread-1"
        assert first_call["remove_labels"] == ["UNREAD"]
        assert first_call["add_labels"] == ["gistt"]
        assert controller.last_results()[0].state == GisttState.REVIEWED
        assert controller.current_selection() == 1

        archive_response = controller.handle_choice("[")

        assert archive_response["status"] == "ok"
        assert archive_response["action"] == "archive"
        assert len(gmail_ops.modified_calls) == 2
        second_call = gmail_ops.modified_calls[1]
        assert second_call["thread_id"] == "thread-2"
        assert set(second_call["remove_labels"]) == {"INBOX", "UNREAD"}
        assert second_call["add_labels"] == ["gistt"]
        assert controller.last_results()[1].state == GisttState.ARCHIVED
        assert controller.current_selection() == 1
        assert gistt_producer.cache_store.upsert_calls, "Expected cache store to persist shortcut actions."


def test_cached_results_orders_entries_by_priority_then_recency() -> None:
    with TemporaryDirectory() as tmp:
        session_store = SessionStateStore(path=Path(tmp) / "session.json")
        settings = Settings()
        gmail_ops = DummyGmailOps([])
        entries = [
            _cached_gist(
                "Archive newer",
                "Archive",
                "2024-01-03T00:00:00Z",
                email_time="2024-02-01T09:00:00Z",
                priority=50,
            ),
            _cached_gist(
                "Archive older",
                "Archive",
                "2024-01-01T00:00:00Z",
                email_time="2024-01-15T09:00:00Z",
                priority=50,
            ),
            _cached_gist(
                "Waiting subject",
                "Waiting on Reply",
                "2024-01-02T00:00:00Z",
                email_time="2024-01-20T09:00:00Z",
                priority=20,
            ),
            _cached_gist(
                "Action subject",
                "Action Needed",
                "2024-01-04T00:00:00Z",
                email_time="2024-02-10T09:00:00Z",
                priority=10,
            ),
        ]
        gistt_producer = StubGisttProducer(entries)
        controller = TableController(
            session_store=session_store,
            gmail_ops=gmail_ops,
            settings=settings,
            gistt_producer=gistt_producer,
        )

        ordered = controller.cached_results()

        labels = [
            entry.gist.recommendation.action_group.group if entry.gist.recommendation else None
            for entry in ordered
        ]
        assert labels == ["Action Needed", "Waiting on Reply", "Archive", "Archive"]

        subjects = [entry.gist.email_message.subject for entry in ordered]
        assert subjects == [
            "Action subject",
            "Waiting subject",
            "Archive newer",
            "Archive older",
        ]
        assert controller.current_selection() == 0


def test_execute_action_advances_selection_and_updates_state() -> None:
    with TemporaryDirectory() as tmp:
        session_store = SessionStateStore(path=Path(tmp) / "session.json")
        settings = Settings()
        gmail_ops = DummyGmailOps([])
        entries = [
            _cached_gist_with_action(
                "First",
                "Action Needed",
                action_name="archive",
                thread_id="thread-1",
                email_time="2024-02-10T09:00:00Z",
            ),
            _cached_gist_with_action(
                "Second",
                "Action Needed",
                action_name="archive",
                thread_id="thread-2",
                email_time="2024-02-09T09:00:00Z",
            ),
        ]
        gistt_producer = StubGisttProducer(entries)
        controller = TableController(
            session_store=session_store,
            gmail_ops=gmail_ops,
            settings=settings,
            gistt_producer=gistt_producer,
        )

        controller.cached_results()
        assert controller.current_selection() == 0

        response = controller.handle_choice("\t")

        assert response["status"] == "ok"
        assert controller.current_selection() == 1
        assert controller.last_results()[0].state == GisttState.ARCHIVED
        assert gistt_producer.cache_store.upsert_calls, "Expected cache store upsert to record state update."


def test_clear_action_resets_state_and_removes_label() -> None:
    with TemporaryDirectory() as tmp:
        session_store = SessionStateStore(path=Path(tmp) / "session.json")
        settings = Settings()
        gmail_ops = DummyGmailOps([])
        entries = [
            _cached_gist_with_action(
                "First",
                "Action Needed",
                action_name="clear",
                thread_id="thread-1",
                email_time="2024-02-10T09:00:00Z",
            ),
            _cached_gist_with_action(
                "Second",
                "Action Needed",
                action_name="archive",
                thread_id="thread-2",
                email_time="2024-02-09T09:00:00Z",
            ),
        ]
        entries[0] = replace(entries[0], gist=replace(entries[0].gist, state=GisttState.SAVED))
        gistt_producer = StubGisttProducer(entries)
        controller = TableController(
            session_store=session_store,
            gmail_ops=gmail_ops,
            settings=settings,
            gistt_producer=gistt_producer,
        )

        controller.cached_results()
        assert controller.current_selection() == 0

        response = controller.handle_choice("\t")

        assert response["status"] == "ok"
        assert controller.current_selection() == 1
        assert controller.last_results()[0].state is None
        assert gistt_producer.cache_store.upsert_calls, "Expected cache store upsert for clear action."
        assert gmail_ops.modified_calls, "Expected Gmail label removal call."
        modify_call = gmail_ops.modified_calls[-1]
        assert modify_call["thread_id"] == "thread-1"
        assert modify_call["add_labels"] == ["INBOX", "UNREAD"]
        assert modify_call["remove_labels"] == ["gistt"]
