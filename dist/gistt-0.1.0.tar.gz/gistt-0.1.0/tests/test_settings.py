import unittest

from gistt.settings import Settings
from gistt.models import Action


class TestSettings(unittest.TestCase):
    def test_settings_load(self) -> None:
        settings = Settings()
        self.assertEqual(len(settings.action_groups), 5)
        self.assertEqual(settings.preferences.default_fetch_size, 10)
        self.assertEqual(settings.preferences.recency_cutoff_days, 10)
        self.assertEqual(settings.preferences.summary_workers, 3)
        
    def test_action_validation(self) -> None:
        self.assertRaises(ValueError, Action, name="invalid")

if __name__ == "__main__":
    unittest.main()
