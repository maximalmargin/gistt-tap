from __future__ import annotations

from dataclasses import replace

from rich.console import Console

from gistt.controller.session_state import SessionState
from gistt.controller.thread_controller import ThreadController
from gistt.models import EmailContext, EmailMessage, Gistt, GisttState
from gistt.services.gistt_cache_store import CachedGistt
from gistt.ui.thread_view import ThreadView


class DummyLiveContext:
    def __init__(self) -> None:
        self.update_calls = 0

    def __enter__(self) -> "DummyLiveContext":
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        return False

    def update(self, renderable, refresh: bool = False) -> None:  # noqa: ANN001 - signature mirrors rich.Live
        self.update_calls += 1


def _cached_gist(*, with_context: bool = True, extra_messages: bool = False) -> CachedGistt:
    base_email = EmailMessage(
        id="primary-id",
        sender="sender@example.com",
        subject="Subject line",
        time="2024-02-11T09:30:00Z",
        body="Primary body content.",
        is_from_user=False,
        account="account@example.com",
        context=None,
    )
    messages: list[EmailMessage] = [base_email]
    if with_context and extra_messages:
        messages.append(
            EmailMessage(
                id="secondary-id",
                sender="colleague@example.com",
                subject="Re: Subject line",
                time="2024-02-11T08:00:00Z",
                body="Secondary body content.",
                is_from_user=False,
                account="account@example.com",
                context=None,
            )
        )
    context = EmailContext(id="thread-1", messages=messages) if with_context else None
    primary = replace(base_email, context=context)
    gist = Gistt(content="Summarised gist content.", email_message=primary)
    return CachedGistt(gist=gist, cached_at="2024-02-11T10:00:00Z")


def _read_key_once(value: str):
    calls = {"remaining": 1}

    def _reader(*, timeout=None):
        if calls["remaining"] > 0:
            calls["remaining"] -= 1
            return value
        raise AssertionError("read_key called more times than expected")

    return _reader


def test_thread_view_returns_back_on_b_key() -> None:
    entry = _cached_gist()
    controller = ThreadController()
    view = ThreadView(
        console=Console(record=True),
        controller=controller,
        read_key_fn=_read_key_once("b"),
    )
    live = lambda **kwargs: DummyLiveContext()  # noqa: E731 - simple inline stub

    result = view.render(entry, live_factory=live)

    assert result == "back"


def test_thread_controller_prefers_thread_id_link() -> None:
    context = EmailContext(id="thread-42", messages=[])
    email = EmailMessage(
        id="message-123",
        sender="sender@example.com",
        subject="Subject",
        time="2024-02-11T12:00:00Z",
        body="Body",
        is_from_user=False,
        account="account@example.com",
        context=context,
    )
    controller = ThreadController()

    link = controller.gmail_link(email)

    assert link.endswith("#inbox/thread-42")


def test_thread_controller_includes_authuser_account() -> None:
    context = EmailContext(id="thread-42", messages=[])
    email = EmailMessage(
        id="message-123",
        sender="sender@example.com",
        subject="Subject",
        time="2024-02-11T12:00:00Z",
        body="Body",
        is_from_user=False,
        account="account@example.com",
        context=context,
    )
    controller = ThreadController()

    link = controller.gmail_link(email)

    assert "?authuser=account%40example.com" in link


class _StubSessionStore:
    def __init__(self, state: SessionState) -> None:
        self._state = state

    def load(self) -> SessionState:
        return self._state

    def save(self, state: SessionState) -> SessionState:
        self._state = state
        return state


def test_thread_controller_falls_back_to_session_account_when_missing() -> None:
    context = EmailContext(id="thread-42", messages=[])
    email = EmailMessage(
        id="message-123",
        sender="sender@example.com",
        subject="Subject",
        time="2024-02-11T12:00:00Z",
        body="Body",
        is_from_user=False,
        account="",
        context=context,
    )
    session_state = SessionState(active_account_email="active@example.com", multi_account_mode=False)
    controller = ThreadController(session_store=_StubSessionStore(session_state))

    link = controller.gmail_link(email)

    assert "?authuser=active%40example.com" in link


def test_thread_view_header_includes_gmail_link_even_with_state() -> None:
    entry = _cached_gist()
    entry_with_state = replace(entry, gist=replace(entry.gist, state=GisttState.SAVED))
    controller = ThreadController()
    view = ThreadView(
        console=Console(record=True),
        controller=controller,
        read_key_fn=_read_key_once("b"),
    )
    view._active_entry = entry_with_state  # type: ignore[assignment]

    header_panel = view._build_header()
    rendered = header_panel.renderable.plain

    assert "Open in Gmail:" in rendered
    assert controller.gmail_link(entry_with_state.gist.email_message) in rendered


def test_thread_view_header_height_expands_for_state() -> None:
    entry = _cached_gist()
    entry_with_state = replace(entry, gist=replace(entry.gist, state=GisttState.SAVED))
    controller = ThreadController()
    view = ThreadView(
        console=Console(record=True),
        controller=controller,
        read_key_fn=_read_key_once("b"),
    )
    view._active_entry = entry_with_state  # type: ignore[assignment]

    layout = view._build_layout()

    assert layout["header"].size >= 8


def test_context_panel_indicates_no_additional_messages() -> None:
    entry = _cached_gist(with_context=True, extra_messages=False)
    controller = ThreadController()
    view = ThreadView(
        console=Console(record=True),
        controller=controller,
        read_key_fn=_read_key_once("b"),
    )
    view._active_entry = entry  # type: ignore[assignment]

    panel = view._context_panel(entry.gist.email_message.context)  # type: ignore[arg-type]

    assert "No additional messages" in panel.renderable.plain
