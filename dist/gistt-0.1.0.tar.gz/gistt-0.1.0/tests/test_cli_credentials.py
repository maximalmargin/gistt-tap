import io
import os
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

from rich.console import Console

from gistt.ui.cli import CLIENT_SECRETS_ENV, DEFAULT_CLIENT_SECRETS, WelcomeAccountManager


class TestWelcomeAccountManagerCredentialsPath(unittest.TestCase):
    def setUp(self) -> None:
        self.console = Console(file=io.StringIO(), record=True)
        self.delegate = Mock()

    def test_prefers_primary_env_override(self) -> None:
        fake_path = "/tmp/primary-creds.json"
        with patch.dict(os.environ, {CLIENT_SECRETS_ENV: fake_path}, clear=True):
            manager = WelcomeAccountManager(console=self.console, delegate=self.delegate)
            self.assertEqual(manager._credentials_path(), Path(fake_path))

    def test_defaults_to_config_path_when_none_found(self) -> None:
        with patch.dict(os.environ, {}, clear=True):
            manager = WelcomeAccountManager(console=self.console, delegate=self.delegate)
            self.assertEqual(manager._credentials_path(), DEFAULT_CLIENT_SECRETS)


if __name__ == "__main__":
    unittest.main()
