import io
import unittest
from dataclasses import dataclass
from unittest.mock import patch
from typing import Optional

from rich.console import Console
from rich.theme import Theme

from gistt.controller.session_state import SessionState
from gistt.ui.welcome_view import WelcomeView


class SingleFrameLive:
    """Live stub used in tests to capture a single rendered frame."""

    def __init__(self, renderable, *, console, **_kwargs):
        self._console = console
        self._renderable = renderable

    def __enter__(self):
        self._console.print(self._renderable)
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def update(self, renderable):
        self._renderable = renderable
        self._console.print(renderable)

    def stop(self):
        pass

    def start(self, refresh=True):
        pass


@dataclass
class StubAccount:
    email: str


class StubAccountManager:
    def __init__(self, emails, *, link_result=None):
        self._accounts = [StubAccount(email) for email in emails]
        self._link_result = link_result
        self.link_calls = 0

    def list_accounts(self):
        return self._accounts

    def link_account(self):
        self.link_calls += 1
        return self._link_result

    def add_account(self, email):
        account = StubAccount(email)
        self._accounts.append(account)
        return account


class StubSessionStore:
    def __init__(self):
        self.saved: list[SessionState] = []

    def load(self) -> SessionState:
        return SessionState()

    def update(
        self,
        *,
        active_account_email: Optional[str],
        multi_account_mode: bool,
    ) -> SessionState:
        state = SessionState(
            active_account_email=active_account_email,
            multi_account_mode=multi_account_mode,
        )
        self.saved.append(state)
        return state


class TestWelcomeViewPrompt(unittest.TestCase):
    def setUp(self):
        self.console = Console(file=io.StringIO(), record=True)
        self.accounts = ["alice@example.com", "bob@example.com"]
        self.account_manager = StubAccountManager(self.accounts)
        self.session_store = StubSessionStore()
        self.view = WelcomeView(
            console=self.console,
            account_manager=self.account_manager,
            session_store=self.session_store,
        )

    @patch("gistt.ui.welcome_view.read_key", side_effect=["a"])
    def test_select_all_accounts_mode(self, _mock_read_key):
        current = StubAccount("alice@example.com")
        selected, multi_mode, should_continue = self.view.render(
            current_account=current,
            multi_account_mode=False,
            live_factory=SingleFrameLive,
        )
        self.assertIs(selected, current)
        self.assertTrue(multi_mode)
        self.assertTrue(should_continue)
        self.assertEqual(len(self.session_store.saved), 1)
        self.assertIsNone(self.session_store.saved[0].active_account_email)
        self.assertTrue(self.session_store.saved[0].multi_account_mode)

    @patch("gistt.ui.welcome_view.read_key", side_effect=["2"])
    def test_select_account_by_index(self, _mock_read_key):
        current = StubAccount("alice@example.com")
        selected, multi_mode, should_continue = self.view.render(
            current_account=current,
            multi_account_mode=False,
            live_factory=SingleFrameLive,
        )
        self.assertEqual(selected.email, "bob@example.com")
        self.assertFalse(multi_mode)
        self.assertTrue(should_continue)
        self.assertEqual(len(self.session_store.saved), 1)
        self.assertEqual(self.session_store.saved[0].active_account_email, "bob@example.com")
        self.assertFalse(self.session_store.saved[0].multi_account_mode)

    @patch("gistt.ui.welcome_view.read_key", side_effect=["j", "enter"])
    def test_navigation_selects_next_account(self, _mock_read_key):
        current = StubAccount("alice@example.com")
        selected, multi_mode, should_continue = self.view.render(
            current_account=current,
            multi_account_mode=False,
            live_factory=SingleFrameLive,
        )
        self.assertEqual(selected.email, "bob@example.com")
        self.assertFalse(multi_mode)
        self.assertTrue(should_continue)
        self.assertEqual(len(self.session_store.saved), 1)
        self.assertEqual(self.session_store.saved[0].active_account_email, "bob@example.com")
        self.assertFalse(self.session_store.saved[0].multi_account_mode)

    @patch("gistt.ui.welcome_view.read_key", side_effect=["ctrl+p", "enter"])
    def test_navigation_selects_all_accounts(self, _mock_read_key):
        current = StubAccount("alice@example.com")
        selected, multi_mode, should_continue = self.view.render(
            current_account=current,
            multi_account_mode=False,
            live_factory=SingleFrameLive,
        )
        self.assertIs(selected, current)
        self.assertTrue(multi_mode)
        self.assertTrue(should_continue)
        self.assertEqual(len(self.session_store.saved), 1)
        self.assertIsNone(self.session_store.saved[0].active_account_email)
        self.assertTrue(self.session_store.saved[0].multi_account_mode)

    @patch("gistt.ui.welcome_view.read_key", side_effect=["q"])
    def test_quit(self, _mock_read_key):
        current = StubAccount("alice@example.com")
        selected, _, should_continue = self.view.render(
            current_account=current,
            multi_account_mode=False,
            live_factory=SingleFrameLive,
        )
        self.assertIsNone(selected)
        self.assertFalse(should_continue)
        self.assertEqual(self.session_store.saved, [])

class TestWelcomeViewNoAccounts(unittest.TestCase):
    def setUp(self):
        self.console = Console(file=io.StringIO(), record=True)
        self.account_manager = StubAccountManager([])
        self.session_store = StubSessionStore()
        self.view = WelcomeView(
            console=self.console,
            account_manager=self.account_manager,
            session_store=self.session_store,
        )

    @patch("gistt.ui.welcome_view.read_key", side_effect=[""])
    def test_no_accounts(self, _mock_read_key):
        selected, multi_mode, should_continue = self.view.render(
            current_account=None,
            multi_account_mode=False,
            live_factory=SingleFrameLive,
        )
        self.assertIsNone(selected)
        self.assertFalse(multi_mode)
        self.assertTrue(should_continue)
        text_output = self.console.export_text(styles=True)
        print("\n--- ANSI Snapshot ---\n")
        print(text_output)
        print("\n--- End ---")
        self.assertIn("Linked Gmail Accounts", text_output)
        self.assertEqual(self.session_store.saved, [])

    @patch("gistt.ui.welcome_view.read_key", side_effect=["l", "q"])
    def test_link_account_failure_shows_error_and_stays_in_view(self, _mock_read_key):
        selected, multi_mode, should_continue = self.view.render(
            current_account=None,
            multi_account_mode=False,
            live_factory=SingleFrameLive,
        )
        self.assertIsNone(selected)
        self.assertFalse(multi_mode)
        self.assertFalse(should_continue)
        self.assertEqual(self.account_manager.link_calls, 1)
        text_output = self.console.export_text(styles=True)
        self.assertIn("Account linking failed", text_output)
        self.assertNotIn("All accounts", text_output)
        self.assertEqual(self.session_store.saved, [])

    @patch("gistt.ui.welcome_view.read_key", side_effect=[""])
    def test_no_accounts_multi_account_mode(self, _mock_read_key):
        selected, multi_mode, should_continue = self.view.render(
            current_account=None,
            multi_account_mode=True,
            live_factory=SingleFrameLive,
        )
        self.assertIsNone(selected)
        self.assertTrue(multi_mode)
        self.assertTrue(should_continue)
        text_output = self.console.export_text(styles=True)
        print("\n--- ANSI Snapshot ---\n")
        print(text_output)
        print("\n--- End ---")
        self.assertIn("Linked Gmail Accounts", text_output)
        self.assertEqual(self.session_store.saved, [])

if __name__ == "__main__":
    unittest.main()
