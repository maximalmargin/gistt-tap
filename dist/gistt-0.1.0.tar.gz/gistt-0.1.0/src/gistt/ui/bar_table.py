"""Helpers for rendering the pagination meter in the table view."""
from __future__ import annotations

from dataclasses import dataclass

from rich.text import Text


@dataclass
class WindowMeter:
    """Neon styled meter showing the visible slice within the full result set."""

    width: int = 24

    def render(self, *, start: int, end: int, total: int, selection: int | None = None) -> Text:
        """Return a Rich Text bar marking the active window."""
        if total <= 0 or end <= start:
            return Text("")

        span = max(1, total)
        per_unit = self.width / span
        highlight_start = int(per_unit * start)
        highlight_end = int(per_unit * end)
        highlight_end = max(highlight_start + 1, highlight_end)
        highlight_start = max(0, min(self.width - 1, highlight_start))
        highlight_end = max(1, min(self.width, highlight_end))

        filled_segment = "[bold #39ff14]█[/]"
        empty_segment = "[dim #4f6ed1]░[/]"
        interior = "".join(
            filled_segment if highlight_start <= idx < highlight_end else empty_segment
            for idx in range(self.width)
        )
        bar_markup = "[bold #ff6ec7]■[/]" + interior + "[bold #ff6ec7]■[/]"
        if selection is None:
            selection = start
        current = max(0, min(selection, total - 1)) + 1
        digits = max(2, len(str(total)))
        count_markup = (
            f"[bold #ff6ec7]{current:0{digits}d}[/]"
            f"[dim #f9f871]/[/]"
            f"[bold #ff6ec7]{total:0{digits}d}[/]"
        )
        return Text.from_markup(f"{bar_markup}  {count_markup}")
