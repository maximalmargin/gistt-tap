"""Retro-styled progress helpers for the UI."""
from __future__ import annotations

from rich.progress import ProgressColumn, Task
from rich.text import Text


class RetroBarColumn(ProgressColumn):
    """Neon 80s bar using block characters (█ ▒ ░ ■)."""

    def __init__(self, width: int = 24) -> None:
        super().__init__()
        self._width = width

    def render(self, task: Task) -> Text:
        total = task.total or 0
        completed = min(max(task.completed or 0, 0), total) if total else (task.completed or 0)

        if total <= 0:
            interior = "[dim #0c1445]" + ("░" * self._width) + "[/]"
            return Text.from_markup(f"[bold #ff6ec7]■[/]{interior}[bold #ff6ec7]■[/]")

        ratio = 0 if total == 0 else completed / max(total, 1)
        filled_units = max(0, min(self._width, int(ratio * self._width)))
        remaining_units = self._width - filled_units

        segments = ["[bold #ff6ec7]■[/]"]
        if filled_units:
            segments.append(f"[bold #39ff14]{'█' * filled_units}[/]")

        has_partial = 0 < ratio < 1 and remaining_units > 0
        if has_partial:
            segments.append("[bold #f9f871]▒[/]")
            remaining_units -= 1

        if remaining_units > 0:
            segments.append(f"[dim #0c1445]{'░' * remaining_units}[/]")

        segments.append("[bold #ff6ec7]■[/]")
        return Text.from_markup("".join(segments))


class RetroCountColumn(ProgressColumn):
    """Retro-styled completed/total counter."""

    def render(self, task: Task) -> Text:
        total = task.total
        completed = task.completed or 0
        if total and total > 0:
            markup = (
                f"[bold #7df9ff]{int(completed):02d}[/]"
                "[dim #f9f871]/[/]"
                f"[bold #fef08a]{int(total):02d}[/]"
            )
        else:
            markup = f"[bold #7df9ff]{int(completed):02d}[/][dim #f9f871]/[/][bold #fef08a]??[/]"
        return Text.from_markup(markup)
