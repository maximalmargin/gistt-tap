"""Rich-based view for inspecting a single gistt thread."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Optional, Sequence

from rich import box
from rich.console import Console, Group
from rich.live import Live
from rich.panel import Panel
from rich.text import Text

from gistt.controller.thread_controller import ThreadController
from gistt.services.gistt_cache_store import CachedGistt
from gistt.models import EmailContext, EmailMessage
from gistt.ui.base import View
from gistt.ui.layout import build_layout, read_key


@dataclass(init=False)
class ThreadView(View):
    """Interactive view that shows the gistt, latest message, and thread context."""

    controller: ThreadController = field(repr=False)
    footer_message: str = field(
        default="b: back • q: quit",
    )
    _read_key: Callable[..., Optional[str]] = field(
        default=read_key, repr=False)
    _active_entry: Optional[CachedGistt] = field(
        default=None, init=False, repr=False)

    def __init__(
        self,
        *,
        console: Console,
        controller: ThreadController,
        read_key_fn: Callable[..., Optional[str]] = read_key,
    ) -> None:
        super().__init__(console=console, controller=controller)
        self._read_key = read_key_fn
        self.footer_message = "b: back • q: quit"
        self._active_entry = None

    def render(
        self,
        entry: CachedGistt,
        *,
        live_factory: Callable[..., Live] = Live,
    ) -> str:
        """Render the thread view until the user exits."""
        self._active_entry = entry
        self.status_message = ""

        with live_factory(
            console=self.console,
            refresh_per_second=8,
            transient=False,
            auto_refresh=False,
        ) as live:
            live.update(self._build_layout(), refresh=True)
            while True:
                key = self._read_key(timeout=0.1)
                if key is None:
                    continue

                normalized = key.lower()
                if normalized in {"b", "escape", "backspace"}:
                    self.status_message = ""
                    return "back"

                if normalized in {"q", "ctrl+c", "ctrl+d"}:
                    return "quit"

                if normalized == "enter":
                    return "back"

                self.status_message = f"pressed {key!s}"
                live.update(self._build_layout(), refresh=True)

    # ------------------------------------------------------------------
    # Layout builders
    # ------------------------------------------------------------------
    def _build_layout(self):
        header = self._build_header()
        header_lines = 0
        renderable = getattr(header, "renderable", None)
        if isinstance(renderable, Text):
            # +1 converts newline count to total line count
            header_lines = renderable.plain.count("\n") + 1
        header_size = max(7, header_lines + 2)  # account for panel borders
        body = self._build_body()
        footer = self._build_footer()
        return build_layout(
            header_renderable=header,
            body_renderable=body,
            footer_renderable=footer,
            spacer_size=0,
            header_size=header_size,
            body_ratio=1,
            footer_size=4,
        )

    def _build_header(self) -> Panel:
        if not self._active_entry:
            return Panel(Text("no gistt selected.", style="yellow"), box=box.SIMPLE)

        gist = self._active_entry.gist
        email = gist.email_message
        header = Text()
        subject = email.subject or "(no subject)"
        header.append("subject: ", style="#7df9ff")
        header.append(subject.strip() or "(no subject)", style="white")
        header.append("\nfrom: ", style="#7df9ff")
        sender = email.sender or "(unknown sender)"
        sender_style = "#39ff14" if email.is_from_user else "white"
        header.append(sender.strip() or "(unknown sender)", style=sender_style)
        if email.is_from_user:
            header.append(" (you)", style="#39ff14")
        if email.account:
            header.append("\naccount: ", style="#7df9ff")
            header.append(email.account, style="white")
        if email.time:
            header.append("\nreceived: ", style="#7df9ff")
            header.append(email.time, style="white")
        gist_state = getattr(gist.state, "value", None)
        if gist_state:
            header.append("\nstate: ", style="#7df9ff")
            header.append(str(gist_state), style="white")
        gmail_link = self.controller.gmail_link(email).strip()
        header.append("\nOpen in Gmail: ", style="#7df9ff")
        if gmail_link:
            header.append(gmail_link, style="#7df9ff underline")
        else:
            header.append("(unavailable)", style="dim")
        return Panel(header, border_style="#7df9ff", box=box.SIMPLE)

    def _build_body(self):
        if not self._active_entry:
            return Panel(Text("no gistt to display.", style="yellow"), box=box.SIMPLE)

        gist_panel = self._gist_panel()
        current_message_panel = self._message_panel(
            self._active_entry.gist.email_message,
            title="original message",
            highlight=False,
        )
        context_panel = self._context_panel(
            self._active_entry.gist.email_message.context)

        panels: Sequence = (gist_panel, current_message_panel)
        if context_panel is not None:
            panels = (*panels, context_panel)

        return Panel(
            Group(*panels),
            border_style="dim",
            box=box.SIMPLE,
        )

    def _build_footer(self) -> Panel:
        return Panel(
            Group(
                Text(self.footer_message, style="cyan"),
                Text(self.status_message, style="dim"),
            ),
            padding=(0, 1),
            box=box.SIMPLE,
        )

    # ------------------------------------------------------------------
    # Render helpers
    # ------------------------------------------------------------------
    def _gist_panel(self) -> Panel:
        gist = self._active_entry.gist if self._active_entry else None
        content = (gist.content or "").strip() if gist else ""
        text = Text(content or "(no gistt available.)", style="bold white")
        return Panel(text, title="gistt", border_style="cyan", padding=(1, 1), box=box.ASCII2)

    def _context_panel(self, context: Optional[EmailContext]) -> Optional[Panel]:
        if context is None or not context.messages:
            return Panel(
                Text("No additional messages in thread.", style="dim"),
                title="thread messages",
                border_style="#7df9ff",
                box=box.SIMPLE,
            )

        active_id = self._active_entry.gist.email_message.id if self._active_entry else None
        other_messages = [
            message for message in context.messages if message.id != active_id]
        if not other_messages:
            return Panel(
                Text("No additional messages in thread.", style="dim"),
                title="thread messages",
                border_style="#7df9ff",
                box=box.SIMPLE,
            )

        message_blocks = [
            self._message_panel(
                message, title=f"message {index}", highlight=False)
            for index, message in enumerate(other_messages, start=1)
        ]

        return Panel(
            Group(*message_blocks),
            title="thread messages",
            border_style="#7df9ff",
            box=box.SIMPLE,
        )

    def _message_panel(self, message: EmailMessage, *, title: str, highlight: bool = False) -> Panel:
        body = Text()
        body.append("from: ", style="#7df9ff")
        sender = message.sender or "(unknown sender)"
        sender_style = "#39ff14" if message.is_from_user else "white"
        body.append(sender, style=sender_style)
        body.append("\nsubject: ", style="#7df9ff")
        body.append(message.subject or "(no subject)", style="white")
        if message.time:
            body.append("\nsent: ", style="#7df9ff")
            body.append(message.time, style="white")
        body.append("\n\n")
        body.append((message.body or "").strip() or "(no body provided.)",
                    style="bold white" if highlight else "white")

        border_style = "#39ff14" if highlight else "#7df9ff"
        panel_title = f"{title}" if highlight else title
        return Panel(body, title=panel_title, border_style=border_style, box=box.SIMPLE)
