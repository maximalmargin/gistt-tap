"""Disk-backed cache for generated gistts."""
from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple
import json
import threading

from gistt.models import ActionGroup, ActionGroupRec, EmailContext, EmailMessage, Gistt, GisttState


CACHE_DIR = Path.home() / ".local" / "share" / "gistt"
CACHE_FILE = CACHE_DIR / "gistt_cache.json"
CACHE_VERSION = 1
_DEFAULT_ACCOUNT_KEY = "__default__"


@dataclass(frozen=True)
class CachedGistt:
    """Cached gistt alongside metadata about when it was stored."""

    gist: Gistt
    cached_at: str


class GisttCacheStore:
    """Persist and retrieve gistts keyed by account + message id."""

    def __init__(self, path: Path = CACHE_FILE) -> None:
        self._path = path
        self._lock = threading.RLock()
        self._entries: Dict[str, Dict[str, Any]] = {}
        self._load()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def get(self, account: Optional[str], message_id: str) -> Optional[CachedGistt]:
        """Return the cached gistt for the given message, if present."""
        key = self._key(account, message_id)
        with self._lock:
            payload = self._entries.get(key)
        if not payload:
            return None
        return self._deserialize_entry(payload)

    def upsert(self, email_message: EmailMessage, gist: Gistt) -> CachedGistt:
        """Persist the gistt alongside the provided email metadata."""
        normalized_gist = gist if gist.email_message == email_message else replace(gist, email_message=email_message)
        entry = self._serialize_entry(email_message, normalized_gist)
        key = self._key(email_message.account, email_message.id)
        with self._lock:
            self._entries[key] = entry
            self._save()
        return self._deserialize_entry(entry)

    def list_for_account(
        self,
        account: Optional[str],
        *,
        limit: Optional[int] = None,
    ) -> List[CachedGistt]:
        """Return cached gistts for the given account, sorted by recency."""
        normalized_account = self._normalize_account(account)
        with self._lock:
            entries = [
                self._deserialize_entry(payload)
                for payload in self._entries.values()
                if payload.get("account_key") == normalized_account
            ]
        entries.sort(key=lambda item: item.cached_at, reverse=True)
        if limit is not None and limit >= 0:
            entries = entries[:limit]
        return entries

    def list_for_accounts(
        self,
        accounts: Optional[Sequence[Optional[str]]] = None,
        *,
        limit: Optional[int] = None,
    ) -> List[CachedGistt]:
        """Return cached gistts for any of the provided accounts."""
        normalized: Optional[set[str]]
        if accounts is None:
            normalized = None
        else:
            normalized = {self._normalize_account(account) for account in accounts}
        with self._lock:
            entries = [
                self._deserialize_entry(payload)
                for payload in self._entries.values()
                if normalized is None or payload.get("account_key") in normalized
            ]
        entries.sort(key=lambda item: item.cached_at, reverse=True)
        if limit is not None and limit >= 0:
            entries = entries[:limit]
        return entries

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
    def _load(self) -> None:
        if not self._path.exists():
            self._entries = {}
            return

        try:
            raw = json.loads(self._path.read_text())
        except (json.JSONDecodeError, OSError):
            self._entries = {}
            return

        if not isinstance(raw, dict):
            self._entries = {}
            return

        version = raw.get("version")
        entries = raw.get("entries")
        if version != CACHE_VERSION or not isinstance(entries, dict):
            self._entries = {}
            return

        self._entries = {}
        for key, payload in entries.items():
            if not isinstance(payload, dict):
                continue
            self._entries[str(key)] = payload

    def _save(self) -> None:
        target_dir = self._path.parent if self._path else CACHE_DIR
        target_dir.mkdir(parents=True, exist_ok=True)
        serialized = {
            "version": CACHE_VERSION,
            "entries": self._entries,
        }
        self._path.write_text(json.dumps(serialized, indent=2))

    def _serialize_entry(self, email_message: EmailMessage, gist: Gistt) -> Dict[str, Any]:
        context_payload = self._serialize_context(email_message.context)
        recommendation_payload = self._serialize_recommendation(gist)
        account_value = email_message.account or ""
        return {
            "account": account_value,
            "account_key": self._normalize_account(account_value),
            "message_id": email_message.id,
            "thread_id": context_payload.get("id") if context_payload else "",
            "cached_at": self._now(),
            "email": self._serialize_email(email_message),
            "context": context_payload,
            "gistt": recommendation_payload,
        }

    def _deserialize_entry(self, payload: Dict[str, Any]) -> CachedGistt:
        context = self._deserialize_context(payload.get("context"))
        email_payload = payload.get("email") or {}
        email = self._deserialize_email(email_payload, context=context)

        gist_payload = payload.get("gistt") or {}
        gist = self._deserialize_gist(gist_payload, email)

        cached_at = str(payload.get("cached_at", self._now()))
        return CachedGistt(gist=gist, cached_at=cached_at)

    def _serialize_email(self, email: EmailMessage) -> Dict[str, Any]:
        return {
            "id": email.id,
            "sender": email.sender,
            "subject": email.subject,
            "time": email.time,
            "body": email.body,
            "is_from_user": email.is_from_user,
            "account": email.account,
        }

    def _deserialize_email(
        self,
        payload: Dict[str, Any],
        *,
        context: Optional[EmailContext],
    ) -> EmailMessage:
        return EmailMessage(
            id=str(payload.get("id", "")),
            sender=str(payload.get("sender", "")),
            subject=str(payload.get("subject", "")),
            time=str(payload.get("time", "")),
            body=str(payload.get("body", "")),
            is_from_user=bool(payload.get("is_from_user", False)),
            account=str(payload.get("account", "")),
            context=context,
        )

    def _serialize_context(self, context: Optional[EmailContext]) -> Optional[Dict[str, Any]]:
        if context is None:
            return None
        return {
            "id": context.id,
            "messages": [self._serialize_email(message) for message in context.messages],
        }

    def _deserialize_context(self, payload: Optional[Dict[str, Any]]) -> Optional[EmailContext]:
        if not payload:
            return None
        messages_payload = payload.get("messages") or []
        messages = [
            self._deserialize_email(msg_payload, context=None)
            for msg_payload in messages_payload
            if isinstance(msg_payload, dict)
        ]
        context_id = str(payload.get("id", ""))
        return EmailContext(id=context_id, messages=messages)

    def _serialize_recommendation(self, gist: Gistt) -> Dict[str, Any]:
        recommendation = gist.recommendation
        action_group = recommendation.action_group if recommendation else gist.action_group
        state_value: Optional[str]
        if isinstance(gist.state, GisttState):
            state_value = gist.state.value
        elif isinstance(gist.state, str):
            state_value = gist.state
        else:
            state_value = None

        return {
            "gistt": gist.content,
            "action_group": self._serialize_action_group(action_group) if action_group else None,
            "explanation": recommendation.explanation if recommendation else None,
            "state": state_value,
        }

    def _deserialize_gist(self, payload: Dict[str, Any], email: EmailMessage) -> Gistt:
        explanation = payload.get("explanation")
        gist_content = payload.get("gistt")
        state_value = payload.get("state")

        action_group_payload = payload.get("action_group")
        action_group = self._deserialize_action_group(action_group_payload) if action_group_payload else None
        recommendation = (
            ActionGroupRec(action_group=action_group, explanation=str(explanation or ""))
            if action_group
            else None
        )

        state: Optional[GisttState | str] = None
        if isinstance(state_value, str) and state_value:
            try:
                state = GisttState(state_value)
            except ValueError:
                state = state_value

        return Gistt(
            content=str(gist_content or ""),
            email_message=email,
            action_group=action_group,
            recommendation=recommendation,
            state=state,
        )

    def _serialize_action_group(self, action_group: ActionGroup) -> Dict[str, Any]:
        raw_action = action_group.action
        if hasattr(raw_action, "name"):
            action_value = str(getattr(raw_action, "name"))
        elif raw_action is None:
            action_value = None
        else:
            action_value = str(raw_action)

        return {
            "group": action_group.group,
            "canonical": action_group.canonical_name,
            "action": action_value,
            "condition": action_group.condition,
            "instruction": action_group.instruction,
            "priority": action_group.priority,
        }

    def _deserialize_action_group(self, payload: Dict[str, Any]) -> ActionGroup | None:
        if not isinstance(payload, dict):
            return None

        group_label = payload.get("group") or payload.get("canonical")
        if not group_label:
            return None

        action_value = payload.get("action")
        condition_value = payload.get("condition") or ""
        instruction_value = payload.get("instruction") or ""
        priority_value = payload.get("priority")
        try:
            priority = int(priority_value)
        except (TypeError, ValueError):
            priority = 100

        return ActionGroup(
            group=str(group_label),
            action=action_value,
            condition=str(condition_value),
            instruction=str(instruction_value),
            priority=priority,
        )

    def _key(self, account: Optional[str], message_id: str) -> str:
        return f"{self._normalize_account(account)}::{message_id}"

    def _normalize_account(self, account: Optional[str]) -> str:
        value = str(account or "").strip().lower()
        return value or _DEFAULT_ACCOUNT_KEY

    def _now(self) -> str:
        return datetime.now(timezone.utc).isoformat()
