"""Shared helpers used by service-layer components."""
from __future__ import annotations

import re
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime

from gistt.models import EmailContext

_INLINE_CSS_PATTERN = re.compile(
    r"^\s*(?:[#.\w-]+|\*|\[[^\]]+\])(?:\s+[.#\w\[\]\-=\"]+)*\s*\{[^{}]*\}\s*$"
)


def sanitize_email_body(body: str | None) -> str:
    """Strip inline CSS boilerplate and style blocks from email bodies."""
    if not body:
        return ""

    text = re.sub(r"<style[^>]*>.*?</style>", "", body, flags=re.IGNORECASE | re.DOTALL)
    lines = text.splitlines()
    cleaned: list[str] = []
    css_depth = 0

    for line in lines:
        stripped = line.strip()
        if css_depth > 0:
            css_depth += stripped.count("{")
            css_depth -= stripped.count("}")
            css_depth = max(css_depth, 0)
            continue

        if stripped.startswith("@media"):
            css_depth = stripped.count("{") - stripped.count("}")
            css_depth = max(css_depth, 0)
            continue

        if stripped == "}" or _INLINE_CSS_PATTERN.match(stripped):
            continue

        cleaned.append(line)

    result = "\n".join(cleaned)
    return re.sub(r"\n{3,}", "\n\n", result).strip()


def format_thread_context(email_context: EmailContext | None, *, now: datetime | None = None) -> str:
    """Render an email thread context in a compact, prompt-friendly layout."""
    if not email_context or not email_context.messages:
        return ""

    segments: list[str] = []
    for message in email_context.messages:
        timestamp = format_prompt_timestamp(message.time, now=now)
        cleaned_body = sanitize_email_body(message.body)
        segments.append(
            "\n".join(
                [
                    f"From: {message.sender}",
                    f"Subject: {message.subject}",
                    f"Time: {timestamp}",
                    f"Body: {cleaned_body}",
                ]
            )
        )
    return "\n".join(segments)


def format_prompt_timestamp(raw_time: str | None, *, now: datetime | None = None) -> str:
    """Return canonical timestamp text enriched with a relative indicator when available."""
    if not raw_time:
        return "unknown"
    relative = format_relative_time(raw_time, now=now)
    if relative:
        return f"{raw_time} ({relative})"
    return raw_time


def format_relative_time(raw_time: str | None, *, now: datetime | None = None) -> str | None:
    """Convert a timestamp into a human friendly relative string (e.g., 3d ago)."""
    timestamp = parse_timestamp(raw_time)
    if not timestamp:
        return None
    reference = now if now else _now()
    delta = reference - timestamp
    if delta.total_seconds() < 0:
        return "in future"
    if delta < timedelta(minutes=1):
        return "just now"
    if delta < timedelta(hours=1):
        minutes = int(delta.total_seconds() // 60)
        return f"{minutes}m ago"
    if delta < timedelta(days=1):
        hours = int(delta.total_seconds() // 3600)
        return f"{hours}h ago"
    if delta < timedelta(days=7):
        days = delta.days
        return f"{days}d ago"
    return timestamp.astimezone().strftime("%Y-%m-%d")


def parse_timestamp(raw_time: str | None) -> datetime | None:
    """Parse various timestamp strings into a timezone-aware UTC datetime."""
    if not raw_time:
        return None
    candidate = raw_time.replace("Z", "+00:00") if raw_time.endswith("Z") else raw_time
    try:
        parsed = datetime.fromisoformat(candidate)
    except ValueError:
        try:
            parsed = parsedate_to_datetime(raw_time)
        except (TypeError, ValueError):
            return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _now() -> datetime:
    """Return the current time in UTC; isolated for easier patching in tests."""
    return datetime.now(timezone.utc)


__all__ = [
    "format_prompt_timestamp",
    "format_relative_time",
    "format_thread_context",
    "parse_timestamp",
    "sanitize_email_body",
]
