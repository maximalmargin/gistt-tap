"""Interface to GenAI services."""
from __future__ import annotations

import os
from dataclasses import dataclass
import types as py_types

from google import genai
from google.genai import types


@dataclass
class GenAIOps:
    api_key: str = os.environ.get("GEMINI_API_KEY")
    model: str = "gemini-flash-latest"
    config: types.GenerateContentConfig | None = None
    retry_count: int = 3
    
    def __post_init__(self):
        if not self.config:
            thinking_cls = getattr(types, "ThinkingConfig", None)
            if thinking_cls is not None:
                self.config = types.GenerateContentConfig(
                    thinking_config=thinking_cls(
                        thinking_budget=-1,
                    ),
                )
            else:
                self.config = types.GenerateContentConfig()
                self.config.thinking_config = py_types.SimpleNamespace(thinking_budget=-1)
        self.client = genai.Client(
            api_key=self.api_key,
        )
    
    def generate(self, prompt: str) -> str:
        for _ in range(self.retry_count):
            try:
                response = self.client.models.generate_content(
                    model=self.model,
                    contents=prompt,
                    config=self.config,
                )
                return response.text
            except:
                continue
        return "Failed to generate content."
