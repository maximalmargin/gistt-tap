"""Controller for the table view."""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
import logging
from typing import Any, Callable, Dict, List, Optional, Tuple

from gistt.actions import available_actions
from gistt.controller.base import Controller
from gistt.controller.session_state import SessionState, SessionStateStore
from gistt.models import Action, ActionGroup, EmailContext, EmailMessage, Gistt, GisttState
from gistt.services.gmail_ops import GmailOps
from gistt.services.gistt_producer import GisttProducer
from gistt.services.gistt_cache_store import CachedGistt
from gistt.settings import Settings


log = logging.getLogger(__name__)


class TableController(Controller):
    """Encapsulates the decision logic for the table view."""

    _ACTION_STATE_MAP: Dict[str, Optional[GisttState]] = {
        "archive": GisttState.ARCHIVED,
        "read": GisttState.REVIEWED,
        "save": GisttState.SAVED,
        "clear": None,
    }

    def __init__(
        self,
        session_store: SessionStateStore,
        gmail_ops: GmailOps,
        settings: Settings,
        gistt_producer: Optional[GisttProducer] = None,
        actions: Optional[Dict[str, Action]] = None,
    ) -> None:
        self.session_store = session_store
        self._gmail_ops = gmail_ops
        self._settings = settings
        self._gistt_producer = gistt_producer or GisttProducer()
        self._last_result: List[CachedGistt] = []
        self._desired_fetch: Dict[str, int] = {}
        self._current_account_key: Optional[str] = None
        self._selected_index: int = self._load_selected_index()
        self._actions: Dict[str, Action] = {}
        self._shortcut_map: Dict[str, str] = {}
        source_actions = actions or available_actions()
        for name, action in source_actions.items():
            normalized = (name or "").strip().lower()
            if not normalized:
                continue
            self._actions[normalized] = action
            self._register_action_shortcuts(action)

    # ------------------------------------------------------------------
    # Controller interface
    # ------------------------------------------------------------------
    def handle_choice(self, choice: str) -> Dict[str, Any]:
        """Handle an incoming key press from the table view."""
        raw_choice = choice or ""
        normalized = raw_choice.strip().lower()

        if raw_choice == "\t" or normalized == "tab":
            return self._handle_execute_recommended_action()

        if normalized == "g":
            return self._handle_fetch_gist()

        action_name = self._resolve_shortcut_action(normalized)
        if action_name:
            return self._handle_execute_named_action(action_name)

        return {"status": "noop", "choice": choice}

    def fetch_gists(self, *, progress: Optional[Callable[[str], None]] = None) -> Dict[str, Any]:
        """Fetch Gmail threads and produce gistts while streaming progress updates."""
        return self._handle_fetch_gist(progress=progress)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _handle_fetch_gist(self, *, progress: Optional[Callable[[str], None]] = None) -> Dict[str, Any]:
        state = self.session_store.load()
        account_email: Optional[str] = None
        multi_account_mode = False
        if isinstance(state, SessionState):
            account_email = state.active_account_email
            multi_account_mode = state.multi_account_mode

        if multi_account_mode:
            return self._fetch_all_accounts(progress=progress)

        return self._fetch_single_account(account_email, progress=progress)

    def _fetch_single_account(
        self,
        account_email: Optional[str],
        *,
        progress: Optional[Callable[[str], None]],
    ) -> Dict[str, Any]:
        account_key = self._account_key(account_email)
        self._reset_account_state_if_needed(account_key)

        previous_total = len(self._last_result)
        desired_limit = self._desired_fetch.get(account_key, 0)
        fetch_window = self._fetch_window_size()
        desired_limit += fetch_window
        self._desired_fetch[account_key] = desired_limit

        self._notify_progress(progress, "fetching gmail threads...")
        results = self._gmail_ops.fetch_messages_with_context(
            account_email=account_email,
            limit=desired_limit,
            max_messages_per_thread=None,
        )
        if results is None:
            message = "Unable to load email context. Confirm your Gmail account is linked."
            return {"status": "error", "message": message}

        if results:
            total = len(results)
            emails: List[EmailMessage] = []
            for email, context in results:
                if email.context is None and context is not None:
                    email = replace(email, context=context)
                emails.append(email)

            progress_callback: Optional[
                Callable[[int, int, EmailMessage], None]
            ] = None
            if progress:
                def _progress(completed: int, count: int, _: EmailMessage) -> None:
                    progress(f"producing gistt {completed}/{count}...")
                progress_callback = _progress

            preferences = getattr(self._settings, "preferences", None)
            worker_count = getattr(preferences, "summary_workers", None)
            self._gistt_producer.produce_many(
                emails,
                max_workers=worker_count,
                progress=progress_callback,
            )

        self._notify_progress(progress, "refreshing cached gistts...")
        cached_entries = self._gistt_producer.cached_gists(
            account_email=account_email,
            limit=None,
        )
        self._last_result = self._order_cached_results(list(cached_entries))
        count = len(self._last_result)
        added_count = max(count - previous_total, 0)
        self.reset_selection(count)
        payload: Dict[str, Any] = {
            "status": "ok",
            "results": self._last_result,
            "count": count,
            "added": added_count,
        }
        if count == 0:
            payload["message"] = "No gistts available."
        return payload

    def _fetch_all_accounts(
        self,
        *,
        progress: Optional[Callable[[str], None]],
    ) -> Dict[str, Any]:
        multi_key = self._account_key(None, multi_account=True)
        self._reset_account_state_if_needed(multi_key)

        previous_total = len(self._last_result)
        fetch_window = self._fetch_window_size()
        self._desired_fetch[multi_key] = self._desired_fetch.get(multi_key, 0) + fetch_window

        accounts = self._gmail_ops.list_accounts()
        if not accounts:
            message = "No linked Gmail accounts. Link an account first."
            return {"status": "error", "message": message}

        emails: List[EmailMessage] = []
        failed_accounts: List[str] = []
        had_successful_fetch = False

        for account in accounts:
            account_key = self._account_key(account.email)
            desired_limit = self._desired_fetch.get(account_key, 0) + fetch_window
            self._desired_fetch[account_key] = desired_limit

            self._notify_progress(progress, f"fetching gmail threads for {account.email}...")
            results = self._gmail_ops.fetch_messages_with_context(
                account_email=account.email,
                limit=desired_limit,
                max_messages_per_thread=None,
            )
            if results is None:
                failed_accounts.append(account.email)
                continue

            had_successful_fetch = True
            for email, context in results:
                if email.context is None and context is not None:
                    email = replace(email, context=context)
                emails.append(email)

        if not had_successful_fetch and not emails:
            detail = ""
            if failed_accounts:
                detail = f" Unable to fetch: {', '.join(sorted(failed_accounts))}."
            message = "Unable to load email context. Confirm your Gmail accounts are linked."
            return {"status": "error", "message": f"{message}{detail}"}

        if emails:
            preferences = getattr(self._settings, "preferences", None)
            worker_count = getattr(preferences, "summary_workers", None)
            progress_callback: Optional[Callable[[int, int, EmailMessage], None]] = None
            if progress:
                def _progress(completed: int, count: int, _: EmailMessage) -> None:
                    progress(f"producing gistt {completed}/{count}...")
                progress_callback = _progress
            self._gistt_producer.produce_many(
                emails,
                max_workers=worker_count,
                progress=progress_callback,
            )

        self._notify_progress(progress, "refreshing cached gistts...")

        account_filters: List[str | None] = [account.email for account in accounts]
        account_filters.append(None)
        cached_entries = self._gistt_producer.cached_gists(
            account_emails=account_filters,
            limit=None,
        )
        self._last_result = self._order_cached_results(list(cached_entries))
        count = len(self._last_result)
        added_count = max(count - previous_total, 0)
        self.reset_selection(count)

        payload: Dict[str, Any] = {
            "status": "ok",
            "results": self._last_result,
            "count": count,
            "added": added_count,
        }

        if count == 0:
            base_message = "No gistts available."
            if failed_accounts:
                base_message = f"{base_message} Unable to fetch: {', '.join(sorted(failed_accounts))}."
            payload["message"] = base_message
        elif failed_accounts:
            payload["message"] = f"Fetched gistts with warnings. Unable to fetch: {', '.join(sorted(failed_accounts))}."

        return payload

    def cached_results(self) -> List[CachedGistt]:
        """Return cached gistts for the current session account."""
        state = self.session_store.load()
        account_email: Optional[str] = None
        multi_account_mode = False
        if isinstance(state, SessionState):
            account_email = state.active_account_email
            multi_account_mode = state.multi_account_mode

        if multi_account_mode:
            return self._cached_results_all_accounts()

        account_key = self._account_key(account_email)
        self._reset_account_state_if_needed(account_key)

        cached_entries = self._gistt_producer.cached_gists(
            account_email=account_email,
            limit=None,
        )
        self._last_result = self._order_cached_results(list(cached_entries))
        total = len(self._last_result)
        if total:
            self._desired_fetch.setdefault(account_key, 0)
            self.sync_selection(total)
        else:
            self._desired_fetch[account_key] = 0
            self._set_selection(0, force=True)
        return self._last_result

    def _cached_results_all_accounts(self) -> List[CachedGistt]:
        multi_key = self._account_key(None, multi_account=True)
        self._reset_account_state_if_needed(multi_key)

        accounts = self._gmail_ops.list_accounts()
        if not accounts:
            self._desired_fetch[multi_key] = 0
            self._last_result = []
            self._set_selection(0, force=True)
            return []

        account_filters: List[str | None] = [account.email for account in accounts]
        account_filters.append(None)
        cached_entries = self._gistt_producer.cached_gists(
            account_emails=account_filters,
            limit=None,
        )
        self._last_result = self._order_cached_results(list(cached_entries))
        total = len(self._last_result)

        self._desired_fetch.setdefault(multi_key, 0)
        for account in accounts:
            account_key = self._account_key(account.email)
            self._desired_fetch.setdefault(account_key, 0)

        if total:
            self.sync_selection(total)
        else:
            self._desired_fetch[multi_key] = 0
            self._set_selection(0, force=True)
        return self._last_result

    def last_email(self) -> Optional[EmailMessage]:
        """Return the last fetched email, if available."""
        if not self._last_result:
            return None
        return self._last_result[0].gist.email_message

    def last_context(self) -> Optional[EmailContext]:
        """Return the last fetched email context, if available."""
        if not self._last_result:
            return None
        return self._last_result[0].gist.email_message.context

    def last_results(self) -> List[Gistt]:
        """Return the last fetched results."""
        return [entry.gist for entry in self._last_result]

    # ------------------------------------------------------------------
    # Action helpers
    # ------------------------------------------------------------------
    def _handle_execute_recommended_action(self) -> Dict[str, Any]:
        selection = self._selected_entry()
        if selection is None:
            return {
                "status": "noop",
                "message": "No gistts available to act on.",
            }

        target_index, cached = selection
        gist = cached.gist
        action_name = self._recommended_action_name(gist)
        if not action_name:
            return {
                "status": "noop",
                "message": "No recommended action for the selected gistt.",
            }

        self._advance_selection()

        action = self._resolve_action(action_name)
        if action is None:
            log.warning("Requested action '%s' is not available.", action_name)
            return {
                "status": "error",
                "action": action_name,
                "message": f"Action '{action_name}' is not implemented.",
            }

        return self._execute_action(action=action, target_index=target_index, gist=gist)

    def _handle_execute_named_action(self, action_name: str) -> Dict[str, Any]:
        selection = self._selected_entry()
        if selection is None:
            return {
                "status": "noop",
                "message": "No gistts available to act on.",
            }

        target_index, cached = selection
        self._advance_selection()
        action = self._resolve_action(action_name)
        if action is None:
            log.warning("Requested action '%s' is not available.", action_name)
            return {
                "status": "error",
                "action": action_name,
                "message": f"Action '{action_name}' is not implemented.",
            }

        return self._execute_action(action=action, target_index=target_index, gist=cached.gist)

    def _execute_action(self, *, action: Action, target_index: int, gist: Gistt) -> Dict[str, Any]:
        total = len(self._last_result)
        if total <= 0:
            return {
                "status": "noop",
                "message": "No gistts available to act on.",
            }

        try:
            success = action.execute(gist, self._gmail_ops)
        except Exception as error:  # noqa: BLE001
            log.error("Failed to execute action '%s': %s", action.name, error, exc_info=True)
            return {
                "status": "error",
                "action": action.name,
                "message": f"Failed to execute '{action.name}'.",
            }

        subject = getattr(gist.email_message, "subject", "") or "(No subject)"
        status = "ok" if success else "error"
        if success:
            self._apply_action_result(index=target_index, action=action)
        message = (
            f"Executed '{action.name}' for '{subject}'."
            if success
            else f"Action '{action.name}' reported failure for '{subject}'."
        )
        return {
            "status": status,
            "action": action.name,
            "message": message,
        }

    def _recommended_action_name(self, gist: Gistt) -> Optional[str]:
        group = None
        if gist.recommendation and gist.recommendation.action_group:
            group = gist.recommendation.action_group
        elif gist.action_group:
            group = gist.action_group

        if group is None:
            return None

        raw = group.action
        if isinstance(raw, Action):
            return raw.name
        if isinstance(raw, str):
            normalized = raw.strip().lower()
            return normalized or None
        return None

    def _resolve_action(self, name: str) -> Optional[Action]:
        if not name:
            return None
        key = name.strip().lower()
        if not key:
            return None
        return self._actions.get(key)

    def resolve_action_shortcut(self, shortcut: str) -> Optional[str]:
        key = self._normalize_shortcut(shortcut)
        if not key:
            return None
        return self._shortcut_map.get(key)

    def is_action_shortcut(self, shortcut: str) -> bool:
        return self.resolve_action_shortcut(shortcut) is not None

    def _register_action_shortcuts(self, action: Action) -> None:
        for shortcut in getattr(action, "shortcuts", []) or []:
            key = self._normalize_shortcut(shortcut)
            if not key:
                continue
            self._shortcut_map.setdefault(key, action.name)

    @staticmethod
    def _normalize_shortcut(shortcut: Optional[str]) -> str:
        if shortcut is None:
            return ""
        return str(shortcut).strip().lower()

    def _resolve_shortcut_action(self, shortcut: str) -> Optional[str]:
        key = self._normalize_shortcut(shortcut)
        if not key:
            return None
        return self._shortcut_map.get(key)

    def _selected_entry(self) -> Optional[Tuple[int, CachedGistt]]:
        if not self._last_result:
            return None
        total = len(self._last_result)
        clamped = self._clamp_selection(self._selected_index, total)
        if clamped != self._selected_index:
            self._set_selection(clamped, force=True)
        if clamped < 0 or clamped >= total:
            return None
        return clamped, self._last_result[clamped]

    def _advance_selection(self) -> int:
        total = len(self._last_result)
        if total > 0:
            self.move_selection(1, total)
        return total

    def _reset_account_state_if_needed(self, account_key: str) -> None:
        if self._current_account_key != account_key:
            self._current_account_key = account_key
            self._desired_fetch[account_key] = self._desired_fetch.get(account_key, 0)
            self._set_selection(0)

    def _account_key(self, account_email: Optional[str], *, multi_account: bool = False) -> str:
        if multi_account:
            return "__all_accounts__"
        return (account_email or "__default__").lower()

    @staticmethod
    def _notify_progress(progress: Optional[Callable[[str], None]], message: str) -> None:
        if progress:
            progress(message)

    def _persist_session(self, *, selected_index: Optional[int] = None) -> None:
        state = self.session_store.load()
        if not isinstance(state, SessionState):
            return

        if selected_index is None:
            self.session_store.save(state)
            return

        new_table_state = replace(state.table_state, selected_index=selected_index)
        updated_state = replace(state, table_state=new_table_state)
        self.session_store.save(updated_state)

    # ------------------------------------------------------------------
    # Selection helpers
    # ------------------------------------------------------------------
    def current_selection(self) -> int:
        """Return the persisted selection index."""
        return self._selected_index

    def sync_selection(self, total: int) -> int:
        """Clamp the current selection to the available rows."""
        clamped = self._clamp_selection(self._selected_index, total)
        self._set_selection(clamped, persist=clamped != self._selected_index)
        return self._selected_index

    def reset_selection(self, total: int) -> int:
        """Reset selection to the first row."""
        clamped = self._clamp_selection(0, total)
        self._set_selection(clamped, force=True)
        return self._selected_index

    def move_selection(self, delta: int, total: int) -> tuple[int, bool]:
        """Move the selection by delta, returning the new index and whether it changed."""
        if total <= 0:
            self._set_selection(0, force=False)
            return self._selected_index, False

        target = self._clamp_selection(self._selected_index + delta, total)
        changed = target != self._selected_index
        self._set_selection(target, persist=changed)
        return self._selected_index, changed

    def set_selection(self, index: int) -> int:
        """Force the selection to a specific index within the current results."""
        total = len(self._last_result)
        clamped = self._clamp_selection(index, total)
        self._set_selection(clamped, force=True)
        return self._selected_index

    def _load_selected_index(self) -> int:
        state = self.session_store.load()
        if not isinstance(state, SessionState):
            return 0
        table_state = getattr(state, "table_state", None)
        selected = getattr(table_state, "selected_index", 0)
        if not isinstance(selected, int) or selected < 0:
            return 0
        return selected

    def _set_selection(self, value: int, *, persist: bool = True, force: bool = False) -> None:
        normalized = max(0, value)
        changed = force or normalized != self._selected_index
        self._selected_index = normalized
        if persist and changed:
            self._persist_session(selected_index=self._selected_index)

    @staticmethod
    def _clamp_selection(index: int, total: int) -> int:
        if total <= 0:
            return 0
        return max(0, min(index, total - 1))

    def _fetch_window_size(self) -> int:
        fetch_window = self._settings.preferences.default_fetch_size
        if fetch_window <= 0:
            return 5
        return fetch_window

    # ------------------------------------------------------------------
    # Ordering helpers
    # ------------------------------------------------------------------
    def _order_cached_results(self, entries: List[CachedGistt]) -> List[CachedGistt]:
        if not entries:
            return []

        grouped: Dict[str, Dict[str, Any]] = {}
        for item in entries:
            label = self._group_label(item)
            priority = self._group_priority(item)
            bucket = grouped.setdefault(label, {"items": [], "priority": priority})
            bucket["items"].append(item)
            if priority < bucket["priority"]:
                bucket["priority"] = priority

        ordered: List[CachedGistt] = []
        for label, payload in sorted(
            grouped.items(),
            key=lambda entry: (entry[1]["priority"], entry[0].lower()),
        ):
            items = payload["items"]
            items.sort(key=self._sort_key_for_group, reverse=True)
            ordered.extend(items)
        return ordered

    def _group_label(self, cached: CachedGistt) -> str:
        group = self._resolve_action_group(cached)
        if group and getattr(group, "group", None):
            return group.group
        return "Other"

    def _group_priority(self, cached: CachedGistt) -> int:
        group = self._resolve_action_group(cached)
        if group and hasattr(group, "priority"):
            try:
                return int(getattr(group, "priority"))
            except (TypeError, ValueError):
                return 100
        return 100

    @staticmethod
    def _resolve_action_group(cached: CachedGistt) -> Optional[ActionGroup]:
        gist = cached.gist
        if gist.recommendation and gist.recommendation.action_group:
            return gist.recommendation.action_group
        return gist.action_group

    def _apply_action_result(self, *, index: int, action: Action) -> None:
        if index < 0 or index >= len(self._last_result):
            return

        cached = self._last_result[index]
        if action.name == "clear":
            updated_state: Optional[GisttState | str] = None
        else:
            state = self._state_for_action(action.name)
            if state is None:
                return
            updated_state = state

        updated_gist = replace(cached.gist, state=updated_state)
        updated_cached = replace(cached, gist=updated_gist)
        self._last_result[index] = updated_cached

        cache_store = getattr(self._gistt_producer, "cache_store", None)
        if cache_store is None:
            return
        try:
            cache_store.upsert(updated_gist.email_message, updated_gist)
        except Exception as error:  # noqa: BLE001
            log.warning("Failed to persist gist state update for action '%s': %s", action.name, error)

    def _state_for_action(self, action_name: str | None) -> Optional[GisttState]:
        if not action_name:
            return None
        key = action_name.strip().lower()
        if not key:
            return None
        return self._ACTION_STATE_MAP.get(key)

    def _sort_key_for_group(self, cached: CachedGistt) -> tuple[datetime, str]:
        timestamp = self._timestamp_for_cached(cached)
        message_id = getattr(cached.gist.email_message, "id", "") or ""
        return timestamp, message_id

    def _timestamp_for_cached(self, cached: CachedGistt) -> datetime:
        email = cached.gist.email_message
        raw_time = getattr(email, "time", None)
        parsed = self._parse_timestamp(raw_time)
        if parsed:
            return parsed
        return datetime.min.replace(tzinfo=timezone.utc)

    @staticmethod
    def _parse_timestamp(raw: Optional[str]) -> Optional[datetime]:
        if not raw:
            return None
        value = raw.strip()
        if not value:
            return None

        candidate = value.replace("Z", "+00:00") if value.endswith("Z") else value
        try:
            parsed = datetime.fromisoformat(candidate)
        except ValueError:
            try:
                parsed = parsedate_to_datetime(value)
            except (TypeError, ValueError):
                return None

        if parsed is None:
            return None
        if parsed.tzinfo is None:
            return parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc)
