"""Settings loader."""

from typing import List
from collections.abc import Mapping
from dataclasses import dataclass, field
from importlib import resources
import json

import logging
logger = logging.getLogger(__name__)

from gistt.models import ActionGroup

@dataclass(frozen=True)
class Preferences:
    recency_cutoff_days: int = 10
    summary_workers: int = 3
    default_fetch_size: int = 4


@dataclass
class Settings:
    action_groups: List[ActionGroup] = field(default_factory=list)
    preferences: Preferences = field(default_factory=Preferences)
    
    _SETTINGS_PATH = "data/settings.json"

    def __post_init__(self) -> None:
        self._settings = self._load_settings_payload()
        self.action_groups = self._parse_action_groups(self._settings)
        self.preferences = self._parse_preferences(self._settings)

    def _load_settings_payload(self) -> Mapping[str, object]:
        with resources.files("gistt").joinpath(self._SETTINGS_PATH).open("r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, Mapping) else {}
    
    def _parse_action_groups(self, data: Mapping[str, object]) -> List[ActionGroup]:
        try:
            action_groups = data.get("action_groups")
            if isinstance(action_groups, List):
                return [ActionGroup(**action_group) for action_group in action_groups]
            return []
        except (KeyError, TypeError, ValueError) as e:
            logger.warning("Failed to parse action groups: %s", e)
            return []
    
    def _parse_preferences(self, data: Mapping[str, object]) -> Preferences:
        try:
            preferences = data.get("preferences")
            if isinstance(preferences, Mapping):
                return Preferences(**preferences)
            return Preferences()
        except (KeyError, TypeError, ValueError) as e:
            logger.warning("Failed to parse preferences: %s", e)
            return Preferences()

    def group_for_name(self, name: str) -> ActionGroup | None:
        """Return the configured action group matching the provided display name."""
        normalized = (name or "").strip().lower()
        if not normalized:
            return None
        for action_group in self.action_groups:
            if action_group.group.strip().lower() == normalized:
                return action_group

        fallbacks = {
            "waiting on reply": {
                "group": "Waiting on Reply",
                "action": "read",
                "condition": "Use when you're awaiting a response from someone else and need to keep the thread handy.",
                "instruction": "Summarize outstanding follow-up needs in under 15 words.",
                "priority": 20,
            },
        }
        definition = fallbacks.get(normalized)
        if definition:
            return ActionGroup(**definition)
        return None


_SETTINGS_SINGLETON: Settings | None = None


def get_settings() -> Settings:
    """Return a cached Settings instance, constructing it on first use."""
    global _SETTINGS_SINGLETON
    if _SETTINGS_SINGLETON is None:
        _SETTINGS_SINGLETON = Settings()
    return _SETTINGS_SINGLETON
